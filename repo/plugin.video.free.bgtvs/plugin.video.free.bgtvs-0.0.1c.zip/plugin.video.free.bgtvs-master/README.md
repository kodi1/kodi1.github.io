# plugin.video.free.bgtvs

Kodi addon for watching Bulgarian TV channels. 
The addon only provides access to official TV streams that are publicly available and free to watch.

Install the addon from the offical Kodi BG repo, or manually from a zip file (download it from here). 
