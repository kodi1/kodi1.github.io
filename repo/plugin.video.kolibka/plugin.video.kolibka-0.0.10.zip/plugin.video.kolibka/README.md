plugin.video.kolibka
====================
Initialy imported from here:
https://www.kaldata.com/forums/topic/231643-kolibka-%D0%B7%D0%B0-xbmc-media-center-aka-kodi/

If you are a owner please contact me to transfer ownership of that repo.