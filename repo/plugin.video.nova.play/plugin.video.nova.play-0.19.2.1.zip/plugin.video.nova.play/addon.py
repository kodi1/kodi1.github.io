# -*- coding: utf-8 -*-
from datetime import datetime
import re
import sys
import urllib.request, urllib.parse, urllib.error
import requests
import json
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs


__addon_id__= 'plugin.video.nova.play'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.nova.play')
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:87.0) Gecko/20100101 Firefox/87.0'
md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_path = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/novaplay.search.txt")
api = "https://nbg-api.fite.tv/api/v2"


#Хедъри за заявки към API на услугата
novaplay_headers = {
	'User-Agent': UA,
	'authority': 'nbg-api.fite.tv',
	'accept': 'application/json, text/plain, */*',
	'x-flipps-user-agent': 'Flipps/75/9.7',
	'dnt': '1',
	'x-flipps-version': '2020-08-31',
	'origin': 'https://play.nova.bg',
	'Connection': 'keep-alive',
	'sec-fetch-site': 'cross-site',
	'sec-fetch-mode': 'cors',
	'sec-fetch-dest': 'empty',
	'referer': 'https://play.nova.bg',
	'accept-language': 'bg-BG,bg;q=0.9,en;q=0.8',
	'Accept-Encoding': 'gzip'
					}

#Основно меню
def CATEGORIES():
		addDir('Търсене на предаване','2','Търсене на предаване',2,md+'DefaultAddonsSearch.png')
		addLink('NOVA на живо','TV','',0,5,'http://logos.kodibg.org/nova.png')

		#Заявка за получаване на препоръките
		response = requests.get(api+'/screens/1', headers=novaplay_headers)
		jsonrsp = response.json()
		
		#Списък на препоръките
		for recomendations in range(0, len(jsonrsp['layouts'])):
			addDir(jsonrsp['layouts'][recomendations]['title'].encode('utf-8', 'ignore'),jsonrsp['layouts'][recomendations]['topics'][0]['links']['self']['href'],jsonrsp['layouts'][recomendations]['title'].encode('utf-8', 'ignore'),1,md+'DefaultFolder.png')

		#Заявка за получаване на категориите
		response = requests.get(api+'/screens/3', headers=novaplay_headers)
		jsonrsp = response.json()
		
		#Списък на категориите
		for categories in range(0, len(jsonrsp['layouts'])):
			addDir(jsonrsp['layouts'][categories]['title'].encode('utf-8', 'ignore'),jsonrsp['layouts'][categories]['topics'][0]['links']['self']['href'],jsonrsp['layouts'][categories]['title'].encode('utf-8', 'ignore'),1,md+'DefaultFolder.png')

		#Филтри към категориите
		for filters in range(1, len(jsonrsp['filters'])):
			response2 = requests.get(api+'/screens/3?filter_id='+str(jsonrsp['filters'][filters]['filter_id']), headers=novaplay_headers)
			jsonrsp2 = response2.json()
			addDir(jsonrsp['filters'][filters]['name'].encode('utf-8', 'ignore'),jsonrsp2['layouts'][0]['topics'][0]['links']['self']['href'],jsonrsp['filters'][filters]['name'].encode('utf-8', 'ignore'),1,md+'DefaultFolder.png')




#Списък на заглавията в една категория
def INDEXCAT(url):
		#Заявка за индексиране
		response = requests.get(api+url, headers=novaplay_headers)
		jsonrsp = response.json()
		#Разлистване
		for items in range(0, len(jsonrsp['items'])):
			#Достъпно за гледане до...
			try:
				avai = '.'.join(re.findall(r"[\d]{4}-[\d]{2}-[\d]{2}", jsonrsp['items'][items]['available_to'])[0].split('-')[::-1])
			except:
				avai = 'неопределено време'

			#Продължителност на видеото в секунди
			duration = '0'
			try:
				hours = re.findall(r"PT(\d{1,2})H", jsonrsp['items'][items]['content_details']['duration'])
			except:
				pass
			try:
				minutes = re.findall(r"\D(\d{1,2})M", jsonrsp['items'][items]['content_details']['duration'])
			except:
				pass
			try:
				seconds = re.findall(r"M(\d{1,2})S", jsonrsp['items'][items]['content_details']['duration'])
			except:
				pass
			try:
				hh = int(hours[0])*60*60
			except:
				hh = 0
			try:
				mm = int(minutes[0])*60
			except:
				mm = 0
			try:
				ss = int(seconds[0])
			except:
				ss = 0
			duration = str(int(hh) + int(mm) + int(ss))
			

			#Ако е епизод
			if (jsonrsp['items'][items]['content_details']['type'] == 'episode'):
				xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
				#name, adres, plot, duration, 5, cover
				addLink(jsonrsp['items'][items]['title'],(str(jsonrsp['items'][items]['content_details']['episode_number'])+'<>'+jsonrsp['items'][items]['links']['streams']['href']+'<>'+jsonrsp['items'][items]['description']+avai+'<>'+duration+'<>'+jsonrsp['items'][items]['links']['image']['href'].replace('{width}','460').replace('{height}','260')),jsonrsp['items'][items]['description']+avai,duration,5,jsonrsp['items'][items]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
			#Ако е филм, спешъл или рекламна заставка
			elif (jsonrsp['items'][items]['content_details']['type'] == 'movie' or jsonrsp['items'][items]['content_details']['type'] == 'tv_show_video' or jsonrsp['items'][items]['content_details']['type'] == 'clip'):
				xbmcplugin.setContent(int(sys.argv[1]), 'movies')
				addLink(jsonrsp['items'][items]['title'],jsonrsp['items'][items]['title']+'<>'+jsonrsp['items'][items]['links']['streams']['href']+'<>'+jsonrsp['items'][items]['description']+' : В каталога на NovaPlay до '+avai+'<>'+duration+'<>'+jsonrsp['items'][items]['links']['image']['href'].replace('{width}','460').replace('{height}','260'),jsonrsp['items'][items]['description']+' : В каталога на NovaPlay до '+avai,duration,5,jsonrsp['items'][items]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
			#Ако е сериал
			elif (jsonrsp['items'][items]['content_details']['type'] == 'tv_show'):
				xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

				try:
					desc = jsonrsp['items'][items]['description']
				except:
					desc = ''

				#name, link, description, 3, cover
				addDir(jsonrsp['items'][items]['title'],jsonrsp['items'][items]['links']['self']['href'],desc,3,jsonrsp['items'][items]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
			#Ако е сезон
			elif (jsonrsp['items'][items]['content_details']['type'] == 'season'):
				xbmcplugin.setContent(int(sys.argv[1]), 'seasons')

				try:
					desc = jsonrsp['items'][items]['description']
				except:
					desc = ''

				#name, link, description, 4, cover
				addDir(jsonrsp['items'][items]['title'],jsonrsp['items'][items]['links']['self']['href'],desc,4,jsonrsp['items'][items]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
			else:
				xbmcgui.Dialog().ok('Неподдържан тип съдържание в директорията',jsonrsp['items'][items]['content_details']['type'])




#Разлистване на сезоните
def INDEXSEASONS(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
		response = requests.get(api+url, headers=novaplay_headers)
		jsonrsp = response.json()
		#xbmcgui.Dialog().ok('URL',url)
		#xbmcgui.Dialog().ok('JSON',str(jsonrsp))

		for sn in range(0, len(jsonrsp['seasons'])):
			try:
				addDir(jsonrsp['seasons'][sn]['title'].encode('utf-8', 'ignore'),jsonrsp['seasons'][sn]['links']['self']['href'].encode('utf-8', 'ignore'),jsonrsp['selected_season']['description'].encode('utf-8', 'ignore'),4,jsonrsp['seasons'][sn]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
			except:
				addDir(jsonrsp['seasons'][sn]['title'].encode('utf-8', 'ignore'),jsonrsp['seasons'][sn]['links']['self']['href'].encode('utf-8', 'ignore'),'',4,jsonrsp['seasons'][sn]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
		
		#Корекция заради структурата на новинарския раздел (не се преминава през сезони)
		try:
			if len(jsonrsp) > 0:
				response2 = requests.get(api+url+'/videos', headers=novaplay_headers)
				jsonrsp2 = response2.json()
				for video in range(0, len(jsonrsp2)):
					addLink(jsonrsp2[video]['title'],jsonrsp2[video]['title']+'<>'+jsonrsp2[video]['links']['streams']['href']+'<>'+jsonrsp2[video]['description']+' : В каталога на NovaPlay до неопределено време'+'<>'+''+'<>'+'',jsonrsp2[video]['description']+' : В каталога на NovaPlay до неопределено време','',5,jsonrsp2[video]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
		except:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('NOVAPLAY','Грешка в INDEXSEASONS', 4000, md+'DefaultIconError.png'))
		



		
#Разлистване на епизодите
def INDEXEPISODES(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		response = requests.get(api+url, headers=novaplay_headers)
		jsonrsp = response.json()

		for en in range(0, len(jsonrsp['selected_season']['episodes'])):

			#Достъпно за гледане до...
			avai = 'неопределено време'
			try:
				avai = '.'.join(re.findall(r"[\d]{4}-[\d]{2}-[\d]{2}", jsonrsp['selected_season']['episodes'][en]['available_to'])[0].split('-')[::-1])
			except:
				pass

			#Продължителност на видеото в секунди
			duration = '0'
			try:
				hours = re.findall(r"PT(\d{1,2})H", jsonrsp['selected_season']['episodes'][en]['duration'])
			except:
				pass
			try:
				minutes = re.findall(r"\D(\d{1,2})M", jsonrsp['selected_season']['episodes'][en]['duration'])
			except:
				pass
			try:
				seconds = re.findall(r"M(\d{1,2})S", jsonrsp['selected_season']['episodes'][en]['duration'])
			except:
				pass
			try:
				hh = int(hours[0])*60*60
			except:
				hh = 0
			try:
				mm = int(minutes[0])*60
			except:
				mm = 0
			try:
				ss = int(seconds[0])
			except:
				ss = 0
			duration = str(int(hh) + int(mm) + int(ss))

			#name, adres, plot, duration, mode, cover
			try:
				addLink(jsonrsp['title']+' Сезон '+str(jsonrsp['selected_season']['episodes'][en]['season_number'])+' Епизод '+str(jsonrsp['selected_season']['episodes'][en]['episode_number']),jsonrsp['title']+' Сезон '+str(jsonrsp['selected_season']['episodes'][en]['season_number'])+' Епизод '+str(jsonrsp['selected_season']['episodes'][en]['episode_number'])+'<>'+jsonrsp['selected_season']['episodes'][en]['links']['streams']['href']+'<>'+jsonrsp['selected_season']['episodes'][en]['description']+' : В каталога на NovaPlay до '+avai+'<>'+duration+'<>'+jsonrsp['selected_season']['episodes'][en]['links']['image']['href'].replace('{width}','460').replace('{height}','260'),jsonrsp['selected_season']['episodes'][en]['description']+' : В каталога на NovaPlay до '+avai,duration,5,jsonrsp['selected_season']['episodes'][en]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
			except:
				try:
					addLink(jsonrsp['title']+' Сезон '+str(jsonrsp['selected_season']['episodes'][en]['season_number']),jsonrsp['title']+' Сезон '+str(jsonrsp['selected_season']['episodes'][en]['season_number'])+'<>'+jsonrsp['selected_season']['episodes'][en]['links']['streams']['href']+'<>'+jsonrsp['selected_season']['episodes'][en]['description']+' : В каталога на NovaPlay до '+avai+'<>'+duration+'<>'+jsonrsp['selected_season']['episodes'][en]['links']['image']['href'].replace('{width}','460').replace('{height}','260'),jsonrsp['selected_season']['episodes'][en]['description']+' : В каталога на NovaPlay до '+avai,duration,5,jsonrsp['selected_season']['episodes'][en]['links']['image']['href'].replace('{width}','460').replace('{height}','260'))
				except:
					addLink(jsonrsp['title'],''+'<>'+jsonrsp['selected_season']['episodes'][en]['links']['streams']['href']+'<>'+''+' : В каталога на NovaPlay до '+avai+'<>'+duration+'<>'+'',''+' : В каталога на NovaPlay до '+avai,duration,5,'')





#Отваряне на видео
def VIDEOLINKS(url):
		if ('TV' == url): #TV
			cover = 'http://logos.kodibg.org/nova.png'
			#EPG
			timenow = str(datetime.utcnow()).replace(' ','T')
			epg = "/videos/533888/epg?from_dt="+timenow+"Z&limit=1";
			response1 = requests.get(api+epg, headers=novaplay_headers)
			jsonrsp1 = response1.json()
			plot = jsonrsp1['programs'][0]['title'] + '.  Следва >> ' + jsonrsp1['programs'][1]['title']
			#xbmcgui.Dialog().ok('Plot',plot)
			#Stream
			response2 = requests.get(api+'/videos/533888/streams', headers=novaplay_headers)
			jsonrsp2 = response2.json()
			adres = jsonrsp2[0]['url']
			#Play		
			li = xbmcgui.ListItem(path=adres+'|User-Agent=stagefright&X-Forwarded-For=52.84.114.59')
			li.setArt({ 'thumb': cover,'poster': cover, 'banner' : cover, 'fanart': cover, 'icon': cover })
			li.setInfo( 'video', { 'Title': plot, 'Plot': plot } )
			try:
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			except:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('NOVAPLAY','Телевизията не е достъпна за гледане', 4000, md+'DefaultIconError.png'))
		else: #VOD
			name, adres, plot, duration, cover = url.split("<>")
			#if (not 'http' in cover):
			#	cover = 'https://nbg-img.fite.tv' + urllib.parse.quote(cover)
			#print (cover)
			response = requests.get(api+adres, headers=novaplay_headers)
			jsonrsp = response.json()
			#Play
			li = xbmcgui.ListItem(path=jsonrsp[0]['url']+'|User-Agent=stagefright&X-Forwarded-For=52.84.114.59')
			li.setArt({ 'thumb': cover,'poster': cover, 'banner' : cover, 'fanart': cover, 'icon': cover })
			li.setInfo( 'video', { 'Title': name, 'Duration': duration, 'Plot': plot } )
			try:
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			except:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('NOVAPLAY','Видеото не е достъпно за гледане', 4000, md+'DefaultIconError.png'))




#Търсене на предаване
def SEARCH():
		#Отваряне на предишната заявка за търсене
		searchfile=xbmcvfs.File(search_path)
		result = searchfile.read()
		searchfile.close()

		keyb = xbmc.Keyboard(result, 'Търсачка на предавания')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.parse.quote_plus(keyb.getText())
			searchText=searchText.replace(' ','+')
			if searchText == "":
				addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','','',md+'DefaultFolderBack.png')
			else:
				#Записване на заявката за търсене
				searchfile=xbmcvfs.File(search_path, 'w')
				result = searchfile.write(keyb.getText())
				searchfile.close()
				
				url= '/topics/-1?limit=75&q='+searchText
				INDEXCAT(url)
		else:
			addDir('Върнете се назад в главното меню за да продължите','','','',md+'DefaultFolderBack.png')




def addLink(name,url,plot,duration,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		liz.setInfo( type="Video", infoLabels={ "title": name, "duration": duration, "plot": plot } )
		liz.addStreamInfo('video', { 'width': 1920, 'height': 1080 })
		liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		
		contextmenu = []
		contextmenu.append(('Информация', 'XBMC.Action(Info)'))
		liz.addContextMenuItems(contextmenu)
		
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok




def addDir(name,url,plot,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name)
	liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
	
	if len(plot)>0:
		contextmenu = []
		contextmenu.append(('Информация', 'XBMC.Action(Info)'))
		liz.addContextMenuItems(contextmenu)
	
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok




def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass



if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEXCAT(url)

elif mode==2:
		SEARCH()

elif mode==3:
		INDEXSEASONS(url)

elif mode==4:
		INDEXEPISODES(url)
		
elif mode==5:
		VIDEOLINKS(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
