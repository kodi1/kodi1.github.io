# -*- coding: utf-8 -*-
import re
import sys
import os
import random
import urllib
import urllib2
import requests
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon


__addon_id__= 'plugin.video.nova.play'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.nova.play')
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0'
md = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_string = urllib.unquote_plus(__settings__.getSetting('lastsearch'))


#Хедъри за заявки към API на услугата
novaplay_headers = {
	'User-Agent': UA,
	'Accept': '*/*',
	'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
	'Referer': 'https://play.nova.bg',
	'Origin': 'https://play.nova.bg',
	'Connection': 'keep-alive',
	'Accept-Encoding': 'gzip'
					}

#Основно меню
def CATEGORIES():
		addDir('Търсене на предаване','2','Търсене на предаване',2,md+'DefaultAddonsSearch.png')
		#TV програма и обложка
		api = "http://nova.bg";
		opener = urllib2.build_opener()
		opener.addheaders = [('User-agent', UA)]
		data = opener.open(api).read()
		
		match = re.compile('<span class="live-info">(.+?)</span>').findall(data)
		for title in match:
			title = 'В момента по NOVA: ' + title
			addLink(title,title+'@'+'3'+'@'+'http://logos.kodibg.org/novatv.png',title,0,5,'http://logos.kodibg.org/novatv.png')
		
		
		#Заявка за получаване на категориите
		response = requests.get('https://neulioneumtsolrc-a.akamaihd.net/solr/eumt_category/novaplay/usersearch?fq=tags_type:GENRE&rows=5000&fl=catId,name,seoName,show,episodes,season&sort=rank%20asc&wt=json', headers=novaplay_headers)
		jsonrsp = response.json()
		
		#Списък на категориите
		for cat in range(0, len(jsonrsp['response']['docs'])):
			addDir(jsonrsp['response']['docs'][cat]['name'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][cat]['catId']),jsonrsp['response']['docs'][cat]['name'].encode('utf-8', 'ignore'),1,'https://neulioneumt-a.akamaihd.net/u/eumt/novaplay/thumbs/categories/'+str(jsonrsp['response']['docs'][cat]['catId'])+'_tb.jpg')



#Списък на заглавията в една категория
def INDEXCAT(url):
		#Задаване на жанровете
		url=url.replace('9','fq=tags_type:FILM').replace('10','fq=tags_type:SHOW AND tags_genres:SERIALI').replace('11','fq=tags_type:SHOW AND tags_genres:NOVINI').replace('12','fq=tags_type:SHOW AND tags_genres:PREDAVANIYA').replace('13','fq=tags_type:SHOW AND tags_genres:PUBLITSISTIKA').replace('14','fq=tags_type:SHOW AND tags_genres:SPORT').replace('15','fq=tags_type:SHOW AND tags_genres:KONTSERTI').replace('16','fq=tags_type:SHOW AND tags_genres:RIALITI')
		#Индексиране
		if 'FILM' in url:
			response = requests.get('https://neulioneumtsolrc-a.akamaihd.net/solr/eumt_program/novaplay/usersearch?'+url+'&rows=5000&start=0&fl=catId,pid,id,name,image,description,runtime,seoName,show,episodes,season&wt=json', headers=novaplay_headers)
			jsonrsp = response.json()
		
			#Списък на филмите
			for ttls in range(0, len(jsonrsp['response']['docs'])):
				#Обложка
				try:
					cover = 'https://neulioneumt-a.akamaihd.net/u/eumt/novaplay/thumbs/'+jsonrsp['response']['docs'][ttls]['image']
				except:
					cover = md+'DefaultFolder.png'
				xbmcplugin.setContent(int(sys.argv[1]), 'movie')
				addLink(jsonrsp['response']['docs'][ttls]['name'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][ttls]['pid']),jsonrsp['response']['docs'][ttls]['description'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][ttls]['runtime']),5,cover)
		else:
			response = requests.get('https://neulioneumtsolrc-a.akamaihd.net/solr/eumt_category/novaplay/usersearch?'+url+'&rows=5000&start=0&fl=catId,pid,id,name,image,description,seoName,show,episodes,season&wt=json', headers=novaplay_headers)
			jsonrsp = response.json()
			
			#Списък на директориите
			for ttls in range(0, len(jsonrsp['response']['docs'])):
				#Обложка
				try:
					cover = 'https://neulioneumt-a.akamaihd.net/u/eumt/novaplay/thumbs/categories/'+jsonrsp['response']['docs'][ttls]['image']
				except:
					cover = md+'DefaultFolder.png'
				addDir(jsonrsp['response']['docs'][ttls]['name'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][ttls]['catId']),jsonrsp['response']['docs'][ttls]['description'].encode('utf-8', 'ignore'),3,cover)




#Разлистване на сезоните
def INDEXSEASONS(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'season')
		response = requests.get('https://neulioneumtsolrc-a.akamaihd.net/solr/eumt_category/novaplay/usersearch?fq=parentId:'+url+'&rows=5000&fl=catId,name,seoName,show,episodes,season&sort=rank%20desc&wt=json', headers=novaplay_headers)
		jsonrsp = response.json()
		
		for sn in range(0, len(jsonrsp['response']['docs'])):
			addDir(jsonrsp['response']['docs'][sn]['name'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][sn]['catId']),jsonrsp['response']['docs'][sn]['name'].encode('utf-8', 'ignore'),4,md+'DefaultFolder.png')
		
		
		
#Разлистване на епизодите
def INDEXEPISODES(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'episode')
		response = requests.get('https://neulioneumtsolrc-a.akamaihd.net/solr/eumt_program/novaplay/usersearch?fq=tags_type:EPISODE AND catId:'+url+' AND releaseDate:[* TO NOW]&start=0&rows=5000&fl=pid,name,seoName,image,episode,show,showTitle,description,runtime&wt=json', headers=novaplay_headers)
		jsonrsp = response.json()
		
		for en in range(0, jsonrsp['response']['numFound']):
			#Обложка
			try:
				cover = 'https://neulioneumt-a.akamaihd.net/u/eumt/novaplay/thumbs/'+jsonrsp['response']['docs'][en]['image']
			except:
				cover = md+'DefaultMovies.png'
			addLink(jsonrsp['response']['docs'][en]['name'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][en]['pid']),jsonrsp['response']['docs'][en]['description'].encode('utf-8', 'ignore'),str(jsonrsp['response']['docs'][en]['runtime']),5,cover)

	


#Отваряне на видео
def VIDEOLINKS(url):
		try:
			name, adres, cover = url.split("@")
			plot = ''
			duration = ''
			#Възпроизвеждане на Nova TV
			response = requests.get('https://play.nova.bg/service/publishpoint?type=channel&id='+adres+'&format=json', headers=novaplay_headers)
			jsonrsp = response.json()
			
			li = xbmcgui.ListItem(iconImage=cover, thumbnailImage=cover, path=jsonrsp['path']+'|User-Agent=stagefright&X-Forwarded-For=54.72.239.169')
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		except:
			#stream
			response = requests.get('https://play.nova.bg/service/publishpoint?type=video&id='+url+'&format=json', headers=novaplay_headers)
			jsonrsp = response.json()
			cover = md+'DefaultStudios.png'
			adres = jsonrsp['path']
			
			#plot, coverart
			response2 = requests.get('https://neulioneumtsolrc-a.akamaihd.net/solr/eumt_program/novaplay/usersearch?fq=pid:'+url+'&start=0&rows=5000&fl=pid,name,seoName,image,episode,show,showTitle,description,runtime&wt=json', headers=novaplay_headers)
			jsonrsp2 = response2.json()
			try:
				name = jsonrsp2['response']['docs'][0]['name'].encode('utf-8', 'ignore')
				plot = jsonrsp2['response']['docs'][0]['description'].encode('utf-8', 'ignore')
				duration = str(jsonrsp2['response']['docs'][0]['runtime'])
				cover = 'https://neulioneumt-a.akamaihd.net/u/eumt/novaplay/thumbs/'+jsonrsp2['response']['docs'][0]['image']
			except:
				cover = md+'DefaultMovies.png'
		
			#Възпроизвеждане на видеата
			adres = adres.replace('https://stream.novatv.bg/','http://videobg.novatv.bg/')
			li = xbmcgui.ListItem(iconImage=cover, thumbnailImage=cover, path=adres)
			li.setInfo('video', { 'title': name, "duration": duration, "plot": plot })
			try:
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			except:
				xbmcgui.Dialog().ok('Грешка', 'Видеото не е достъпно за гледане ! Код на грешката: '+url)



#Търсене на предаване
def SEARCH():
		keyb = xbmc.Keyboard(search_string, 'Търсачка на предавания')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			searchText=searchText.replace(' ','+')
			if searchText == "":
				addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','','',md+'DefaultFolderBack.png')
			else:
				#Записване на заявката за търсене в настройките
				__settings__.setSetting('lastsearch', searchText)
			url= 'q='+searchText+'%20AND%20releaseDate:[*%20TO%20NOW]'
			url = url.encode('utf-8')
			INDEXCAT(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','','',md+'DefaultFolderBack.png')


def addLink(name,url,plot,duration,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
		liz.setInfo( type="Video", infoLabels={ "title": name, "duration": duration, "plot": plot } )
		liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
		liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		
		contextmenu = []
		contextmenu.append(('Информация', 'XBMC.Action(Info)'))
		liz.addContextMenuItems(contextmenu)
		
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok


def addDir(name,url,plot,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
	
	if len(plot)>0:
		contextmenu = []
		contextmenu.append(('Информация', 'XBMC.Action(Info)'))
		liz.addContextMenuItems(contextmenu)
	
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok



def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass



if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEXCAT(url)

elif mode==2:
		SEARCH()

elif mode==3:
		INDEXSEASONS(url)

elif mode==4:
		INDEXEPISODES(url)
		
elif mode==5:
		VIDEOLINKS(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
