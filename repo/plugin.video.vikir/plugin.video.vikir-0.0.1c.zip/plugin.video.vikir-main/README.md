# Viki kodi addon

This is a kodi addon for the streaming website Viki.

---------------------------------------------------------------------------------
This addon need an account (a free account is enough) to work.
---------------------------------------------------------------------------------
What the addon can do  :

- [X] Playing content (including drm protect content)
- [X] Getting information in fonction of the language (if possible)
- [ ] Manage account data in the addon

---------------------------------------------------------------------------------
*It's not an official addon and it's not affiliated with Viki.*