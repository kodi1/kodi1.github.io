plugin.program.bscfusion
======================
It is not official addon from provider.
It was made just for fun.
You were warned.

Plugin can be installed via repo:
https://github.com/kodi1/kodi1.github.io/releases/download/v0.0.1/repo.bg.plugins.zip

You need a tvheadend running.

Run ./map_to_hts.py localhost localhost

Use Tvheadend PVR client addon for Kodi
