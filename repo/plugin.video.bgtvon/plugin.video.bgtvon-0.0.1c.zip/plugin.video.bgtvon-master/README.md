# plugin.video.bgtvon version 6.0.1
Kodi addon to watch tv streams from http://www.bgtv-on.com/. An account is required. 

Readme for Kodi bgtv-on.com plugin created by zinobg@gmail.com

I created this addon to be able to watch online TV via Kodi on my Raspberry pi3. 
It is tested as well on Kodi for Windows

How to install:

1. Copy the zip file plugin.video.bgtvon.zip to a directory, where Kodi server has access to
	Windows -> <USERDIR>\AppData\Roaming\XBMC\addons\packages\ 
	Linux/OpenElec/LibreElec -> ~/.kodi/addons/packages/
2. Run Kodi and go to System -> Add-ons
3. From Add-ons menu select -> Install from zip file
4. Select the zip file plugin.video.bgtvon.zip
5. BGTV-ON add-on will appear in the video addon list
6. Before you run it you have to provide login information
	For this select the addon in the list and the PC use right mouse button 
on AppleTV long press Menu on the remote control
