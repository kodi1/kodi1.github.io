# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import HTMLParser
import feedparser
import random
import urlresolver

xbmc.executebuiltin("xbmc.PlayerControl(RepeatOff)")

#   plugin://plugin.video.youtube/play/?video_id=[VID]
#   plugin://plugin.video.youtube/playlist/<PLAYLIST_ID>/
#   plugin://plugin.video.youtube/channel/[CID]/
#   plugin://plugin.video.youtube/user/[NAME]/
#   plugin://plugin.video.vimeo/play/?video_id=[VID]

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.brigada'
__Addon = xbmcaddon.Addon(__addon_id__)

UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'
MUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D201 Safari/9537.53'
thumbnail = 'DefaultVideo.png'

headers={
                    'Origin' : 'http://ucha.se',
                    'Accept-Language' : 'bg,en-US;q=0.8,en;q=0.6',
                    'User-Agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/43.0.2357.130 Chrome/43.0.2357.130 Safari/537.36',
                    'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Accept' : '*/*',
                    'Referer' : 'http://ucha.se/videos/',
                    'X-Requested-With' : 'XMLHttpRequest',
                    'Connection' : 'keep-alive',
                    'DNT' : '1'
                }

#Меню с директории в приставката
def CATEGORIES():
        xbmc.executebuiltin("xbmc.playercontrol(RepeatOff)")
        addDir('Български филми от BGTV2.BLOGSPOT.COM','http://bgtv2.blogspot.com/',4,'http://upload.wikimedia.org/wikipedia/commons/8/87/Bulgariafilm.png')
        addDir('Български филми и футбол от POLOMA.NET','http://poloma.net/',1,'http://poloma.net/photo/poloma.jpg')
        SEND2YTCLIP('Български филми от BULGARIANFILM.COM','zlatenfond','http://www.bulgarianfilm.com/images/bilder/logo_oben_50.jpg')
        addDir('Български филми и детски песни от CORENI.NET','http://coreni.net',14,'http://coreni.net/wp-content/uploads/2015/01/Coreni_logo.png')
        addDir('Български филми и сериали за деца от TVHLAPETA.BNT.BG','http://epg.kodibg.org/brigadahlapeta.php',6,'http://tvhlapeta.bnt.bg/images/tvhlapeta-logo.png')
        addDir('Български приказки, песнички и радиотеатър от GRAMOFONCHE.CHITANKA.INFO','gramofonche',32,'http://vk.com/images/gifts/256/276.jpg')
        addDir('Български приказки от DECHICA.COM','bgprikazki',12,'http://www.dechica.com/Documents/000000632/BGBG/bg_narodni.jpg')
        #addDir('Български видеоуроци от UCHA.SE','uchase',17,'http://ucha.se/public/images/uchase-logo.png')
        CHANTUBE('Български видеоуроци от NAU4I.ME','UCpHITy7CGe-h_fXng03bZrw','https://yt3.ggpht.com/-TMyhvQnl4P4/AAAAAAAAAAI/AAAAAAAAAAA/UkweUQVnd9c/s100-c-k-no/photo.jpg')
        #addDir('Български видеоуроци от SCHOOLPEDIA.ORG','sp',2,'https://schoolpedia.org/img/logo.png')
        CHANTUBE('Български видеоуроци от TELERIKACADEMY.COM','UCLC-vbm7OWvpbqzXaoAMGGw','https://yt3.ggpht.com/-69C3oNxEcv4/AAAAAAAAAAI/AAAAAAAAAAA/l5nRqSMobgc/s900-c-k-no/photo.jpg')
        CHANTUBE('Български видеоуроци от BG.KHANACADEMY.ORG','UCHNKwF_1cac1ebnOtrdXwVw','https://www.khanacademy.org/images/khan-logo-vertical-transparent.png')
        addDir('Български видеоуроци по английски език от BiTELEVISION.COM','5627058/events/3039729',35,'http://logos.kodibg.org/bit.png')
        SEND2YTCLIP('Български видеоуроци по английски език от CLASSROOM.BG','ClassroomBg','http://classroom.bg/images/logo.png')
        addDir('Българската история разказана от VIVAHISTORY.BG','http://vivahistory.bg',24,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
        addDir('История славянобългарская - прочит от ISTORIATA.BG','nerazumni',23,'http://player.myshared.ru/805346/data/images/img29.png')
        addDir('Български аудиокниги от ZAKNIGI.COM','zaknigi',28,'http://zaknigi.com/image/book.png')
        addDir('Български аудиоразкази от AVTORI.COM','avtori',20,'http://www.avtori.com/images/new_logo.png')
        addDir('Български подкасти','bgpodcast',9,'http://nursejournal.org/files/2012/12/podcast-headphones.png')
        addDir('Български радиа','bgradio',8,'http://gtrk-saratov.ru/images/cms/data/2013/march2013/89/uzn_1368814232.jpg')
        CHANTUBE('Българска музика от BGESTRADA.COM','UCJhbyIJNHjGrstWIIVr149Q','http://www.bgestrada.com/bgestrada/sites/default/files/litejazz_logo.png')
        #addDir('Българска телевизия /само официални излъчвания/','http://epg.kodibg.org/brigadatv.php',6,'http://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Bnt1_history.png/600px-Bnt1_history.png')
        addDir('Българска телевизия /само официални излъчвания/','http://andromeda.eu.org/tv/2ftp/brigadatv.php',6,'http://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Bnt1_history.png/600px-Bnt1_history.png')



#Списък на предаванията/филмите в BGTV2
def INDEXCATBGTV2(showid):
        thumbnail = 'DefaultVideo.png'
        #url = 'http://sites.google.com/site/apitvbg/shadowbbox.js' #cifri abvgd
        #url = 'http://sites.google.com/site/apitvbg/shadowex.js' #ejzik
        #url = 'http://sites.google.com/site/apitvbg/shadowlex.js' #klmno
        #url = 'http://sites.google.com/site/apitvbg/shadowp.js' #prs
        #url = 'http://sites.google.com/site/apitvbg/shadowpr.js' #s2 ^
        #url = 'http://sites.google.com/site/apitvbg/shadowvoz.js' #tufhtzsh6tiuia - problem s encodinga
        #url = 'http://sites.google.com/site/apitvbg/shadowscx.js' #kratki film - shorts i tv
        #url = 'http://sites.google.com/site/apitvbg/shadowan.js'
        
        #url = 'http://sites.google.com/site/apitvbg/shadowbox.js' cifri a-u
        #url = 'http://sites.google.com/site/apitvbg/shadowboz.js' prstufhc46uq
        #url = 'http://sites.google.com/site/apitvbg/google_api.js' shorts

        li = ['http://sites.google.com/site/apitvbg/shadowbox.js', 'http://sites.google.com/site/apitvbg/shadowboz.js', 'http://sites.google.com/site/apitvbg/google_api.js'] #a-ia + shorts
        for url in li:
            try:
                req = urllib2.Request(url)
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data=response.read()
                response.close()
                
                match= re.compile(' "(.+?)",.*:"(.+?)",').findall(data)
                pars = HTMLParser.HTMLParser()
                for href,name in match:
                    href=href.replace('https','http')
                    mn=pars.unescape(name).encode('utf-8', 'ignore') #<-работи на PC и андроид, но само с правилен енкодинг
                    if not ('nfc.bg' in href or 'iframe' in mn):
                        addLink(mn,href,3,thumbnail)
                        #print mn + ' ' + href + ' ' + thumbnail
            except:
                pass










#BG приказки
def PRIKAZKI(url):
        addLink('Педя човек - лакът брада','http://player.vimeo.com/video/48138586',11,'http://dechica.com/Documents/000000826/BGBG/pedia_chovek.jpg')
        addLink('Лудориите на козлето Боц','http://player.vimeo.com/video/40570006',11,'http://www.dechica.com/Documents/000000801/BGBG/kozleto_botz.jpg')
        addLink('Неродена мома','http://player.vimeo.com/video/39467924',11,'http://www.dechica.com/Documents/000000775/BGBG/nerodena_moma.jpg')
        addLink('Главчо и царската дъщеря','http://player.vimeo.com/video/39467840',11,'http://www.dechica.com/Documents/000000774/BGBG/glavcho_i_carskata.jpg')
        addLink('Умното овчарче','http://player.vimeo.com/video/39394000',11,'http://www.dechica.com/Documents/000000768/BGBG/umnoto_ovcharche.jpg')
        addLink('Сребърният елен','http://player.vimeo.com/video/38650615',11,'http://www.dechica.com/Documents/000000716/BGBG/srebyrniia_elen.jpg')
        addLink('Дванадесетте месеца','http://player.vimeo.com/video/38650591',11,'http://www.dechica.com/Documents/000000715/BGBG/dvanadesette_meseca.jpg')
        addLink('Тримата братя и златната ябълка','http://player.vimeo.com/video/38649421',11,'http://www.dechica.com/Documents/000000714/BGBG/trimata_bratia.jpg')
        addLink('Златното момиче','http://player.vimeo.com/video/38093321',11,'http://www.dechica.com/Documents/000000688/BGBG/zlatnoto_momiche.jpg')
        addLink('Полски зайци','http://player.vimeo.com/video/38093212',11,'http://www.dechica.com/Documents/000000685/BGBG/polski_zaici.jpg')
        addLink('Кума Лиса и Ежко Бежко','http://player.vimeo.com/video/38031437',11,'http://www.dechica.com/Documents/000000683/BGBG/kuma_lisa_i_ezhko_bezhko.jpg')
        addLink('Зайо Байо и Ежко Бежко','http://player.vimeo.com/video/37958849',11,'http://www.dechica.com/Documents/000000676/BGBG/zaio_baio_ezhko_bezhko.jpg')
        addLink('Кума Лиса кръстница','http://player.vimeo.com/video/37957561',11,'http://www.dechica.com/Documents/000000675/BGBG/kuma_lisa_krustnica.jpg')
        addLink('Магарето','http://player.vimeo.com/video/37953095',11,'http://www.dechica.com/Documents/000000669/BGBG/magareto.jpg')
        addLink('По-горе от нас','http://player.vimeo.com/video/37952701',11,'http://www.dechica.com/Documents/000000668/BGBG/po_gore_ot_nas.jpg')
        addLink('Защо заекът има къса опашка','http://player.vimeo.com/video/37952032',11,'http://www.dechica.com/Documents/000000667/BGBG/zashto_zaeka.jpg')
        addLink('Врабчо','http://player.vimeo.com/video/37894859',11,'http://www.dechica.com/Documents/000000664/BGBG/vrabcho.jpg')
        addLink('Дядовата ръкавичка','http://player.vimeo.com/video/37893020',11,'http://www.dechica.com/Documents/000000663/BGBG/dqdovata_rukavichka.jpg')
        addLink('Щъркелът и жабите','http://player.vimeo.com/video/37892901',11,'http://www.dechica.com/Documents/000000662/BGBG/shturkela_i_jabite.jpg')
        addLink('Болен здрав носи','http://player.vimeo.com/video/37892326',11,'http://www.dechica.com/Documents/000000661/BGBG/bolen_zdrav_nosi.jpg')
        addLink('Лисицата и щъркелът','http://player.vimeo.com/video/37891326',11,'http://www.dechica.com/Documents/000000659/BGBG/lisicata_i_shturkelut.jpg')
        addLink('Лисицата и гъските','http://player.vimeo.com/video/37891317',11,'http://www.dechica.com/Documents/000000658/BGBG/lisicata_i_gyskite.jpg')
        addLink('Баба за дренки','http://player.vimeo.com/video/37891307',11,'http://www.dechica.com/Documents/000000657/BGBG/baba_za_drenki.jpg')
        addLink('Сливи за смет','http://player.vimeo.com/video/37889757',11,'http://www.dechica.com/Documents/000000655/BGBG/slivi_za_smet.jpg')
        addLink('Косът помага','http://player.vimeo.com/video/37851395',11,'http://www.dechica.com/Documents/000000654/BGBG/kosut_pomaga.jpg')
        addLink('Царкинята и барабанчето','http://player.vimeo.com/video/37800212',11,'http://www.dechica.com/Documents/000000653/BGBG/carkiniata_i_barabancheto.gif')
        addLink('Куцото петле','http://player.vimeo.com/video/37790843',11,'http://www.dechica.com/Documents/000000651/BGBG/kucoto_petle.jpg')
        addLink('Трите самовилски коня','http://player.vimeo.com/video/43040978',11,'http://dechica.com/Documents/000000827/BGBG/trite_samovilski_konia.jpg')
        addLink('Меко казано','http://player.vimeo.com/video/41756007',11,'http://www.dechica.com/Documents/000000817/BGBG/meko_kazano.jpg')
        addLink('Тайната сила на мечока Пепо','http://player.vimeo.com/video/41755991',11,'http://www.dechica.com/Documents/000000816/BGBG/tainata_sila.jpg')
        addLink('Два пищова и едно куцо магаре','http://player.vimeo.com/video/41755965',11,'http://www.dechica.com/Documents/000000815/BGBG/dva_pishtova.jpg')
        addLink('Винтчето Прокопчо','http://player.vimeo.com/video/40954845',11,'http://www.dechica.com/Documents/000000807/BGBG/vintcheto_prokopcho.jpg')
        addLink('Северни приказки','http://player.vimeo.com/video/40570929',11,'http://www.dechica.com/Documents/000000806/BGBG/severni_prikazki.jpg')
        addLink('Пук','http://player.vimeo.com/video/40215849',11,'http://www.dechica.com/Documents/000000796/BGBG/puk.jpg')
        addLink('Копче за сън','http://player.vimeo.com/video/40215815',11,'http://www.dechica.com/Documents/000000795/BGBG/kopche_za_sun.jpg')
        addLink('Голямото имане','http://player.vimeo.com/video/38909936',11,'http://www.dechica.com/Documents/000000725/BGBG/goliamoto_imane.jpg')
        addLink('Момче и вятър','http://player.vimeo.com/video/38093182',11,'http://www.dechica.com/Documents/000000684/BGBG/momche_i_vqtur.jpg')
        addLink('Клан, недоклан','http://player.vimeo.com/video/38031364',11,'http://www.dechica.com/Documents/000000682/BGBG/klan_nedoklan.jpg')
        addLink('Топлата ръкавичка','http://player.vimeo.com/video/37960341',11,'http://www.dechica.com/Documents/000000677/BGBG/toplata_rukavichka.jpg')
        addLink('Дядо вади ряпа','http://player.vimeo.com/video/37852445',11,'http://www.dechica.com/Documents/000000656/BGBG/dyado_vadi_ryapa.jpg')
        addLink('Косе Босе','http://player.vimeo.com/video/37676502',11,'http://www.dechica.com/Documents/000000647/BGBG/kose_bose.jpg')










#BG подкасти на живо по интернет
def PODCAST(url):
        addDir('BiT - акценти в българските новини отвъд атлантика','http://www.bitelevision.com/feed/',7,'http://logos.kodibg.org/bit.png')
        addDir('AXN Player - цели епизоди и акценти от AXN Network','http://feed.theplatform.com/f/spe/PEvSp9pxiE5T/?form=json&byContent=byFormat=mpeg4&range=1-100&count=true&fileFields=bitrate,duration,format,url',38,'http://www.thelogodb.com/images/media/logo/yusrru1445113463.png')
        addDir('DW - новините от света с германска перспектива','http://feed43.com/1550710417215715.xml',36,'http://www.thelogodb.com/images/media/logo/wtqyxv1444822994.png')
        addDir('Предприемачите - стартъп разговор за финанси и икономика','http://predpriemachite.com/category/startup-razgovor/feed/',7,'http://predpriemachite.com/wp-content/uploads/powerpress/Startup_razgovor.jpg')
        addDir('Предприемачите - мисли за пари на млади български експерти','http://predpriemachite.com/category/misli-za-pari/feed/',7,'http://predpriemachite.com/wp-content/uploads/powerpress/logomisli300.jpg')
        addDir('Бизнес, мотивация и личностно развитие - съвети и стратегии','http://blog.ivodimitrov.pro/feed/podcast/',7,'http://blog.ivodimitrov.pro/wp-content/uploads/2014/10/Podcast-Artwork2.png')
        SEND2YTCLIP('JobTiger - търсите работа или стаж? Ние ще планираме вашето кариерно развитие','JobTigerChannel','http://www.jobtiger.bg/images/slider-logo.png')
        SEND2YTCLIP('WishBox - мотивация и кариерно развитие на младежите','mywishbox','http://wishbox.org/themes/wishbox/images/logo.png')
        addDir('Nerds2Nerds - ИТ, програмиране, наука и всичко geeky','http://www.nerds2nerds.com/?feed=rss2',7,'http://2014.tuxcon.mobi/themes/yellow-swan/img/nerds2nerds.png')
        addDir('Tech Baloon - новини от областта на информационните технологии','http://techballoon.net/category/podcast/feed/',7,'http://techballoon.net/wp-content/uploads/2013/01/TechBalloon_No_gears.jpg')
        SEND2YTCLIP('Линукс За Българи - записи от конференции и ръководства','LinuxZaBulgari','http://www.unixstickers.com/image/cache/data/stickers/little-tux/littletux_bumper.sh-600x600.png')
        addDir('Gamers’ Voiceshop - гейминга като хоби, развлечение и професия','http://gamersvoiceshop.com/category/podcast/feed/',7,'http://pbs.twimg.com/profile_images/378800000811926970/404dbbffc559cbdd6a20099ea74ed71c_400x400.png')
        SEND2YTCLIP('NEXT TV - гейминг, музика, кино и интернет','nexttvbulgaria','http://cdn.akamai.steamstatic.com/steamcommunity/public/images/avatars/63/63dd8e36b57e03a59f46cd398430b55a080c48ca_full.jpg')
        SEND2YTCLIP('БГ Лов - гласът на ловеца, оръжия и такъми','BGLovcom','http://www.bglov.com/img/logo.gif')
        addDir('Без жичка - съвременните технологии в помощ на хората с увредено зрение','http://bezjichka.com/feed/podcast',7,'http://www.iconsdb.com/icons/preview/black/wireless-xxl.png')
        addDir('Всичко, дори това - аудио разкази от Петър Тушков','http://feed43.com/7601682426443243.xml',7,'http://eet-live.com/sites/default/files/eet-live.com_logo_blue_0.png')
        SEND2YTCLIP('Общество „От Извора“ - жива вода за жадни души','otizvora','http://www.otizvora.com/wp-content/uploads/2012/08/otizvora_logo_stylebook.jpg')
        CHANTUBE('Българска история - страданията и борбите, геройството и гордостта на българския род','UCAhDucdzaP9OPbbxxXREohA','http://www.bulgarianhistory.org/wp-content/uploads/BH-new-logo-square.png')
        SEND2YT('ЕПОХИ ТВ - историята-такава, каквато малко я познаваме','PLG4JmPC7RHsBDV-c_W9ldg5sKmpv6vC0t','https://i.ytimg.com/vi/7uGIJlgTxGU/mqdefault.jpg')
        SEND2YTCLIP('Friday Chopsticks (Радио Реакция) - азиатска музика и култура','FridayChopsticks','https://yt3.ggpht.com/-1WJESsiEv3s/AAAAAAAAAAI/AAAAAAAAAAA/Khj7r7MwsAE/s900-c-k-no/photo.jpg')
        SEND2YT('Пощенска кутия за приказки - разкази, изчитани от популярни личности','PLXFF7lu1nQ3t4kjxkcCSMqeMylAsZWrmg','http://oi63.tinypic.com/zusfnb.jpg')
        addDir('Фалшименто – музикално предаване за независима музика, инди','http://www.falshimento.com/feed',7,'http://www.falshimento.com/wp-content/uploads/2013/08/970287_10200312090747859_1519332404_n-640x426.jpg')
        SEND2YTCLIP('Типично - българският комедиен уеб сериал','CybertronicStudios','http://prikachi.com/images/876/8496876w.jpg')
        addDir('Indioteque - пътувания, партита, инди и алтернатив сцена','http://mixcloud-rss.georgipavlov.com/indioteque/mp3/20',7,'https://pbs.twimg.com/profile_images/1325887940/indioteque_logo_200X200_negative_400x400.jpg')
        addDir('BOYSCOUT - мода, дизайн, музика, събития, интересни личности','http://mixcloud-rss.georgipavlov.com/boyscoutmagazine/mp3/20',7,'http://boyscoutmag.com/wp-content/themes/boyscout/images/logo.png')
        CHANTUBE('Списание Амбиция - интервюта с успели българи в България и чужбина','UCphVAbEp-OxJcPs3SpVeC6w','http://ambicia.com/img/ambicia-logo-white.png')
        addDir('Elegant Touch - сетове на DJ Runo','http://soundfeed.preslav.me/feed/dj_runo/04f692',7,'https://i1.sndcdn.com/avatars-000077084279-cj2qo2-t500x500.jpg')
        addDir('Traffic радио - най-добрата хаус и клубна музика','http://djbobbyd.podomatic.com/rss2.xml',7,'http://trafficradio.org/wp-content/uploads/badge.png')
        addDir('Tangra Mega Rock - рок радиото на България','http://feed43.com/4165318261647423.xml',7,'http://www.radiotangra.com/img/logo_tangra.png')
        addDir('Дарик радио - последните аудио материали','http://radio.dariknews.bg/rss.php?type=podcast',7,'http://darikradio.bg/img/logo.png')
        SEND2YTCLIP('БГ Радио - вашите любими български изпълнители','bgradiobg','http://www.bgradio.bg/themes/bgradio/images/logo.png')
        CHANTUBE('Тракия Вижън - късометражни филми и скечове от Теодор Димитров','UClAbaEIoaAjEZqqB1L6XmdQ','http://image.ibb.co/ix5qTk/12045239_1669166946634836_232094459314697672_o.jpg')
        CHANTUBE('Агенция ПИК - шокиращите новини от ПИК ТВ','UCLio4Mi7R5d8wHvESJoZJmA','http://i.pik.bg/img2/logo.png')
        CHANTUBE('Информационна агенция БГНЕС - новини от България и чужбина','UCNkRuL_6Jqtwx8yfTJx0yfQ','http://bgnes.com/images/logo.png')
        CHANTUBE('Медиатор - асоциация на европейските журналисти','UCGOaDVmRTCJNO-xw60TFJZQ','http://www.aej-bulgaria.org/bul/images/logo.png')
        CHANTUBE('Бивол - журналистически разследвания по най-горещите теми','UCMDBwbbOKMfMjC7a5_N4oaw','http://pbs.twimg.com/profile_images/378800000811075540/6be410bfefb1db3e381722daf84ccffa_400x400.jpeg')
        addDir('airball - новини, анализи и коментари от света на НБА','http://feeds.soundcloud.com/users/soundcloud:users:219247712/sounds.rss',7,'http://images.airball.bg//2016/05/podcast-last.png')
        addDir('Честни разговори за мръсни теми - интимност, фетиши /18+/','http://www.f-bg.org/podcast',7,'http://www.f-bg.org/wp-content/themes/bft2.0/images/alogo1.png')








 #Видове уроци от UCHA.SE
def UCHASE():
        thumbnail='DefaultFolder.png'
        addDir('Забавни видео уроци (без категория)','category=29&class_num=0',18,thumbnail)

        addDir('Видео уроци по Химия за 7 клас','category=26&class_num=7',18,thumbnail)
        addDir('Видео уроци по Химия за 8 клас','category=26&class_num=8',18,thumbnail)
        addDir('Видео уроци по Химия за 9 клас','category=26&class_num=9',18,thumbnail)
        addDir('Видео уроци по Химия за 10 клас','category=26&class_num=10',18,thumbnail)

        addDir('Видео уроци по Химия за кандидат-студенти','category=35&class_num=0',18,thumbnail)

        addDir('Видео уроци по Математика за 1 клас','category=28&class_num=1',18,thumbnail)
        addDir('Видео уроци по Математика за 2 клас','category=28&class_num=2',18,thumbnail)
        addDir('Видео уроци по Математика за 3 клас','category=28&class_num=3',18,thumbnail)
        addDir('Видео уроци по Математика за 4 клас','category=28&class_num=4',18,thumbnail)
        addDir('Видео уроци по Математика за 5 клас','category=28&class_num=5',18,thumbnail)
        addDir('Видео уроци по Математика за 6 клас','category=28&class_num=6',18,thumbnail)
        addDir('Видео уроци по Математика за 7 клас','category=28&class_num=7',18,thumbnail)
        addDir('Видео уроци по Математика за 8 клас','category=28&class_num=8',18,thumbnail)
        addDir('Видео уроци по Математика за 9 клас','category=28&class_num=9',18,thumbnail)
        addDir('Видео уроци по Математика за 10 клас','category=28&class_num=10',18,thumbnail)
        addDir('Видео уроци по Математика за 11 клас','category=28&class_num=11',18,thumbnail)
        addDir('Видео уроци по Математика за 12 клас','category=28&class_num=12',18,thumbnail)

        addDir('Видео уроци по Информационни технологии за 5 клас','category=52&class_num=5',18,thumbnail)

        addDir('Видео уроци по Програмиране','category=38&class_num=0',18,thumbnail)

        addDir('Предприемачество','category=50&class_num=0',18,thumbnail)

        addDir('Видео уроци по Физика за 7 клас','category=31&class_num=7',18,thumbnail)
        addDir('Видео уроци по Физика за 8 клас','category=31&class_num=8',18,thumbnail)
        addDir('Видео уроци по Физика за 9 клас','category=31&class_num=9',18,thumbnail)
        addDir('Видео уроци по Физика за 10 клас','category=31&class_num=10',18,thumbnail)
        addDir('Видео уроци по Физика за 11 клас','category=31&class_num=11',18,thumbnail)
        addDir('Видео уроци по Физика за 12 клас','category=31&class_num=12',18,thumbnail)

        addDir('Видео уроци по Биология за 7 клас','category=32&class_num=7',18,thumbnail)
        addDir('Видео уроци по Биология за 8 клас','category=32&class_num=8',18,thumbnail)
        addDir('Видео уроци по Биология за 9 клас','category=32&class_num=9',18,thumbnail)
        addDir('Видео уроци по Биология за 10 клас','category=32&class_num=10',18,thumbnail)

        addDir('Видео уроци по История за 5 клас','category=34&class_num=5',18,thumbnail)
        addDir('Видео уроци по История за 6 клас','category=34&class_num=6',18,thumbnail)
        addDir('Видео уроци по История за 7 клас','category=34&class_num=7',18,thumbnail)
        addDir('Видео уроци по История за 8 клас','category=34&class_num=8',18,thumbnail)
        addDir('Видео уроци по История за 9 клас','category=34&class_num=9',18,thumbnail)
        addDir('Видео уроци по История за 10 клас','category=34&class_num=10',18,thumbnail)
        addDir('Видео уроци по История за 11 клас','category=34&class_num=11',18,thumbnail)

        addDir('Видео уроци по География за 5 клас','category=37&class_num=5',18,thumbnail)
        addDir('Видео уроци по География за 6 клас','category=37&class_num=6',18,thumbnail)
        addDir('Видео уроци по География за 7 клас','category=37&class_num=7',18,thumbnail)
        addDir('Видео уроци по География за 8 клас','category=37&class_num=8',18,thumbnail)
        addDir('Видео уроци по География за 9 клас','category=37&class_num=9',18,thumbnail)
        addDir('Видео уроци по География за 10 клас','category=37&class_num=10',18,thumbnail)

        addDir('Видео уроци по Български език за 1 клас','category=36&class_num=1',18,thumbnail)
        addDir('Видео уроци по Български език за 2 клас','category=36&class_num=2',18,thumbnail)
        addDir('Видео уроци по Български език за 3 клас','category=36&class_num=3',18,thumbnail)
        addDir('Видео уроци по Български език за 4 клас','category=36&class_num=4',18,thumbnail)
        addDir('Видео уроци по Български език за 5 клас','category=36&class_num=5',18,thumbnail)
        addDir('Видео уроци по Български език за 6 клас','category=36&class_num=6',18,thumbnail)
        addDir('Видео уроци по Български език за 7 клас','category=36&class_num=7',18,thumbnail)

        addDir('Видео уроци по Литература за 5 клас','category=45&class_num=5',18,thumbnail)
        addDir('Видео уроци по Литература за 6 клас','category=45&class_num=6',18,thumbnail)
        addDir('Видео уроци по Литература за 7 клас','category=45&class_num=7',18,thumbnail)
        addDir('Видео уроци по Литература за 8 клас','category=45&class_num=8',18,thumbnail)
        addDir('Видео уроци по Литература за 9 клас','category=45&class_num=9',18,thumbnail)
        addDir('Видео уроци по Литература за 10 клас','category=45&class_num=10',18,thumbnail)
        addDir('Видео уроци по Литература за 11 клас','category=45&class_num=11',18,thumbnail)
        addDir('Видео уроци по Литература за 12 клас','category=45&class_num=12',18,thumbnail)

        addDir('Видео уроци по Човекът и природата за 3 клас','category=39&class_num=3',18,thumbnail)
        addDir('Видео уроци по Човекът и природата за 4 клас','category=39&class_num=4',18,thumbnail)
        addDir('Видео уроци по Човекът и природата за 5 клас','category=39&class_num=5',18,thumbnail)
        addDir('Видео уроци по Човекът и природата за 6 клас','category=39&class_num=6',18,thumbnail)

        addDir('Видео уроци по Човекът и обществото за 3 клас','category=42&class_num=3',18,thumbnail)
        addDir('Видео уроци по Човекът и обществото за 4 клас','category=42&class_num=4',18,thumbnail)

        addDir('Видео уроци по Околен свят за 2 клас','category=47&class_num=2',18,thumbnail)

        addDir('Видео уроци по Роден край за 1 клас','category=46&class_num=1',18,thumbnail)

        addDir('Видео уроци по Музика','category=43&class_num=0',18,thumbnail)

        addDir('Български език за българи в чужбина за 1 клас','category=51&class_num=1',18,thumbnail)
        addDir('Български език за българи в чужбина за 2 клас','category=51&class_num=2',18,thumbnail)
        addDir('Български език за българи в чужбина за 3 клас','category=51&class_num=3',18,thumbnail)
        addDir('Български език за българи в чужбина за 4 клас','category=51&class_num=4',18,thumbnail)

        addDir('Видео уроци по Английски език (начално ниво) за 2 клас','category=40&class_num=2',18,thumbnail)
        addDir('Видео уроци по Английски език (начално ниво) за 3 клас','category=40&class_num=3',18,thumbnail)
        addDir('Видео уроци по Английски език (начално ниво) за 4 клас','category=40&class_num=4',18,thumbnail)
        addDir('Видео уроци по Английски език (начално ниво) за 5 клас','category=40&class_num=5',18,thumbnail)
        addDir('Видео уроци по Английски език (начално ниво) за 6 клас','category=40&class_num=6',18,thumbnail)
        addDir('Видео уроци по Английски език (начално ниво) за 7 клас','category=40&class_num=7',18,thumbnail)
        addDir('Видео уроци по Английски език (начално ниво) за 8 клас','category=40&class_num=8',18,thumbnail)

        addDir('Видео уроци по Английски език (Средно ниво)','category=30&class_num=0',18,thumbnail)

        addDir('Видео уроци по Немски език ниво A1','category=41&class_num=1',18,thumbnail)
        addDir('Видео уроци по Немски език ниво A2','category=41&class_num=2',18,thumbnail)
        addDir('Видео уроци по Немски език ниво B1','category=41&class_num=3',18,thumbnail)
        addDir('Видео уроци по Немски език ниво B2','category=41&class_num=4',18,thumbnail)

        addDir('Видео уроци по Руски език ниво A1','category=53&class_num=1',18,thumbnail)
        addDir('Видео уроци по Руски език ниво A2','category=53&class_num=2',18,thumbnail)
        addDir('Видео уроци по Руски език ниво B1','category=53&class_num=3',18,thumbnail)
        addDir('Видео уроци по Руски език ниво B2','category=53&class_num=4',18,thumbnail)

        addDir('Видео уроци по Френски език ниво A1','category=49&class_num=1',18,thumbnail)
        addDir('Видео уроци по Френски език ниво A2','category=49&class_num=2',18,thumbnail)
        addDir('Видео уроци по Френски език ниво B1','category=49&class_num=3',18,thumbnail)
        addDir('Видео уроци по Френски език ниво B2','category=49&class_num=4',18,thumbnail)

        addDir('Видео уроци по Испански език ниво A1','category=48&class_num=1',18,thumbnail)
        addDir('Видео уроци по Испански език ниво A2','category=48&class_num=2',18,thumbnail)
        addDir('Видео уроци по Испански език ниво B1','category=48&class_num=3',18,thumbnail)
        addDir('Видео уроци по Испански език ниво B2','category=48&class_num=4',18,thumbnail)








#BG радиа на живо по интернет
def RADIO(url):
        addLink('Дарик радио','http://darikradio.by.host.bg:8000/S2-128',5,'http://radio.dariknews.bg/img/logo.png')
        addLink('БГ Радио','http://149.13.0.81/bgradio.aac',5,'http://media.metacast.eu/pictures/07_2015/lVGzkB8cUw9iJIOudM6W-5318.png')
        addLink('БГ Радио Естрада','http://149.13.0.81/bgestrada.aac',5,'http://media.metacast.eu/pictures/07_2015/F8EA4iJRTqOzLl9oMsZ5-5319.png')
        addLink('БГ Радио Хип-Хоп','http://149.13.0.81/bghiphop.aac',5,'http://media.metacast.eu/pictures/07_2015/OPJR8bSEqpGC4ev9Zrx6-5320.png')
        addLink('БГ Радио Коледа','http://stream.radioreklama.bg:80/bgradio-koleda.aac',5,'http://media.metacast.eu/pictures/11_2015/7JiFPzK6f85U3ro0j2tB-8273.png')
        addLink('Програма Хоризонт - БНР','http://stream.bnr.bg:8002/horizont.mp3',5,'http://bnr.bg/img/logos/horizont.png')
        addLink('Програма Христо Ботев - БНР','http://stream.bnr.bg:8003/botev.mp3',5,'http://bnr.bg/img/logos/hristobotev.png')
        addLink('Музикален канал БГпоп на РАДИО БИНАР - БНР','rtmp://pri.cdn.bg:2003/fls/_definst_/5.stream pageUrl=http://binar.bg/player/bgpop timeout=12',5,'http://files.binar.bg/media/2014/03/91-r1-c1.jpg')
        addLink('Музикален канал Фолклор на РАДИО БИНАР - БНР','rtmp://pri.cdn.bg:2003/fls/_definst_/6.stream pageUrl=http://binar.bg/player/folk timeout=12',5,'http://files.binar.bg/media/2014/05/folk.jpg')
        addLink('Радио Татковина - радиото на българите по света','http://www.tatkovina.com:8000/bg',5,'http://www.tatkovina.com/images/crossroads1.gif')
        addLink('Народно радио "Наздраве" - народна музика','http://stream-bg.net:8020/narodno',5,'http://www.folkradionazdrave.com/images/nazdrave/horo.jpg')
        addLink('Фолк радио "Наздраве" - поп-фолк, народна музика и балкански ритми','http://stream-bg.net:8020/nazdrave',5,'http://www.folkradionazdrave.com/templates/nazdrave/images/logo.png')
        addLink('Радио Пайнер - модерен поп-фолк','http://pri.cdn.bg:2050/fls/planeta.stream/playlist.m3u8',5,'http://www.predavatel.com/bg/radio/payner.png')
        addLink('Дарк радио - БЪЛГАРСКА рок музика','http://dj.darkpj.com:8000',5,'http://preview.ibb.co/ex8RBv/20374633_893273510820517_651287322137122836_n.jpg')
        addLink('Радио FSB - Формация Студио Балкантон','http://50.7.96.210:8211',5,'http://fsb.bg/images/FSB-b.png')







#BGTV на живо по интернет
def LIVETV(url):
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())

        for tv in range(0, len(jsonrsp['streams'])):
            addLink(jsonrsp['streams'][tv]['title'].encode('utf-8', 'ignore'),jsonrsp['streams'][tv]['url'],jsonrsp['streams'][tv]['mode'],jsonrsp['streams'][tv]['cover'])



 #Извличане на стриймове от Evolink/CDNBG
def EVOLINK(name,url,iconimage):
        streemh = ''
        streem0 = ''
        streem1 = ''
        streem2 = ''

        #Select streamer
        streamer = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16'] #, '17', '18', '19', '20'
        ns = random.choice(streamer)

        if 'edge' in url:
            streemh = re.sub(r"edge\d", "edge" + ns, url)
            #streemh = url
        else:
            referrer, adres, port, token = url.split("-")

            #Заявка към страницата със стрийма
            req = urllib2.Request(adres)
            req.add_header('User-Agent', UA)
            req.add_header('Referer', referrer)
            response = urllib2.urlopen(req)
            data=response.read()
            response.close()
            #print 'EVOLINK: ' + data

            #Генерираме сами стрийма с нов сървър от loadbalancer-a
            try:
                matchh = re.compile('(//.*m3u8.{30,40})[\ \"\']').findall(data)
                for hls in matchh:
                    if 'clb' in hls:
                        streem0 = 'http:' + hls.replace('"','').replace("'","") + '|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53' + '&Referer=' + referrer
                    else:
                        hls = re.sub(r"//.*cdn.bg", "//edge" + ns + '.cdn.bg', hls)
                        streem0 = 'http:' + hls.replace('"','').replace("'","") + '|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53' + '&Referer=' + referrer
                    #streem0 = streem0.replace('fls','fls/_definst_')
                    streem0 = re.sub(r" control.*>", "", streem0)
            except:
                pass

        #print 'EVOLINK: ' + streem0
        STREAMPLAY(name,streemh+streem0,'iconimage')





#Извличане на стриймове с динамичен token
def HLSTP(name,url,iconimage):
        referrer, adres = url.split("--")
        req = urllib2.Request(adres)
        req.add_header('User-Agent', UA)
        req.add_header('Referer', referrer)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data
        
        streem0='';
        streem1='';
        match = re.compile('(http.+\/.*m3u.*)[\"\'\ ]').findall(data)
        for hls in match:
            if hls <>'':
                try:
                    hls, garbage = hls.split(" ")
                except:
                    pass
                streem0 = hls.replace('"','').replace("'","")
                if not 'http' in streem0:
                    streem0 = 'http:' + streem0
        if streem0 =='':
            match2 = re.compile('(//.*m3u8.{30,40})[\ \"\']').findall(data)
            for hls in match2:
                    streem1 = hls.replace('"','').replace("'","")
                    if not 'http' in streem1:
                        streem1 = 'http:' + streem1
        STREAMPLAY(name,streem0+streem1+'|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53',iconimage)





#Извличане на стриймове от Livestream.com
def LIVESTREAM(name,url,iconimage):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print 'LIVESTREAM: ' + data

        match = re.compile('rtsp_url":"(.+?)"').findall(data)
        for rtsp in match:
            rtmp = rtsp.replace('rtsp','rtmp')
            streem = rtmp + ' pageURL=https://livestream.com/ swfUrl=http://cdn.livestream.com/swf/LSPlayer.swf swfVfy=1 live=1 timeout=12'
            #print 'LIVESTREAM: ' + streem
            STREAMPLAY(name,streem,iconimage)








#Разлистване предавания на запис от Livestream.com
def LSARCHIVE(url):
        req = urllib2.Request('http://api.new.livestream.com/accounts/' + url + '/feed.json?maxItems=9000')
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        #print jsonrsp['data'][0]['data']['caption'].encode('utf-8', 'ignore')
        #print jsonrsp['data'][0]['data']['id']
        #print jsonrsp['data'][0]['data']['thumbnail_url']
        #print jsonrsp['data'][0]['data']['m3u8_url']

        for index in range(0, len(jsonrsp['data'])):
            #print jsonrsp['data'][index]['data']['caption'].encode('utf-8', 'ignore')
            addLink(jsonrsp['data'][index]['data']['caption'].encode('utf-8', 'ignore'),jsonrsp['data'][index]['data']['m3u8_url'] + '|User-Agent=stagefright',5,jsonrsp['data'][index]['data']['thumbnail_url'])














 #Разлистване на уроците в schoolpedia
def SCHOOLPEDIA(url):
        url = 'https://schoolpedia.org/%D0%B2%D0%B8%D0%B4%D0%B5%D0%B0'
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data


        match = re.compile('<a href="(.+?)">\n +(.+?)\n +(.+?)</a>').findall(data)
        for adres, nomer, ime in match:
            title=nomer+ime
            addDir(title,adres,15,'DefaultFolder.png')





 #Отваряне на видеата в schoolpedia
def OPENSP(title,adres,thumbnail):
        req = urllib2.Request(adres)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data2=response.read()
        response.close()
        #print data

        match2 = re.compile('<source src="(.+?)" type=').findall(data2)
        for video in match2:
            vurl = 'https://schoolpedia.org' + video + '|User-Agent=stagefright' #Конструираме адреса за достъп до видеото
            #print 'SCHOOLPEDIA vurl=' + vurl
            name = '[Линк ' + str(match2.index(video)+1) + '] ~ ' + title #Конструираме заглавието на линка за гледане
            addLink(name,vurl,5,'https://schoolpedia.org/img/logo.png')







 #Разлистване на уроците от ucha.se по категории
def INDEXCATUROCI(url):
        #Select streamer
        streamer = ['101', '103', '104']
        ns = random.choice(streamer)

        matchj = re.compile('category=(.+?)&class_num=(.+?)').findall(url)
        for cat, clas in matchj:
            values={'type' : 'video',
                            'category' : cat,
                            'class_num' : clas,
                            'subcategory' : '',
                            'view_active' : 'grid'
                            }

        url = 'http://ucha.se/ajax/content_items/get_items_ajax.php'
        postdata = urllib.urlencode(values)
        req = urllib2.Request(url, postdata, headers)
        response = urllib2.urlopen(req)
        #print 'request page url:' + url
        data=response.read()
        response.close()

        #print data
        br = 0
        h = HTMLParser.HTMLParser()
        matchd = re.compile('<a href="(http://ucha.se/watch/.+?)" class.*\n.*\n.*\n.*\n.*\n.*\n.*<img itemprop="image" src="(.+?)" alt="(.+?)"').findall(data)
        for vurl, thumb, title in matchd:
            thumb=str(thumb.replace('https','http'))
            #print vid + ' ' + thumb + ' ' + title
            #print image
            #matchv = re.compile('\d/(.+?).jpg').findall(thumb)
            #for imagename in matchv:
                #print imagename
            br = br + 1
                #http://31.13.223.104/uchase/_definist_/mp4:videos/13092016-Gradivni-chastitsi-na-veshtestvata-Atomi-Himichen-element.mp4/playlist.m3u8
                #vurl = "http://31.13.223." + ns + "/uchase/_definist_/mp4:videos/" + imagename + ".mp4/playlist.m3u8|User-Agent=" + MUA + "&X-Forwarded-For=104.25.224.8" #Конструираме адреса за достъп до видеото
                #vurl = "rtmp://31.13.223." + ns + ":80/uchase/mp4/" + imagename + ".mp4 pageUrl=http://ucha.se swfurl=http://ucha.se/public/flowplayer/flowplayer.rtmp-3.2.13.swf token=1q2w3e4 live=1 timeout=12" #Конструираме адреса за достъп до видеото
            addLink(title.replace('&quot;','"').replace('&#039;',"'"),vurl,5,thumb)
        if br ==0:
            addDir('Очаквайте скоро :)','','',"DefaultFolderBack.png")










 #Разлистване на авторите
def INDEXCATAVTORI(url):
        req = urllib2.Request('http://www.avtori.com/authors.html')
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #print data
        match = re.compile('<a href="(.+?)" title=".+?" >(.+?)<\/a><br \/><br \/>').findall(data)
        for page, name in match:
            addDir(name,page,21,"DefaultFolder.png")






#Разлистване на разказите по автори
def RESOLVEAVTORI(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #print data
        match = re.compile('<!--<a href="(.+?)" title=".+?" >(.+?)<\/a>-->').findall(data)
        for adress, name in match:
            addLink(name,adress,5,"DefaultAudio.png")






 #Меню на грамофончето
def GRAMOFONCHE(url):
        addDir('Песнички и стихове за деца','/pesnicki/',33,"DefaultFolder.png")
        addDir('Приказки за деца','/prikazki/',33,"DefaultFolder.png")
        addDir('Радиотеатър и стихове за големи (възрастни)','/zagolemi/',33,"DefaultFolder.png")






#Разлистване на грамофончето
def GRAMOFONCHEPARSER(url):
        baseurl = 'http://gramofonche.chitanka.info'
        req = urllib2.Request(baseurl+url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data

        #Заглавия с обложки
        match = re.compile('<a href="(.+?)"> <img src="(.+?)".*alt="(.+?)">').findall(data)
        for page, cover, name in match:
            addDir(name,baseurl+page,34,cover)

        #Заглавия без обложки
        match = re.compile('<a href="(.+?)"> (.+?)</a>').findall(data)
        for page, name in match:
            name = name.replace('<i>','')
            name = name.replace('</i>','')
            addDir(name,baseurl+page,34,"DefaultFolder.png")






#Прослушване плочите на грамофончето
def GRAMOFONCHERESOLVER(url):
        baseurl = 'http://gramofonche.chitanka.info'
        req = urllib2.Request(url)
        print 'url is '+url
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data

        #Извличане на директни линкове за текущата директория
        match = re.compile('<a href="./(.+?mp3)"> (.+?)</a>').findall(data)
        for page, name in match:
            name = name.replace('<i>','')
            name = name.replace('</i>','')
            addLink(name,url+page,5,"DefaultAudio.png")







#Списък на категориите в POLOMA
def INDEXCATPOLOMA(url):
        CHANTUBE('Български филми','UCM9JvxWIApg0Ef0lY80Xecg','http://poloma.net/photo/poloma.jpg')
        CHANTUBE('Още български филми','UCDtTY6FEBLPXOn9o_9DPStA','http://poloma.net/photo/poloma.jpg')
        CHANTUBE('Български футбол АПФГ','UC4CyJh7_XGaNUaSUECrhtCA','http://sportvox.net/wp-content/uploads/2013/01/a_grupa.jpg')






#Списък на категориите в CORENI
def INDEXCATCORENI(url):
        SEND2YT('Български филми I част','PL2103BC9F1F637E8C','DefaultFolder.png')
        SEND2YT('Български филми II част','PLt35DFMLv9vZ3Kd0xXe9CZHYecrPrnZbd','DefaultFolder.png')
        SEND2YT('Български исторически филми','PLt35DFMLv9vaPIvyTOPZHuW-I8ro3-smk','DefaultFolder.png')
        SEND2YT('Български сериали','PLA59AD77E41B77720','DefaultFolder.png')
        SEND2YT('Български детски песни I част','PLUEGIl__BbiXOb054zRYE4rObrabk50nQ','DefaultFolder.png')
        SEND2YT('Български детски песни II част','PLUEGIl__BbiVLVYDQ5-9JecKIYf27btVC','DefaultFolder.png')






#Обработка на избраното видео
def SEND2RESOLVER(url):
    #print 'url: '+url
    url=url.replace('https','http')
    url=url.replace('www.','')


    # Получаване на линкове
    sitelink = url
    req = urllib2.Request(url)
    req.add_header('User-Agent', UA)
    response = urllib2.urlopen(req)
    data=response.read()
    response.close()


    #YouTube
    yt = re.compile('youtu.*/(.+?)"').findall(data)
    for vid in yt:
        sitelink = 'http://www.youtube.com/watch?v=' + vid
        print 'YouTube playable link: '  + sitelink
        pipeurl = 'plugin://plugin.video.youtube/play/?video_id=' + vid
        item = xbmcgui.ListItem(path=pipeurl, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    #Vimeo
    vm = re.compile('player.vimeo.com/video/(.+?).auto').findall(data)
    for vid in vm:
        sitelink = 'http://player.vimeo.com/video/' + vid
        print 'Vimeo playable link: '  + sitelink
        SEND2VM(vid)


    #Директен линк
    dl = re.compile('file: "(.+?)"').findall(data)
    for link in dl:
        if not ('youtu' in link or 'vimeo' in link):
            sitelink = link
            print 'Direct playable link: '  + sitelink
            item = xbmcgui.ListItem(path=sitelink, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
            item.setInfo( type="Video", infoLabels={ "Title": name } )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


    #Google Docs
    pars = HTMLParser.HTMLParser()
    if '/preview' in data:
        gd = re.compile('src="(.+?/preview)').findall(data)
        for fm in gd:
            link=fm
    else:
        gd = re.compile("src='(.+?)&").findall(data)
        for gid in gd:
            print 'Google Docs playable link: '  + gid
            gid=gid.replace('https://video.google.com/get_player?docid=','')
            link='http://docs.google.com/file/d/'+gid+'/preview'
    
    hmf = urlresolver.HostedMediaFile(link)
    if hmf:
        try:
            #Play via universal urlresolver
            item = xbmcgui.ListItem(path=urlresolver.resolve(link), iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
            item.setInfo( type="Video", infoLabels={ "Title": name } )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        except:
            #Problem
            xbmc.executebuiltin("Notification(BRIGADA,Това заглавие не може да бъде отворено. Уведомете администратора на сайта!,11000)")
    

    url = sitelink
    # Край на получаването на линкове





#Отваряне на онлайн стрийм
def STREAMPLAY(name,url,thumbnail):
        #Избиране на стрийминг сървър за Load Balancing
        streamers = []
        if '||' in url:
            streamers.extend(url.split("||"))
            ns = random.choice(streamers)
        else:
            ns = url
        
        if 'ucha' in url:
            req = urllib2.Request(url)
            req.add_header('User-Agent', UA)
            response = urllib2.urlopen(req)
            data=response.read()
            response.close()
            #print data
            
            h = HTMLParser.HTMLParser()
            match = re.compile('data-params=\"(.+?)\"').findall(data)
            for jsn in match:
                jsonrsp = json.loads(h.unescape(jsn))
                ns = jsonrsp['sources']['mp4_level_top'] + "|User-Agent=" + MUA + "&Referer=http://ucha.se/"
        
        if 'theplatform' in url:
            opener = urllib2.build_opener()
            opener.addheaders = [('User-agent', UA)]
            data = opener.open(url+'&manifest=m3u&vpaid=script&formats=mpeg4&format=SMIL&embedded=true').read()
        
            match = re.compile('<video src="(.+?)" title').findall(data)
            for s1 in match:
                ns = s1 + "|User-Agent=" + UA + "&X-Forwarded-For=207.223.2.149"
        
        
        #Възпроизвеждане
        li = xbmcgui.ListItem(path=ns)
        li.setInfo('video', { 'title': name })
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path = ns))
        except:
            xbmc.executebuiltin("Notification(Грешка,Изпратете log файла до разработчика!)")




#Отваряне на vod стрийм с безкрайно повторение
def STREAMPLAYR(name,url,thumbnail):
        li = xbmcgui.ListItem(path=url)
        li.setInfo('video', { 'title': name })
        try:
            xbmc.executebuiltin("xbmc.playercontrol(RepeatAll)")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path = url))
            #xbmc.executebuiltin("xbmc.PlayerControl(RepeatOff)")

        except:
            xbmc.executebuiltin("Notification(Грешка,Изпратете log файла до разработчика!)")






#Възпроизвеждане на подкаст
def FEEDPLAY(url):
        d = feedparser.parse(url)
        #print d
        e = len(d.entries)
        count = 0
        pars = HTMLParser.HTMLParser()
        extensions = ['.aac', '.ogg', '.mp3', '.mp4', '.mov', '.m3u', '.m3u8', '.webm']
        while (count < e):
            title=pars.unescape(d.entries[count].title).encode('utf-8', 'ignore')
            match = re.compile("'href': u'(.+?)'").findall(str(d.entries[count].links))
            if any(me in match[-1] for me in extensions):
                addLink(title,match[-1],5,'http://nursejournal.org/files/2012/12/podcast-headphones.png')
            count = count + 1







#YouTube на живо
def LIVETUBE(name,url,thumbnail):
        ok=True
        pipeurl = "plugin://plugin.video.youtube/play/?video_id=" + url
        item = xbmcgui.ListItem(path=pipeurl, iconImage=thumbnail, thumbnailImage=thumbnail)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return ok







#YouTube канал
def CHANTUBE(name,url,thumbnail):
        ok=True
        pipeurl = 'plugin://plugin.video.youtube/channel/' + url + '/'
        item = xbmcgui.ListItem(name, thumbnail, thumbnail)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=pipeurl,listitem=item,isFolder=True)
        return ok









#Клипове на YouTube потребител
def SEND2YTCLIP(name,url,thumbnail):
        ok=True
        pipeurl = 'plugin://plugin.video.youtube/user/' + url + '/'
        item = xbmcgui.ListItem(name, thumbnail, thumbnail)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=pipeurl,listitem=item,isFolder=True)
        return ok







#Изпращане на плейлиста към  YouTube Addon-a
def SEND2YT(name,url,thumbnail):
        ok=True
        pipeurl = 'plugin://plugin.video.youtube/playlist/' + url + '/'
        item = xbmcgui.ListItem(name, thumbnail, thumbnail)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=pipeurl,listitem=item,isFolder=True)
        return ok







#Препращане към Vimeo Addon-a
def SEND2VM(url):
        ok=True
        vid=url.replace('http://player.vimeo.com/video/','')
        pipeurl = 'plugin://plugin.video.vimeo/play/?video_id=' + vid
        #print 'PIPE: ' + pipeurl
        #xbmc.executebuiltin("xbmc.PlayMedia("+pipeurl+")")
        item = xbmcgui.ListItem(path=pipeurl, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return ok








#stream resolver за DACAST.COM
def DACAST(name,url,thumbnail):
        #url = "http://iframe.dacast.com/b/77649/c/423879?autoplay=0"
        prov = re.search("\/b\/(.+?)\/c\/", url).group(1)
        chan = re.search("\/c\/(.+?)\?", url).group(1)
        
        req = urllib2.Request('http://json.dacast.com/b/'+prov+'/c/'+chan)
        req.add_header('User-Agent', UA)
        req.add_header('Referer', 'http://iframe.dacast.com')
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        #print jsonrsp['hls']
        
        #url='https://services.dacast.com/token/i/b/77649/c/423879'
        req2 = urllib2.Request('http://services.dacast.com/token/i/b/'+prov+'/c/'+chan)
        req2.add_header('User-Agent', UA)
        req2.add_header('Referer', 'http://iframe.dacast.com')
        opener = urllib2.build_opener()
        f2 = opener.open(req2)
        jsonrsp2 = json.loads(f2.read())
        #print jsonrsp2['token']
        
        STREAMPLAY(name,'http:'+jsonrsp['hls'] + jsonrsp2['token'] + '|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53',thumbnail)
        
        
        
        
        
        
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        
        
        ok=True
        vid=url.replace('http://player.vimeo.com/video/','')
        pipeurl = 'plugin://plugin.video.vimeo/play/?video_id=' + vid
        #print 'PIPE: ' + pipeurl
        #xbmc.executebuiltin("xbmc.PlayMedia("+pipeurl+")")
        item = xbmcgui.ListItem(path=pipeurl, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return ok







#AXN Player via The Platform
def AXN(url):
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', UA)]
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        #print jsonrsp['entries'][0]['title'].encode('utf-8', 'ignore')
        
        for n in range(0, len(jsonrsp['entries'])):
            addLinkd(jsonrsp['entries'][n]['title'].encode('utf-8', 'ignore'),jsonrsp['entries'][n]['media$content'][0]['plfile$url'],str(jsonrsp['entries'][n]['media$content'][0]['plfile$duration']),5,jsonrsp['entries'][n]['plmedia$defaultThumbnailUrl'])
       








#BG прочит на история славянобългарская
def NERAZUMNI(url):
        addLink('Ползата от историята','http://istoriata.bg/assets/files/ISB-01.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Славянобългарска история','http://istoriata.bg/assets/files/ISB-02.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Историческо събрание за българския народ','http://istoriata.bg/assets/files/ISB-03.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Тук внимавай читателю, ще кажем накратко за сръбските крале','http://istoriata.bg/assets/files/ISB-04.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Пак завършваме разказа за Константин Шишман','http://istoriata.bg/assets/files/ISB-05.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Тук е потребно да се съберат заедно имената на българските крале и царе. Колкото се намират. И кой след кого е царувал','http://istoriata.bg/assets/files/ISB-06.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Събрано накратко колко знаменити били българските крале и царе','http://istoriata.bg/assets/files/ISB-07.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('За славянските учители','http://istoriata.bg/assets/files/ISB-08.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Тук събрахме накратко имената на българските светци, колкото са просияли от българския народ в последно време','http://istoriata.bg/assets/files/ISB-09.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Послесловие','http://istoriata.bg/assets/files/ISB-10.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Иван Вазов - Ода за Паисий','http://istoriata.bg/assets/files/ivan%20vazov%20oda%20za%20paisii.mp3',5,'http://www.desant.net/files/tn/139893929679157.jpg')
        addLink('Интервю с професор Илия Тодев','http://istoriata.bg/assets/files/videos/interviews/ilia_todev.mp4',5,'http://istoriata.bg/assets/files/videos/interviews/ilia_todev.jpg')
        addLink('Интервю с професор Вера Бонева','http://istoriata.bg/assets/files/videos/interviews/vera_boneva.mp4',5,'http://istoriata.bg/assets/files/videos/interviews/vera_boneva.jpg')









#Категории на видеата от vivahistory.bg
def VIVAHISTORY(url):
    addDir('Времева линия','https://spreadsheets.google.com/feeds/list/1EnKsyfWs207zCDLpzMGoLJNKQ41N_gIncFXlp_4cblA/1/public/values?alt=rss',25,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('Държавници и Политици','/people/statesmen-politicians/',26,'http://www.vivahistory.bg/res/img/silhouettes/politician.png')
    addDir('Военни','/people/military/',26,'http://www.vivahistory.bg/res/img/silhouettes/military.png')
    addDir('Чужденци','/people/foreigners/',26,'http://www.vivahistory.bg/res/img/silhouettes/foreigner.png')
    addDir('Революционери','/people/revolutionaries/',26,'http://www.vivahistory.bg/res/img/silhouettes/revolutionary.png')
    addDir('Фолклор','/culture/folklore/',26,'http://www.vivahistory.bg/res/img/silhouettes/bagpiper.png')
    addDir('Празници и обичаи','/culture/holidays-celebrations/',26,'http://www.vivahistory.bg/res/img/silhouettes/lazarka.png')
    addDir('Народно творчество','/culture/art/',26,'http://www.vivahistory.bg/res/img/silhouettes/HitarPetar.png')
    addDir('Опознай България','/facts/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('Любопитни факти','/facts/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('VIVA10','/viva10/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('За малчуганите','/kids/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('Тестове','/tests/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')








#Парсер на времевата линия на vivahistory.bg
def VIVATIMELINEPARSER(url):
        #url = "https://docs.google.com/spreadsheets/d/1EnKsyfWs207zCDLpzMGoLJNKQ41N_gIncFXlp_4cblA/pubhtml"
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #print data
        match = re.compile('<gsx:year>(.+?)</gsx:year>.*<gsx:endyear>(.*)</gsx:endyear>.*<gsx:headline>(.+?)</gsx:headline>.*\n.*poster="(.+?)"').findall(data)
        for start, end, title, cover in match:
            if end != '':
                name = start + ' - ' + end + 'г. ' + title
            else:
                name = start + 'г. ' + title
            video = cover.replace('jpg','webm')
            addLink(name,video,5,cover)







#Парсер на страниците от vivahistory.bg
def VIVAPAGEPARSER(url):
        #url = "/people/statesmen-politicians/"
        base = "http://www.vivahistory.bg"

        req = urllib2.Request(base+url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #print data
        match = re.compile('<img src="(.+?)" width="240" height="135" alt="(.+?)" />').findall(data) #<img src="/res/videos/people/thumbs/Alexander_I_Batenberg.jpg" width="240" height="135" alt="Княз Александър І Батенберг" />
        for cover, name in match:
            #name = name.replace('&bdquo;','"') # kavichki
            #name = name.replace('&ldquo;','"') # kavichki
            cover = base + cover
            video = cover.replace('thumbs/','').replace('jpg','mp4')
            addLink(name,video,5,cover)

        #други линкове
        match = re.compile('<h3>(.+?)</h3>\n.*\n.*poster="(.+?)".*src="(.+?)"').findall(data)
        for name, cover, video in match:
            name = name.replace('&bdquo;','"') # kavichki
            name = name.replace('&ldquo;','"') # kavichki
            cover = base + cover
            video = base + video
            addLink(name,video,5,cover)







#Избор на автор по съответната буква
def ZAKNIGI():
        addDir('Всички','all',29,'DefaultFolder.png')
        addDir('А','1',29,'DefaultFolder.png')
        addDir('Б','2',29,'DefaultFolder.png')
        addDir('В','3',29,'DefaultFolder.png')
        addDir('Г','4',29,'DefaultFolder.png')
        addDir('Д','5',29,'DefaultFolder.png')
        addDir('Е','6',29,'DefaultFolder.png')
        addDir('Ж','7',29,'DefaultFolder.png')
        addDir('З','8',29,'DefaultFolder.png')
        addDir('И','9',29,'DefaultFolder.png')
        addDir('Й','10',29,'DefaultFolder.png')
        addDir('К','11',29,'DefaultFolder.png')
        addDir('Л','12',29,'DefaultFolder.png')
        addDir('М','13',29,'DefaultFolder.png')
        addDir('Н','14',29,'DefaultFolder.png')
        addDir('О','15',29,'DefaultFolder.png')
        addDir('П','16',29,'DefaultFolder.png')
        addDir('Р','17',29,'DefaultFolder.png')
        addDir('С','18',29,'DefaultFolder.png')
        addDir('Т','19',29,'DefaultFolder.png')
        addDir('У','20',29,'DefaultFolder.png')
        addDir('Ф','21',29,'DefaultFolder.png')
        addDir('Х','22',29,'DefaultFolder.png')
        addDir('Ц','23',29,'DefaultFolder.png')
        addDir('Ч','24',29,'DefaultFolder.png')
        addDir('Ш','25',29,'DefaultFolder.png')
        addDir('Щ','26',29,'DefaultFolder.png')
        addDir('Ь','27',29,'DefaultFolder.png')
        addDir('Ъ','28',29,'DefaultFolder.png')
        addDir('Ю','29',29,'DefaultFolder.png')
        addDir('Я','30',29,'DefaultFolder.png')





# Парсер по букви на zaknigi.com
def ZAKNIGIPARSER(url):
        base = "http://zaknigi.com/browse/2/bukva/"
        req = urllib2.Request(base+url+'/')
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        pars = HTMLParser.HTMLParser()
        match = re.compile('<a href="(.+?)" class="author">(.+?)</a>').findall(data)
        for adress, name in match:
            name = name.replace('<span class="span"> ','') # зачистване на автора
            name = name.replace('</span>','') #  на заглавието
            name = pars.unescape(name).decode('cp1251', 'ignore').encode('utf-8', 'ignore')
            addDir(name,adress,30,'DefaultFolder.png')





# Парсер на zaknigi.com
def ZAKNIGIPARSER2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        pars = HTMLParser.HTMLParser()
        match = re.compile('<a href="(.+?/)">(.+?)</a><div>').findall(data)
        for adress, name in match:
            name = pars.unescape(name).decode('cp1251', 'ignore').encode('utf-8', 'ignore')
            addDir(name,adress,31,'DefaultFolder.png')






#Генериране на линкове за възпроизвеждане на аудиокнигите от zaknigi.com
def ZAKNIGIPLAYER(name,url):
        print 'zaknigi url is: ' + url
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        pars = HTMLParser.HTMLParser()
        match = re.compile('<li><a href="#" data-src="(.+?)">(.+?)</a></li>').findall(data)
        for kniga, name2 in match:
            name2 = pars.unescape(name2).decode('cp1251', 'ignore').encode('utf-8', 'ignore')
            if name2 == 'Част ':
                title = name
            else:
                title = name + ' ' + name2
            addLink(title,kniga,5,'DefaultAudio.png')




#Новини от DW
def DW(url):
        d = feedparser.parse(url)
        #print d
        e = len(d.entries)
        count = 0
        pars = HTMLParser.HTMLParser()
        while (count < e):
            title=pars.unescape(d.entries[count].title).encode('utf-8', 'ignore')
            match = re.compile("href': u'(.+?)'").findall(str(d.entries[count].links))
            #addLink(title,match[-1].replace('http://www.dw.com/static/stills/images/','http://tv-download.dw.de/dwtv_video/flv/').replace('.jpg','_sd_sor.mp4')+'|User-Agent=stagefright',5,match[-1])
            addLink(title,match[-1].replace('https://tvdownloaddw-a.akamaihd.net/stills/images/','http://tv-download.dw.de/dwtv_video/flv/').replace('.jpg','_sd_sor.mp4')+'|User-Agent=stagefright',5,match[-1])
            count = count + 1






#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделно заглавие и неговите атрибути + продължителност към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLinkd(name,url,duration,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': 'Дълго описание на видеото...' } )
        liz.addStreamInfo("Video", { 'width': 1920, 'height': 1080, "duration": duration })
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param



params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode==1:
        INDEXCATPOLOMA(url)

elif mode==2:
        SCHOOLPEDIA(url)

elif mode==3:
        SEND2RESOLVER(url)

elif mode==4:
        INDEXCATBGTV2(url)

elif mode==5:
        STREAMPLAY(name,url,thumbnail)

elif mode==6:
        LIVETV(url)

elif mode==7:
        FEEDPLAY(url)

elif mode==8:
        RADIO(url)

elif mode==9:
        PODCAST(url)

elif mode==10:
        SEND2YT(name,url,thumbnail)

elif mode==11:
        SEND2VM(url)

elif mode==12:
        PRIKAZKI(url)

elif mode==13:
        CHANTUBE(name,url,thumbnail)

elif mode==14:
        INDEXCATCORENI(url)

elif mode==15:
        OPENSP(name,url,thumbnail)

elif mode==16:
        SEND2YTCLIP(name,url,thumbnail)

elif mode==17:
        UCHASE()

elif mode==18:
        INDEXCATUROCI(url)

elif mode==19:
        EVOLINK(name,url,thumbnail)

elif mode==20:
        INDEXCATAVTORI(url)

elif mode==21:
        RESOLVEAVTORI(url)

elif mode==22:
        LIVESTREAM(name,url,thumbnail)

elif mode==23:
        NERAZUMNI(url)

elif mode==24:
        VIVAHISTORY(url)

elif mode==25:
        VIVATIMELINEPARSER(url)

elif mode==26:
        VIVAPAGEPARSER(url)

elif mode==27:
        LIVETUBE(name,url,thumbnail)

elif mode==28:
        ZAKNIGI()

elif mode==29:
        ZAKNIGIPARSER(url)

elif mode==30:
        ZAKNIGIPARSER2(url)

elif mode==31:
        ZAKNIGIPLAYER(name,url)

elif mode==32:
        GRAMOFONCHE(url)

elif mode==33:
        GRAMOFONCHEPARSER(url)

elif mode==34:
        GRAMOFONCHERESOLVER(url)

elif mode==35:
        LSARCHIVE(url)

elif mode==36:
        DW(url)

elif mode==37:
        DACAST(name,url,thumbnail)

elif mode==38:
        AXN(url)

elif mode==40:
        STREAMPLAYR(name,url,thumbnail)

elif mode==41:
        HLSTP(name,url,thumbnail)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
