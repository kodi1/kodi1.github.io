# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import HTMLParser
import feedparser
import random
import urlresolver

xbmc.executebuiltin("xbmc.PlayerControl(RepeatOff)")
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

#   plugin://plugin.video.youtube/play/?video_id=[VID]
#   plugin://plugin.video.youtube/playlist/<PLAYLIST_ID>/
#   plugin://plugin.video.youtube/channel/[CID]/
#   plugin://plugin.video.youtube/user/[NAME]/
#   plugin://plugin.video.vimeo/play/?video_id=[VID]

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.brigada'
__Addon = xbmcaddon.Addon(__addon_id__)

UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:63.0) Gecko/20100101 Firefox/63.0'
MUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D201 Safari/9537.53'
thumbnail = 'DefaultVideo.png'


#Меню с директории в приставката
def CATEGORIES():
        xbmc.executebuiltin("xbmc.playercontrol(RepeatOff)")
        addDir('Български филми от BGTV2.BLOGSPOT.COM','http://bgtv2.blogspot.com/',4,'http://upload.wikimedia.org/wikipedia/commons/8/87/Bulgariafilm.png')
        addDir('Български филми и футбол от POLOMA.NET','http://poloma.net/',1,'http://poloma.net/photo/poloma.jpg')
        addDir('Български филми и сериали за деца от TVHLAPETA.BNT.BG','http://epg.kodibg.org/brigadahlapeta.php',6,'http://tvhlapeta.bnt.bg/images/tvhlapeta-logo.png')
        addDir('Български приказки, песнички и радиотеатър от GRAMOFONCHE.CHITANKA.INFO','gramofonche',32,'http://vk.com/images/gifts/256/276.jpg')
        addDir('Български приказки от DECHICA.COM','http://epg.kodibg.org/brigadaprikazki.php',6,'http://www.dechica.com/Documents/000000632/BGBG/bg_narodni.jpg')
        CHANTUBE('Български видеоуроци от NAU4I.ME','UCpHITy7CGe-h_fXng03bZrw','https://yt3.ggpht.com/-TMyhvQnl4P4/AAAAAAAAAAI/AAAAAAAAAAA/UkweUQVnd9c/s100-c-k-no/photo.jpg')
        CHANTUBE('Български видеоуроци от TELERIKACADEMY.COM','UCLC-vbm7OWvpbqzXaoAMGGw','https://yt3.ggpht.com/-69C3oNxEcv4/AAAAAAAAAAI/AAAAAAAAAAA/l5nRqSMobgc/s900-c-k-no/photo.jpg')
        CHANTUBE('Български видеоуроци от BG.KHANACADEMY.ORG','UCHNKwF_1cac1ebnOtrdXwVw','https://www.khanacademy.org/images/khan-logo-vertical-transparent.png')
        addDir('Български видеоуроци по английски език от BiTELEVISION.COM','5627058/events/3039729',35,'http://logos.kodibg.org/bit.png')
        SEND2YTCLIP('Български видеоуроци по английски език от CLASSROOM.BG','ClassroomBg','http://classroom.bg/images/logo.png')
        addDir('Българската история разказана от VIVAHISTORY.BG','http://vivahistory.bg',24,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
        addDir('История славянобългарская - прочит от ISTORIATA.BG','nerazumni',23,'http://player.myshared.ru/805346/data/images/img29.png')
        addDir('Български подкасти','http://epg.kodibg.org/brigadapodcast.php',6,'http://nursejournal.org/files/2012/12/podcast-headphones.png')
        addDir('Български радиа','http://epg.kodibg.org/brigadaradio.php',6,'http://gtrk-saratov.ru/images/cms/data/2013/march2013/89/uzn_1368814232.jpg')
        CHANTUBE('Българска музика от BGESTRADA.COM','UCJhbyIJNHjGrstWIIVr149Q','http://www.bgestrada.com/bgestrada/sites/default/files/litejazz_logo.png')
        addDir('Българска телевизия /само официални излъчвания/','http://epg.kodibg.org/brigadatv.php',6,'http://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Bnt1_history.png/600px-Bnt1_history.png')



#Списък на предаванията/филмите в BGTV2
def INDEXCATBGTV2(showid):
        thumbnail = 'DefaultVideo.png'
        #url = 'http://sites.google.com/site/apitvbg/shadowbbox.js' #cifri abvgd
        #url = 'http://sites.google.com/site/apitvbg/shadowex.js' #ejzik
        #url = 'http://sites.google.com/site/apitvbg/shadowlex.js' #klmno
        #url = 'http://sites.google.com/site/apitvbg/shadowp.js' #prs
        #url = 'http://sites.google.com/site/apitvbg/shadowpr.js' #s2 ^
        #url = 'http://sites.google.com/site/apitvbg/shadowvoz.js' #tufhtzsh6tiuia - problem s encodinga
        #url = 'http://sites.google.com/site/apitvbg/shadowscx.js' #kratki film - shorts i tv
        #url = 'http://sites.google.com/site/apitvbg/shadowan.js'
        
        #url = 'http://sites.google.com/site/apitvbg/shadowbox.js' cifri a-u
        #url = 'http://sites.google.com/site/apitvbg/shadowboz.js' prstufhc46uq
        #url = 'http://sites.google.com/site/apitvbg/google_api.js' shorts

        li = ['http://sites.google.com/site/apitvbg/shadowbox.js', 'http://sites.google.com/site/apitvbg/shadowboz.js', 'http://sites.google.com/site/apitvbg/google_api.js'] #a-ia + shorts
        for url in li:
            try:
                req = urllib2.Request(url)
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data=response.read()
                response.close()
                
                match= re.compile(' "(.+?)",.*:"(.+?)",').findall(data)
                pars = HTMLParser.HTMLParser()
                for href,name in match:
                    href=href.replace('https','http')
                    mn=pars.unescape(name).encode('utf-8', 'ignore') #<-работи на PC и андроид, но само с правилен енкодинг
                    if not ('nfc.bg' in href or 'iframe' in mn):
                        addLink(mn,href,3,thumbnail)
                        #print mn + ' ' + href + ' ' + thumbnail
            except:
                pass



#BG приказки
#BG подкасти на живо по интернет
#BGTV на живо по интернет
#BG радиа на живо по интернет
def BGP(url):
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        
        if 'podcast' in url:
            for bg in range(0, len(jsonrsp['streams'])):
                addDir(jsonrsp['streams'][bg]['title'].encode('utf-8', 'ignore'),jsonrsp['streams'][bg]['url'],jsonrsp['streams'][bg]['mode'],jsonrsp['streams'][bg]['cover'])
        else:
            for bg in range(0, len(jsonrsp['streams'])):
                addLink(jsonrsp['streams'][bg]['title'].encode('utf-8', 'ignore'),jsonrsp['streams'][bg]['url'],jsonrsp['streams'][bg]['mode'],jsonrsp['streams'][bg]['cover'])



 #Извличане на стриймове от Evolink/CDNBG
def EVOLINK(name,url,iconimage):
        streemh = ''
        streem0 = ''
        streem1 = ''
        streem2 = ''

        #Select streamer
        streamer = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16'] #, '17', '18', '19', '20'
        ns = random.choice(streamer)

        if 'edge' in url:
            streemh = re.sub(r"edge\d", "edge" + ns, url)
            #streemh = url
        else:
            referrer, adres, port, token = url.split("-")

            #Заявка към страницата със стрийма
            req = urllib2.Request(adres)
            req.add_header('User-Agent', UA)
            req.add_header('Referer', referrer)
            response = urllib2.urlopen(req)
            data=response.read()
            response.close()
            #print 'EVOLINK: ' + data

            #Генерираме сами стрийма с нов сървър от loadbalancer-a
            try:
                matchh = re.compile('(//.*m3u8.{30,40})[\ \"\']').findall(data)
                for hls in matchh:
                    if 'clb' in hls:
                        streem0 = 'http:' + hls.replace('"','').replace("'","") + '|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53' + '&Referer=' + referrer
                    else:
                        hls = re.sub(r"//.*cdn.bg", "//edge" + ns + '.cdn.bg', hls)
                        streem0 = 'http:' + hls.replace('"','').replace("'","") + '|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53' + '&Referer=' + referrer
                    #streem0 = streem0.replace('fls','fls/_definst_')
                    streem0 = re.sub(r" control.*>", "", streem0)
            except:
                pass

        #print 'EVOLINK: ' + streem0
        STREAMPLAY(name,streemh+streem0,'iconimage')





#Извличане на стриймове с динамичен token
def HLSTP(name,url,iconimage):
        referrer, adres = url.split("--")
        req = urllib2.Request(adres)
        req.add_header('User-Agent', UA)
        req.add_header('Referer', referrer)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data
        
        streem0='';
        streem1='';
        match = re.compile('(http.+\/.*m3u.*)[\"\'\ ]').findall(data)
        for hls in match:
            if hls <>'':
                try:
                    hls, garbage = hls.split(" ")
                except:
                    pass
                streem0 = hls.replace('"','').replace("'","")
                if not 'http' in streem0:
                    streem0 = 'http:' + streem0
        if streem0 =='':
            match2 = re.compile('(//.*m3u8.{30,40})[\ \"\']').findall(data)
            for hls in match2:
                    streem1 = hls.replace('"','').replace("'","")
                    if not 'http' in streem1:
                        streem1 = 'http:' + streem1
        STREAMPLAY(name,streem0+streem1+'|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53',iconimage)





#Извличане на стриймове от Livestream.com
def LIVESTREAM(name,url,iconimage):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print 'LIVESTREAM: ' + data

        match = re.compile('rtsp_url":"(.+?)"').findall(data)
        for rtsp in match:
            rtmp = rtsp.replace('rtsp','rtmp')
            streem = rtmp + ' pageURL=https://livestream.com/ swfUrl=http://cdn.livestream.com/swf/LSPlayer.swf swfVfy=1 live=1 timeout=12'
            #print 'LIVESTREAM: ' + streem
            STREAMPLAY(name,streem,iconimage)








#Разлистване предавания на запис от Livestream.com
def LSARCHIVE(url):
        req = urllib2.Request('http://api.new.livestream.com/accounts/' + url + '/feed.json?maxItems=9000')
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        #print jsonrsp['data'][0]['data']['caption'].encode('utf-8', 'ignore')
        #print jsonrsp['data'][0]['data']['id']
        #print jsonrsp['data'][0]['data']['thumbnail_url']
        #print jsonrsp['data'][0]['data']['m3u8_url']

        for index in range(0, len(jsonrsp['data'])):
            #print jsonrsp['data'][index]['data']['caption'].encode('utf-8', 'ignore')
            addLink(jsonrsp['data'][index]['data']['caption'].encode('utf-8', 'ignore'),jsonrsp['data'][index]['data']['m3u8_url'] + '|User-Agent=stagefright',5,jsonrsp['data'][index]['data']['thumbnail_url'])









 #Меню на грамофончето
def GRAMOFONCHE(url):
        addDir('Песнички и стихове за деца','/pesnicki/',33,"DefaultFolder.png")
        addDir('Приказки за деца','/prikazki/',33,"DefaultFolder.png")
        addDir('Радиотеатър и стихове за големи (възрастни)','/zagolemi/',33,"DefaultFolder.png")






#Разлистване на грамофончето
def GRAMOFONCHEPARSER(url):
        baseurl = 'http://gramofonche.chitanka.info'
        req = urllib2.Request(baseurl+url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data

        #Заглавия с обложки
        match = re.compile('<a href="(.+?)"> <img src="(.+?)".*alt="(.+?)">').findall(data)
        for page, cover, name in match:
            addDir(name,baseurl+page,34,cover)

        #Заглавия без обложки
        match = re.compile('<a href="(.+?)"> (.+?)</a>').findall(data)
        for page, name in match:
            name = name.replace('<i>','')
            name = name.replace('</i>','')
            addDir(name,baseurl+page,34,"DefaultFolder.png")






#Прослушване плочите на грамофончето
def GRAMOFONCHERESOLVER(url):
        baseurl = 'http://gramofonche.chitanka.info'
        req = urllib2.Request(url)
        print 'url is '+url
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        #print data

        #Извличане на директни линкове за текущата директория
        match = re.compile('<a href="./(.+?mp3)"> (.+?)</a>').findall(data)
        for page, name in match:
            name = name.replace('<i>','')
            name = name.replace('</i>','')
            addLink(name,url+page,5,"DefaultAudio.png")





#Списък на категориите в POLOMA
def INDEXCATPOLOMA(url):
        CHANTUBE('Още български филми','UCDtTY6FEBLPXOn9o_9DPStA','http://poloma.net/photo/poloma.jpg')
        CHANTUBE('Български футбол АПФГ','UC4CyJh7_XGaNUaSUECrhtCA','http://sportvox.net/wp-content/uploads/2013/01/a_grupa.jpg')






#Обработка на избраното видео
def SEND2RESOLVER(url):
    #print 'url: '+url
    url=url.replace('https','http')
    url=url.replace('www.','')


    # Получаване на линкове
    sitelink = url
    req = urllib2.Request(url)
    req.add_header('User-Agent', UA)
    response = urllib2.urlopen(req)
    data=response.read()
    response.close()


    #YouTube
    yt = re.compile('youtu.*/(.+?)"').findall(data)
    for vid in yt:
        sitelink = 'http://www.youtube.com/watch?v=' + vid
        print 'YouTube playable link: '  + sitelink
        pipeurl = 'plugin://plugin.video.youtube/play/?video_id=' + vid
        item = xbmcgui.ListItem(path=pipeurl, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    #Vimeo
    vm = re.compile('player.vimeo.com/video/(.+?).auto').findall(data)
    for vid in vm:
        sitelink = 'http://player.vimeo.com/video/' + vid
        print 'Vimeo playable link: '  + sitelink
        SEND2VM(vid)


    #Директен линк
    dl = re.compile('file: "(.+?)"').findall(data)
    for link in dl:
        if not ('youtu' in link or 'vimeo' in link):
            sitelink = link
            print 'Direct playable link: '  + sitelink
            item = xbmcgui.ListItem(path=sitelink, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
            item.setInfo( type="Video", infoLabels={ "Title": name } )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


    #Google Docs
    pars = HTMLParser.HTMLParser()
    if '/preview' in data:
        gd = re.compile('src="(.+?/preview)').findall(data)
        for fm in gd:
            link=fm
    else:
        gd = re.compile("src='(.+?)&").findall(data)
        for gid in gd:
            print 'Google Docs playable link: '  + gid
            gid=gid.replace('https://video.google.com/get_player?docid=','')
            link='http://docs.google.com/file/d/'+gid+'/preview'
    
    hmf = urlresolver.HostedMediaFile(link)
    if hmf:
        try:
            #Play via universal urlresolver
            item = xbmcgui.ListItem(path=urlresolver.resolve(link), iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
            item.setInfo( type="Video", infoLabels={ "Title": name } )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        except:
            #Problem
            xbmc.executebuiltin("Notification(BRIGADA,Това заглавие не може да бъде отворено. Уведомете администратора на сайта!,11000)")
    

    url = sitelink
    # Край на получаването на линкове





#Отваряне на онлайн стрийм
def STREAMPLAY(name,url,thumbnail):
        #Избиране на стрийминг сървър за Load Balancing
        streamers = []
        if '||' in url:
            streamers.extend(url.split("||"))
            ns = random.choice(streamers)
        else:
            ns = url
        
        if 'ucha' in url:
            req = urllib2.Request(url)
            req.add_header('User-Agent', UA)
            response = urllib2.urlopen(req)
            data=response.read()
            response.close()
            #print data
            
            h = HTMLParser.HTMLParser()
            match = re.compile('data-params=\"(.+?)\"').findall(data)
            for jsn in match:
                jsonrsp = json.loads(h.unescape(jsn))
                ns = jsonrsp['sources']['mp4_level_top'] + "|User-Agent=" + MUA + "&Referer=http://ucha.se/"
        
        if 'theplatform' in url:
            opener = urllib2.build_opener()
            opener.addheaders = [('User-agent', UA)]
            data = opener.open(url+'&manifest=m3u&vpaid=script&formats=mpeg4&format=SMIL&embedded=true').read()
        
            match = re.compile('<video src="(.+?)" title').findall(data)
            for s1 in match:
                ns = s1 + "|User-Agent=" + UA + "&X-Forwarded-For=207.223.2.149"
        
        
        #Възпроизвеждане
        li = xbmcgui.ListItem(path=ns)
        li.setInfo('video', { 'title': name })
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path = ns))
        except:
            xbmc.executebuiltin("Notification(Грешка,Изпратете log файла до разработчика!)")




#Отваряне на vod стрийм с безкрайно повторение
def STREAMPLAYR(name,url,thumbnail):
        li = xbmcgui.ListItem(path=url)
        li.setInfo('video', { 'title': name })
        try:
            xbmc.executebuiltin("xbmc.playercontrol(RepeatAll)")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path = url))
            #xbmc.executebuiltin("xbmc.PlayerControl(RepeatOff)")

        except:
            xbmc.executebuiltin("Notification(Грешка,Изпратете log файла до разработчика!)")






#Възпроизвеждане на подкаст
def FEEDPLAY(url):
        d = feedparser.parse(url)
        #print d
        e = len(d.entries)
        count = 0
        pars = HTMLParser.HTMLParser()
        extensions = ['.aac', '.ogg', '.mp3', '.mp4', '.mov', '.m3u', '.m3u8', '.webm']
        while (count < e):
            title=pars.unescape(d.entries[count].title).encode('utf-8', 'ignore')
            match = re.compile("'href': u'(.+?)'").findall(str(d.entries[count].links))
            if any(me in match[-1] for me in extensions):
                #print match[-1]
                addLink(title,match[-1],5,'http://nursejournal.org/files/2012/12/podcast-headphones.png')
            count = count + 1







#YouTube на живо
def LIVETUBE(name,url,thumbnail):
        ok=True
        pipeurl = "plugin://plugin.video.youtube/play/?video_id=" + url
        item = xbmcgui.ListItem(path=pipeurl, iconImage=thumbnail, thumbnailImage=thumbnail)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return ok







#YouTube канал
def CHANTUBE(name,url,thumbnail):
        ok=True
        pipeurl = 'plugin://plugin.video.youtube/channel/' + url + '/'
        item = xbmcgui.ListItem(name, thumbnail, thumbnail)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=pipeurl,listitem=item,isFolder=True)
        return ok









#Клипове на YouTube потребител
def SEND2YTCLIP(name,url,thumbnail):
        ok=True
        pipeurl = 'plugin://plugin.video.youtube/user/' + url + '/'
        item = xbmcgui.ListItem(name, thumbnail, thumbnail)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=pipeurl,listitem=item,isFolder=True)
        return ok







#Изпращане на плейлиста към  YouTube Addon-a
def SEND2YT(name,url,thumbnail):
        ok=True
        pipeurl = 'plugin://plugin.video.youtube/playlist/' + url + '/'
        item = xbmcgui.ListItem(name, thumbnail, thumbnail)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=pipeurl,listitem=item,isFolder=True)
        return ok







#Препращане към Vimeo Addon-a
def SEND2VM(url):
        ok=True
        vid=url.replace('http://player.vimeo.com/video/','')
        pipeurl = 'plugin://plugin.video.vimeo/play/?video_id=' + vid
        #print 'PIPE: ' + pipeurl
        #xbmc.executebuiltin("xbmc.PlayMedia("+pipeurl+")")
        item = xbmcgui.ListItem(path=pipeurl, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return ok








#stream resolver за DACAST.COM
def DACAST(name,url,thumbnail):
        #url = "http://iframe.dacast.com/b/77649/c/423879?autoplay=0"
        prov = re.search("\/b\/(.+?)\/c\/", url).group(1)
        chan = re.search("\/c\/(.+?)\?", url).group(1)
        
        req = urllib2.Request('http://json.dacast.com/b/'+prov+'/c/'+chan)
        req.add_header('User-Agent', UA)
        req.add_header('Referer', 'http://iframe.dacast.com')
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        #print jsonrsp['hls']
        
        #url='https://services.dacast.com/token/i/b/77649/c/423879'
        req2 = urllib2.Request('http://services.dacast.com/token/i/b/'+prov+'/c/'+chan)
        req2.add_header('User-Agent', UA)
        req2.add_header('Referer', 'http://iframe.dacast.com')
        opener = urllib2.build_opener()
        f2 = opener.open(req2)
        jsonrsp2 = json.loads(f2.read())
        #print jsonrsp2['token']
        
        STREAMPLAY(name,'http:'+jsonrsp['hls'] + jsonrsp2['token'] + '|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53',thumbnail)
        
        
        
        
        
        
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        
        
        ok=True
        vid=url.replace('http://player.vimeo.com/video/','')
        pipeurl = 'plugin://plugin.video.vimeo/play/?video_id=' + vid
        #print 'PIPE: ' + pipeurl
        #xbmc.executebuiltin("xbmc.PlayMedia("+pipeurl+")")
        item = xbmcgui.ListItem(path=pipeurl, iconImage='DefaultVideo.png', thumbnailImage='DefaultVideo.png')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return ok







#AXN Player via The Platform
def AXN(url):
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', UA)]
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        #print jsonrsp['entries'][0]['title'].encode('utf-8', 'ignore')
        
        for n in range(0, len(jsonrsp['entries'])):
            addLinkd(jsonrsp['entries'][n]['title'].encode('utf-8', 'ignore'),jsonrsp['entries'][n]['media$content'][0]['plfile$url'],str(jsonrsp['entries'][n]['media$content'][0]['plfile$duration']),5,jsonrsp['entries'][n]['plmedia$defaultThumbnailUrl'])
       








#BG прочит на история славянобългарская
def NERAZUMNI(url):
        addLink('Ползата от историята','http://istoriata.bg/assets/files/ISB-01.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Славянобългарска история','http://istoriata.bg/assets/files/ISB-02.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Историческо събрание за българския народ','http://istoriata.bg/assets/files/ISB-03.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Тук внимавай читателю, ще кажем накратко за сръбските крале','http://istoriata.bg/assets/files/ISB-04.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Пак завършваме разказа за Константин Шишман','http://istoriata.bg/assets/files/ISB-05.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Тук е потребно да се съберат заедно имената на българските крале и царе. Колкото се намират. И кой след кого е царувал','http://istoriata.bg/assets/files/ISB-06.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Събрано накратко колко знаменити били българските крале и царе','http://istoriata.bg/assets/files/ISB-07.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('За славянските учители','http://istoriata.bg/assets/files/ISB-08.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Тук събрахме накратко имената на българските светци, колкото са просияли от българския народ в последно време','http://istoriata.bg/assets/files/ISB-09.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Послесловие','http://istoriata.bg/assets/files/ISB-10.mp3',5,'http://paissiada.com/image/layout_set_logo?img_id=563167&t=1445707940926')
        addLink('Иван Вазов - Ода за Паисий','http://istoriata.bg/assets/files/ivan%20vazov%20oda%20za%20paisii.mp3',5,'http://www.desant.net/files/tn/139893929679157.jpg')
        addLink('Интервю с професор Илия Тодев','http://istoriata.bg/assets/files/videos/interviews/ilia_todev.mp4',5,'http://istoriata.bg/assets/files/videos/interviews/ilia_todev.jpg')
        addLink('Интервю с професор Вера Бонева','http://istoriata.bg/assets/files/videos/interviews/vera_boneva.mp4',5,'http://istoriata.bg/assets/files/videos/interviews/vera_boneva.jpg')









#Категории на видеата от vivahistory.bg
def VIVAHISTORY(url):
    addDir('Времева линия','https://spreadsheets.google.com/feeds/list/1EnKsyfWs207zCDLpzMGoLJNKQ41N_gIncFXlp_4cblA/1/public/values?alt=rss',25,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('Държавници и Политици','/people/statesmen-politicians/',26,'http://www.vivahistory.bg/res/img/silhouettes/politician.png')
    addDir('Военни','/people/military/',26,'http://www.vivahistory.bg/res/img/silhouettes/military.png')
    addDir('Чужденци','/people/foreigners/',26,'http://www.vivahistory.bg/res/img/silhouettes/foreigner.png')
    addDir('Революционери','/people/revolutionaries/',26,'http://www.vivahistory.bg/res/img/silhouettes/revolutionary.png')
    addDir('Фолклор','/culture/folklore/',26,'http://www.vivahistory.bg/res/img/silhouettes/bagpiper.png')
    addDir('Празници и обичаи','/culture/holidays-celebrations/',26,'http://www.vivahistory.bg/res/img/silhouettes/lazarka.png')
    addDir('Народно творчество','/culture/art/',26,'http://www.vivahistory.bg/res/img/silhouettes/HitarPetar.png')
    addDir('Опознай България','/facts/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('Любопитни факти','/facts/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('VIVA10','/viva10/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('За малчуганите','/kids/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')
    addDir('Тестове','/tests/',26,'http://www.vivahistory.bg/res/uploads/2015/10/vivahistory-logo80.png')








#Парсер на времевата линия на vivahistory.bg
def VIVATIMELINEPARSER(url):
        #url = "https://docs.google.com/spreadsheets/d/1EnKsyfWs207zCDLpzMGoLJNKQ41N_gIncFXlp_4cblA/pubhtml"
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #print data
        match = re.compile('<gsx:year>(.+?)</gsx:year>.*<gsx:endyear>(.*)</gsx:endyear>.*<gsx:headline>(.+?)</gsx:headline>.*\n.*poster="(.+?)"').findall(data)
        for start, end, title, cover in match:
            if end != '':
                name = start + ' - ' + end + 'г. ' + title
            else:
                name = start + 'г. ' + title
            video = cover.replace('jpg','webm')
            addLink(name,video,5,cover)







#Парсер на страниците от vivahistory.bg
def VIVAPAGEPARSER(url):
        #url = "/people/statesmen-politicians/"
        base = "http://www.vivahistory.bg"

        req = urllib2.Request(base+url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #print data
        match = re.compile('<img src="(.+?)" width="240" height="135" alt="(.+?)" />').findall(data) #<img src="/res/videos/people/thumbs/Alexander_I_Batenberg.jpg" width="240" height="135" alt="Княз Александър І Батенберг" />
        for cover, name in match:
            #name = name.replace('&bdquo;','"') # kavichki
            #name = name.replace('&ldquo;','"') # kavichki
            cover = base + cover
            video = cover.replace('thumbs/','').replace('jpg','mp4')
            addLink(name,video,5,cover)

        #други линкове
        match = re.compile('<h3>(.+?)</h3>\n.*\n.*poster="(.+?)".*src="(.+?)"').findall(data)
        for name, cover, video in match:
            name = name.replace('&bdquo;','"') # kavichki
            name = name.replace('&ldquo;','"') # kavichki
            cover = base + cover
            video = base + video
            addLink(name,video,5,cover)







#Новини от DW
def DW(url):
        d = feedparser.parse(url)
        #print d
        e = len(d.entries)
        count = 0
        pars = HTMLParser.HTMLParser()
        while (count < e):
            title=pars.unescape(d.entries[count].title).encode('utf-8', 'ignore')
            match = re.compile("href': u'(.+?)'").findall(str(d.entries[count].links))
            #print match[-1]
            #addLink(title,match[-1].replace('http://www.dw.com/static/stills/images/','http://tv-download.dw.de/dwtv_video/flv/').replace('.jpg','_sd_sor.mp4')+'|User-Agent=stagefright',5,match[-1])
            addLink(title,match[-1].replace('https://tvdownloaddw-a.akamaihd.net/stills/images/','http://tv-download.dw.de/dwtv_video/flv/').replace('.jpg','_sd_sor.mp4')+'|User-Agent=stagefright',5,match[-1])
            #print match[-1].replace('https://tvdownloaddw-a.akamaihd.net/stills/images/','http://tv-download.dw.de/dwtv_video/flv/').replace('.jpg','_sd_sor.mp4')+'|User-Agent=stagefright'
            count = count + 1






#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделно заглавие и неговите атрибути + продължителност към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLinkd(name,url,duration,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': 'Дълго описание на видеото...' } )
        liz.addStreamInfo("Video", { 'width': 1920, 'height': 1080, "duration": duration })
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param



params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode==1:
        INDEXCATPOLOMA(url)

elif mode==2:
        SCHOOLPEDIA(url)

elif mode==3:
        SEND2RESOLVER(url)

elif mode==4:
        INDEXCATBGTV2(url)

elif mode==5:
        STREAMPLAY(name,url,thumbnail)

elif mode==6:
        BGP(url)

elif mode==7:
        FEEDPLAY(url)

elif mode==8:
        RADIO(url)

elif mode==9:
        PODCAST(url)

elif mode==10:
        SEND2YT(name,url,thumbnail)

elif mode==11:
        SEND2VM(url)

elif mode==12:
        PRIKAZKI(url)

elif mode==13:
        CHANTUBE(name,url,thumbnail)

elif mode==14:
        INDEXCATCORENI(url)

elif mode==15:
        OPENSP(name,url,thumbnail)

elif mode==16:
        SEND2YTCLIP(name,url,thumbnail)

elif mode==17:
        UCHASE()

elif mode==18:
        INDEXCATUROCI(url)

elif mode==19:
        EVOLINK(name,url,thumbnail)

elif mode==20:
        INDEXCATAVTORI(url)

elif mode==21:
        RESOLVEAVTORI(url)

elif mode==22:
        LIVESTREAM(name,url,thumbnail)

elif mode==23:
        NERAZUMNI(url)

elif mode==24:
        VIVAHISTORY(url)

elif mode==25:
        VIVATIMELINEPARSER(url)

elif mode==26:
        VIVAPAGEPARSER(url)

elif mode==27:
        LIVETUBE(name,url,thumbnail)

elif mode==28:
        ZAKNIGI()

elif mode==29:
        ZAKNIGIPARSER(url)

elif mode==30:
        ZAKNIGIPARSER2(url)

elif mode==31:
        ZAKNIGIPLAYER(name,url)

elif mode==32:
        GRAMOFONCHE(url)

elif mode==33:
        GRAMOFONCHEPARSER(url)

elif mode==34:
        GRAMOFONCHERESOLVER(url)

elif mode==35:
        LSARCHIVE(url)

elif mode==36:
        DW(url)

elif mode==37:
        DACAST(name,url,thumbnail)

elif mode==38:
        AXN(url)

elif mode==40:
        STREAMPLAYR(name,url,thumbnail)

elif mode==41:
        HLSTP(name,url,thumbnail)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
