# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.error, urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import html
import urlresolver

#   plugin://plugin.video.youtube/play/?video_id=[VID]
#   plugin://plugin.video.vimeo/play/?video_id=[VID]

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.brigada'
__Addon = xbmcaddon.Addon(__addon_id__)
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
UA = 'Mozilla/5.0 (Macintosh; MacOS X10_14_3; rv;85.0) Gecko/20100101 Firefox/85.0' #За симулиране на заявка от  компютърен браузър
MUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/ 604.1.21 (KHTML, like Gecko) Version/ 12.0 Mobile/17A6278a Safari/602.1.26' #За симулиране на заявка от мобилно устройство
thumbnail = 'DefaultVideo.png'


#Хедъри за заявки услугата
bgtv2_headers = {
	'User-Agent': UA,
	'authority': 'sites.google.com',
	'accept': 'application/json, text/plain, */*',
	'dnt': '1',
	'origin': 'https://sites.google.com',
	'Connection': 'keep-alive',
	'sec-fetch-site': 'cross-site',
	'sec-fetch-mode': 'cors',
	'sec-fetch-dest': 'empty',
	'referer': 'https://sites.google.com',
	'accept-language': 'bg-BG,bg;q=0.9,en;q=0.8',
	'Accept-Encoding': 'gzip'
					}


#Списък на предаванията/филмите в BGTV2
def INDEX():
	#url = 'http://sites.google.com/site/apitvbg/shadowbbox.js' #cifri abvgd
	#url = 'http://sites.google.com/site/apitvbg/shadowex.js' #ejzik
	#url = 'http://sites.google.com/site/apitvbg/shadowlex.js' #klmno
	#url = 'http://sites.google.com/site/apitvbg/shadowp.js' #prs
	#url = 'http://sites.google.com/site/apitvbg/shadowpr.js' #s2 ^
	#url = 'http://sites.google.com/site/apitvbg/shadowvoz.js' #tufhtzsh6tiuia - problem s encoding
	#url = 'http://sites.google.com/site/apitvbg/shadowscx.js' #kratki film - shorts i tv
	#url = 'http://sites.google.com/site/apitvbg/shadowan.js'
	#url = 'http://sites.google.com/site/apitvbg/shadowbox.js' cifri a-u
	#url = 'http://sites.google.com/site/apitvbg/shadowboz.js' prstufhc46uq
	#url = 'http://sites.google.com/site/apitvbg/google_api.js' shorts

	li = ['http://sites.google.com/site/apitvbg/shadowbox.js', 'http://sites.google.com/site/apitvbg/shadowboz.js', 'http://sites.google.com/site/apitvbg/google_api.js'] #a-ia + shorts
	for url in li:
		response = requests.get(url, headers=bgtv2_headers)
		match= re.compile(' "(.+?)",.*:"(.+?)",').findall(response.text)
		for href,name in match:
			if not ('nfc.bg' in href or 'iframe' in name):
				addLink(html.unescape(name),href,1,thumbnail)
				#print (name + ' ' + href + ' ' + thumbnail)




#Обработка на избраното видео
def SEND2RESOLVER(url):
	print ('PRIMITIVE OLINK url: '+url)
	link = url
	url = url.replace('www.','')

	# Получаване на линкове
	sitelink = url
	response = requests.get(url, headers=bgtv2_headers)

	#YouTube
	yt = re.compile('youtu.*/(.+?)\?').findall(response.text)
	for vid in yt:
		sitelink = 'https://www.youtube.com/watch?v=' + vid
		print('YouTube playable link: '  + sitelink)
		pipeurl = 'plugin://plugin.video.youtube/play/?video_id=' + vid
		item = xbmcgui.ListItem(path=pipeurl)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

	#Vimeo
	vm = re.compile('player.vimeo.com/video/(.+?).auto').findall(response.text)
	for vid in vm:
		sitelink = 'https://player.vimeo.com/video/' + vid
		print('Vimeo playable link: '  + sitelink)
		#SEND2VM(vid)
		pipeurl = 'plugin://plugin.video.vimeo/play/?video_id=' + vid
		item = xbmcgui.ListItem(path=pipeurl)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


	#Директен линк
	dl = re.compile('file: "(.+?)"').findall(response.text)
	for link in dl:
		if not ('youtu' in link or 'vimeo' in link):
			sitelink = link
			print('Direct playable link: '  + sitelink)
			item = xbmcgui.ListItem(path=sitelink)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


	#Google Docs/Drive
	if '/preview' in response.text:
		gd = re.compile('src="(.+?/preview)').findall(response.text)
		for fm in gd:
			link=fm
	else:
		gd = re.compile("src='(.+?)&").findall(response.text)
		for gid in gd:
			print('Google Docs playable link: '  + gid)
			gid = gid.replace('https://video.google.com/get_player?docid=','')
			link = 'https://docs.google.com/file/d/'+gid+'/preview'
				
	hmf = urlresolver.HostedMediaFile(link)
	if hmf:
		try:
			#Play via universal urlresolver
			item = xbmcgui.ListItem(path=urlresolver.resolve(link))
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		except:
			#Problem
			xbmc.executebuiltin("Notification(BRIGADA,Заради авторски права сайтът хостващ видеото е премахнат.,20000)")







#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": name })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok


#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]

		return param



params=get_params()
url=None
name=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		INDEX()

elif mode==1:
		SEND2RESOLVER(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
