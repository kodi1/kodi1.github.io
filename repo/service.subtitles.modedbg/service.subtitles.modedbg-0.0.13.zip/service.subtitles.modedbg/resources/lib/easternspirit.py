# -*- coding: utf-8 -*-

from nsub import log_my, savetofile, list_key
from common import *
import xbmcgui
values = {'q': '','type': 'downloads_file','search_and_or': 'or','search_in': 'titles','sortby': 'relevancy'}

headers = {
    'Upgrade-Insecure-Requests' : '1',
    'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
    'Content-Type' : 'application/x-www-form-urlencoded',
    'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Accept-Encoding': 'gzip, deflate',
    'Referer' : 'http://www.easternspirit.org/forum/index.php?/files/',
    'Accept-Language' : 'en-US,en;q=0.8'
}

url = 'http://www.easternspirit.org/forum'


def get_id_url_n(txt, list):
  soup = BeautifulSoup(txt, 'html5lib')
  for link in soup.find_all("span", class_="ipsContained ipsType_break"):
    #print link
    href = link.find('a', href=True)
    title = link.getText()
    title = re.sub('[\r\n]+','',title)
    yr =  re.search('.*\((\d+)',title).group(1)
    title = re.sub(' \(.*\s+','',title)
    
    list.append({'url': href['href'],
              'info': title,
              'year': yr,
              'cds': '',
              'fps': '',
              'rating': '0.0',
              'id': __name__})
  return

def get_data(l, key):
  out = []
  for d in l:
    out.append(d[key])
  return out

def read_sub (mov):
  list = []

  values['q'] = mov
  enc_values = urllib.parse.urlencode(values)
  log_my('Url: ', (url) +enc_values, 'Headers: ', (headers))
  request = urllib.request.Request(url + '/index.php?/search/&'+enc_values.replace('+','%20'), None, headers)

  response = urllib.request.urlopen(request)
  log_my(response.code)


  if response.headers['Content-Encoding'] == 'gzip':
    data = gzip.decompress(response.read())
  else:
    log_my('Error: ', response.headers['Content-Encoding'])
    return None

  get_id_url_n(data, list)
  #if run_from_xbmc == False:
  for k in list_key:
    d = get_data(list, k)
    log_my(d)

  return list


        
def getResult(subs):
    IDs = [i[1] for i in subs]
    displays = [i[0] for i in subs]
    idx = xbmcgui.Dialog().select('Select subs',displays)
    if idx < 0: return None
    return IDs[idx]
      
def get_sub(id, sub_url, filename):
  request = urllib.request.Request(sub_url, None, headers)
  response = urllib.request.urlopen(request)
  mycook = response.headers['Set-Cookie']
  if response.headers['Content-Encoding'] == 'gzip':
    data = gzip.decompress(response.read())
  else:
    data = response.read()
    log_my('Error: ', response.headers['Content-Encoding'])
  match = re.findall("<a href='(.+?)' class='ipsButton ipsButton_fullWidth", data)
  log_my(response.code)
  nexturl = match[0].replace('&amp;','&')
  dheaders = {
    'Upgrade-Insecure-Requests' : '1',
    'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
    'Content-Type' : 'application/x-www-form-urlencoded',
    'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Referer' : 'http://www.easternspirit.org/forum/index.php?/files/',
    'Accept-Encoding' : 'gzip, deflate',
    'Accept-Language' : 'en-US,en;q=0.8',
    'Cookie': mycook,
    'Connection': 'keep-alive',
    'Referer': nexturl,
    'Host': 'www.easternspirit.org'
}
  
  request = urllib.request.Request(nexturl, None, dheaders)
  request.add_header('Cookie',mycook)
  log_my(response.code)
  response = urllib.request.urlopen(request)
  s = {} 
  if response.headers['Content-Type'] == 'application/x-rar-compressed':
    s['data'] = response.read()
    s['fname'] = response.headers['Content-Disposition'].split('filename=')[1].strip('"')
    return s
  else:
    #TV SERIES FIX
    if response.headers['Content-Encoding'] == 'gzip':
      data = gzip.decompress(response.read())
    else:
      data2 = response.read()
    data2 =  re.sub('[\r\n]+','',data2)
    data2 =  re.sub('&amp;','&',data2)
    match = re.findall("ipsType_break ipsContained'>([^<>]+)<.+?a href='([^']+)'", data2)
    sub_url = getResult(match)
    request = urllib.request.Request(sub_url, None, dheaders)
    request.add_header('Cookie',mycook)
    response = urllib.request.urlopen(request)
    log_my(response.code)
    s['data'] = response.read()
    s['fname'] = response.headers['Content-Disposition'].split('filename=')[1].strip('"')
    return s
