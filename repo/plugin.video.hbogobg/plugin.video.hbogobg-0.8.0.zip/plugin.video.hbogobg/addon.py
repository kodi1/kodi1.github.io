# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import base64
import time
import ssl
import uuid
import inputstreamhelper
import requests

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.hbogobg'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.hbogobg')

#Глобално търсене през търсачката на Коди, като YouTube addon-a
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'
MUA = 'Dalvik/2.1.0 (Linux; U; Android 8.0.0; Nexus 5X Build/OPP3.170518.006)'

pc = __settings__.getSetting('pc')
se = __settings__.getSetting('se')
language = __settings__.getSetting('language')
if language == '0':
	lang = 'Bulgarian'
	Code = 'BUL'
	srtsubs_path = xbmc.translatePath('special://temp/hbogo.Bulgarian.Forced.srt')
elif language == '1':
	lang = 'Bulgarian'
	Code = 'BUL'
	srtsubs_path = xbmc.translatePath('special://temp/hbogo.Bulgarian.Forced.srt')
elif language == '2':
	lang = 'English'
	Code = 'ENG'
	srtsubs_path = xbmc.translatePath('special://temp/hbogo.English.Forced.srt')
	

md = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_string = urllib.unquote_plus(__settings__.getSetting('lastsearch'))

operator = __settings__.getSetting('operator')
op_ids = [
'00000000-0000-0000-0000-000000000000', # Anonymous NonAuthenticated
'7d1d3d8a-f052-402a-a964-415da5da6aec', # Telenor Promo
'7d1d3d8a-f052-402a-a964-415da5da6aec', # HBO GO Vip/Club Bulgaria
'c5afc2d3-e50d-4ddf-bd66-d1c256cca142', # M SAT Cable EAD
'29c994ca-48bc-4b19-a0e7-44a25b51b241', # A1
'0b17bfc7-c6a3-457f-b3fa-76547606799f', # N3
'63cc0033-1f0d-40ad-bdca-d074dbac5e73', # NET1
'553c40d9-cf30-4a47-9051-cc7ac832e124', # NetSurf
'105cc484-80a2-4710-9b1c-6f73107bf58b', # NetWorx
'e8382e76-c870-4023-b099-4a9e5497175f', # Silistra TV
'4381c076-4942-43d2-8aa0-a1ab919aaf89', # Telekabel
'8d9d817a-aea5-4d9c-bf32-07ba91d66560', # Telenor
'60d4a508-dcc8-4d49-aacd-af9f4dc82a99', # Vivacom
'b52fda48-25b2-4623-af6b-e8e30ae7d645', # HBO Bulgaria
]
op_id = op_ids[int(operator)];

username = __settings__.getSetting('username')
password = __settings__.getSetting('password')

individualization = ""
goToken = ""
customerId = ""
GOcustomerId = ""
sessionId = '00000000-0000-0000-0000-000000000000'

loggedin_headers = {
	'User-Agent': UA,
	'Accept': '*/*',
	'Accept-Language': 'en-US,en;q=0.5',
	'Referer': 'https://www.hbogo.bg/',
	'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
	'Origin': 'https://www.hbogo.bg',
	'X-Requested-With': 'XMLHttpRequest',
	'GO-Language': 'BUL',
	'GO-requiredPlatform': 'CHBR',
	'GO-Token': '',
	'GO-SessionId': '',
	'GO-swVersion': '4.8.0',
	'GO-CustomerId': '',
	'Connection': 'keep-alive',
	'Accept-Encoding': ''
}

loggedviahbo_headers = {
'GO-requiredPlatform': 'CHBR',
'Origin': 'https://hbogo.bg',
'Accept-Encoding': '',
'Accept-Language': 'en-US,en;q=0.9',
'User-Agent': UA,
'Content-Type': 'application/json',
'Accept': '*/*',
'Referer': 'https://hbogo.bg/',
'GO-swVersion': '4.7.4',
'Connection': 'keep-alive',
'GO-CustomerId': ''
}

def LOGINVIAHBOPAYLOAD(indiv):
	return {
'Id':'',
'Action':'L',
'IsPromo':False,
'OperatorId':op_id,
'IsAnonymus':False,
'EmailAddress':username,
'Password':password,
'Nick':'',
'BirthYear':0,
'SubscribeForNewsletter':False,
'IpAddress':'',
'OperatorName':'HBO Bulgaria',
'Language':'BUL',
'CustomerCode':'',
'ServiceCode':'HBO_Premium',
'CountryName':'Bulgaria',
'AppLanguage':'BUL',
'AudioLanguage':'BUL',
'DefaultSubtitleLanguage':'BUL',
'AutoPlayNext':False,
'ProfileName':'',
'SubtitleSize':'MEDIUM',
'IsDefaultProfile':True,
'Gender':0,
'ZipCode':'',
'FirstName':'',
'LastName':'',
'SubscState':'VALID',
'CurrentDevice':{
	'Id':'',
	'Individualization':indiv,
	'Name':'COMP',
	'Platform':'COMP',
	'CreatedDate':time.strftime('%d/%m/%Y'),
	'IsDeleted':False,
	'OSName':'Linux',
	'Brand':'Chrome',
	'Modell':'61.0.3163',
	'SWVersion':'4.7.4'
}}



#Записване на автентификационните данни в настройките на добавката за постоянно; изпълнява се еднократно
def storeIndiv(indiv, custid):
	global individualization
	global customerId
	individualization = __settings__.getSetting('individualization')
	if individualization == "":
		__settings__.setSetting('individualization', indiv)
		individualization = indiv

	customerId = __settings__.getSetting('customerId')
	if customerId == "":
		__settings__.setSetting('customerId', custid)
		customerId = custid





#Регистриране на устройство в платформата; изпълнява се еднократно
def SILENTREGISTER():
	global goToken
	global individualization
	global customerId
	global sessionId
	
	#За HBO Bulgaria абонати
	if op_id =='b52fda48-25b2-4623-af6b-e8e30ae7d645':
		#req = urllib2.Request('https://api.ugw.hbogo.eu/v3.0/Authentication/BGR/JSON/BUL/COMP', json.dumps(loggedviahbo_payload), loggedviahbo_headers)
		payload = LOGINVIAHBOPAYLOAD("")
		req = urllib2.Request('https://api.ugw.hbogo.eu/v3.0/Authentication/BGR/JSON/BUL/COMP', json.dumps(payload), loggedviahbo_headers)
		
		opener = urllib2.build_opener()
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		
		try:
			if jsonrsp['ErrorMessage']:
				xbmcgui.Dialog().ok('Грешка', jsonrsp['Error'])
		except:
			#goToken = jsonrsp['Token']
			sessionId = jsonrsp['SessionId']
			custid = jsonrsp['Customer']['Id']
			indiv = jsonrsp['Customer']['CurrentDevice']['Individualization']
			storeIndiv(indiv, custid)
		
	#За абонати на телеком оператори
	else:
		storeIndiv(str(uuid.uuid1()), '00000000-0000-0000-0000-000000000000')





#Автентификация на абоната; изпълнява се преди отваряне на видео
def LOGIN():
	global sessionId
	global goToken
	global customerId
	global GOcustomerId
	global individualization
	global loggedin_headers

	customerId = __settings__.getSetting('customerId')
	individualization = __settings__.getSetting('individualization')

	if (individualization == ""):
		SILENTREGISTER()

	if (username=="" or password==""):
		xbmcgui.Dialog().ok('HBO GO','Регистрирайте се през сайта hbogo.bg и после посочете оператора си и въведете акаунта ви в настройките на тази приставка.')
		xbmcaddon.Addon(id='plugin.video.hbogobg').openSettings("Акаунт")
		xbmc.executebuiltin("Container.Refresh")
		return False
	
	#За HBO Bulgaria абонати
	if op_id =='b52fda48-25b2-4623-af6b-e8e30ae7d645':
		#req = urllib2.Request('https://api.ugw.hbogo.eu/v3.0/Authentication/BGR/JSON/BUL/COMP', json.dumps(loggedviahbo_payload), loggedviahbo_headers)
		payload = LOGINVIAHBOPAYLOAD(individualization)
		req = urllib2.Request('https://api.ugw.hbogo.eu/v3.0/Authentication/BGR/JSON/BUL/COMP', json.dumps(payload), loggedviahbo_headers)
		
		opener = urllib2.build_opener()
		f = opener.open(req)
		jsonrspl = json.loads(f.read())
		
		try:
			if jsonrspl['Data']['ErrorMessage']:
				xbmcgui.Dialog().ok('Грешка', jsonrspl['Data']['ErrorMessage'])
		except:
			pass
		
		sessionId = jsonrspl['SessionId']
		if sessionId == '00000000-0000-0000-0000-000000000000':
			xbmcgui.Dialog().ok('Влизането е неуспешно','Проверете правилно ли сте въвели акаунта си в настройките и опитайте отново.')
			xbmcaddon.Addon(id='plugin.video.hbogobg').openSettings("Акаунт")
			xbmc.executebuiltin("Action(Back)")
		else:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(username,'Време е за пуканки!', 4000, md+'DefaultUser.png'))
		
			goToken = jsonrspl['Token']
			GOcustomerId = jsonrspl['Customer']['Id']
		
			loggedin_headers['GO-SessionId'] = str(sessionId)
			loggedin_headers['GO-Token'] = str(goToken)
			loggedin_headers['GO-CustomerId'] = str(GOcustomerId)
		
		
	#За абонати на телеком оператори
	else:
		sn_headers = {
			'Host': 'bggwapi.hbogo.eu',
			'User-Agent': UA,
			'Accept': 'application/json',
			'Accept-Language': 'bg-BG',
			'Accept-Encoding': 'br, gzip, deflate',
			'Referer': 'https://gateway.hbogo.eu/signin/form',
			'Content-Type': 'application/json',
			'GO-CustomerId': '00000000-0000-0000-0000-000000000000',
			'Origin': 'https://gateway.hbogo.eu',
			'Connection': 'keep-alive'
			}

		payload = {
			"Action": "L",
			"AppLanguage": None,
			"ActivationCode": None,
			"AllowedContents": [],
			"AudioLanguage": None,
			"AutoPlayNext": False,
			"BirthYear": 0,
			"CurrentDevice": {
				"AppLanguage": "",
				"AutoPlayNext": False,
				"Brand": "Chrome",
				"CreatedDate": "",
				"DeletedDate": "",
				"Id": "00000000-0000-0000-0000-000000000000",
				"Individualization": individualization,
				"IsDeleted": False,
				"LastUsed": "",
				"Modell": "61.0.3163",
				"Name": "",
				"OSName": "Linux",
				"OSVersion": "",
				"Platform": "COMP",
				"SWVersion": "3.1.19.6338.281",
				"SubtitleSize": ""
			},
			"CustomerCode": "",
			"DebugMode": False,
			"DefaultSubtitleLanguage": None,
			"EmailAddress": username,
			"FirstName": "",
			"Gender": 0,
			"Id": "00000000-0000-0000-0000-000000000000",
			"IsAnonymus": True,
			"IsPromo": False,
			"Language": "BUL",
			"LastName": "",
			"Nick": "",
			"NotificationChanges": 0,
			"OperatorId": op_id,
			"OperatorName": "",
			"OperatorToken": "",
			"ParentalControl": {
				"Active": False,
				"Password": "",
				"Rating": 0,
				"ReferenceId": "00000000-0000-0000-0000-000000000000"
			},
			"Password": password,
			"PromoCode": "",
			"ReferenceId": "00000000-0000-0000-0000-000000000000",
			"SecondaryEmailAddress": "",
			"SecondarySpecificData": None,
			"ServiceCode": "",
			"SpecificData": None,
			"SubscribeForNewsletter": False,
			"SubscState": None,
			"SubtitleSize": "",
			"TVPinCode": "",
			"ZipCode": "",
			"PromoId": ""
		}
		
		response = requests.post('https://bggwapi.hbogo.eu/v2.1/Authentication/json/BUL/COMP',json=payload,verify=False,headers=sn_headers)
		jsonrspl = response.json()
		#print jsonrspl
		
		try:
			if jsonrspl['Data']['ErrorMessage']:
				xbmcgui.Dialog().ok('Грешка', jsonrspl['Data']['ErrorMessage'])
		except:
			pass
		
		sessionId = jsonrspl['SessionId']
		if sessionId == '00000000-0000-0000-0000-000000000000':
			xbmcgui.Dialog().ok('Влизането е неуспешно','Проверете правилно ли сте въвели акаунта си в настройките и опитайте отново.')
			xbmcaddon.Addon(id='plugin.video.hbogobg').openSettings("Акаунт")
			xbmc.executebuiltin("Action(Back)")
		else:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(username,'Време е за пуканки!', 4000, md+'DefaultUser.png'))
		
			goToken = jsonrspl['Token']
			GOcustomerId = jsonrspl['Customer']['Id']
		
			loggedin_headers['GO-SessionId'] = str(sessionId)
			loggedin_headers['GO-Token'] = str(goToken)
			loggedin_headers['GO-CustomerId'] = str(GOcustomerId)





#Категории съдържание
def CATEGORIES():
	if pc=='true':
		#addDir('KIDS','http://bgapi.hbogo.eu/v7/Group/json/BUL/ANMO/2afc0d1f-938c-44af-abe6-cdb16f46f821/0/0/0/0/0/0/True','',1,md+'DefaultFolder.png')
		LIST('http://bgapi.hbogo.eu/v8/Group/json/BUL/ANMO/2afc0d1f-938c-44af-abe6-cdb16f46f821/0/0/0/0/0/0/True')
	else:
		addDir('Търсене на филми, сериали...','search','',4,md+'DefaultAddonsSearch.png')
		#Заявка за получаване на категориите
		req = urllib2.Request('http://bgapi.hbogo.eu/v8/Groups/json/BUL/ANMO/0/True', None, loggedin_headers)
		opener = urllib2.build_opener()
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		
		try:
			if jsonrsp['ErrorMessage']:
				xbmcgui.Dialog().ok('Грешка', jsonrsp['ErrorMessage'])
		except:
			pass
		#Списък на категориите
		#addDir(jsonrsp['Items'][cat]['Name'].encode('utf-8', 'ignore'),jsonrsp['Items'][cat]['ObjectUrl'].replace('/0/{sort}/{pageIndex}/{pageSize}/0/0','/0/0/1/1024/0/0'),'',1,md+'DefaultFolder.png')
		for cat in range(0, 3): #До 4 за да включва и фалшивата детска категория
			addDir(jsonrsp['Items'][cat]['Name'].encode('utf-8', 'ignore'),jsonrsp['Items'][cat]['ObjectUrl'],'',1,md+'DefaultFolder.png')
		#Ръчно задаване на детската категория
		addDir(jsonrsp['Items'][3]['Name'].encode('utf-8', 'ignore'),'http://bgapi.hbogo.eu/v8/Group/json/BUL/ANMO/2afc0d1f-938c-44af-abe6-cdb16f46f821/0/0/0/0/0/0/True','',1,md+'DefaultFolder.png')





#Заявка за разлистване на категориите съдържание
def LIST(url):
	req = urllib2.Request(url, None, loggedin_headers)
	opener = urllib2.build_opener()
	f = opener.open(req)
	jsonrsp = json.loads(f.read())

	try:
		if jsonrsp['ErrorMessage']:
			xbmcgui.Dialog().ok('Грешка', jsonrsp['ErrorMessage'])
	except:
		pass
	#Ако има подкатегория/жанрове
	if len(jsonrsp['Container']) > 1:
		for Container in range(0, len(jsonrsp['Container'])):
			addDir(jsonrsp['Container'][Container]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][Container]['ObjectUrl'],'',1,md+'DefaultFolder.png')
	else:
		#Ако няма подкатегория/жанрове
		for titles in range(0, len(jsonrsp['Container'][0]['Contents']['Items'])):
			if jsonrsp['Container'][0]['Contents']['Items'][titles]['ContentType'] == 1: #1=MOVIE/EXTRAS, 2=SERIES(serial), 3=SERIES(episode)
				#Ако е филм    # addLink(ou,plot,ar,imdb,bu,cast,director,writer,duration,genre,name,on,py,mode)
				xbmcplugin.setContent(int(sys.argv[1]), 'movie')
				plot = jsonrsp['Container'][0]['Contents']['Items'][titles]['Abstract'].encode('utf-8', 'ignore')
				#if jsonrsp['Container'][0]['Contents']['Items'][titles]['AvailabilityTo'] is not None:
					#plot = plot + ' Филма е достъпен за гледане до: ' + jsonrsp['Container'][0]['Contents']['Items'][titles]['AvailabilityTo'].encode('utf-8', 'ignore')
				addLink(jsonrsp['Container'][0]['Contents']['Items'][titles]['ObjectUrl'],plot,jsonrsp['Container'][0]['Contents']['Items'][titles]['AgeRating'],jsonrsp['Container'][0]['Contents']['Items'][titles]['ImdbRate'],jsonrsp['Container'][0]['Contents']['Items'][titles]['BackgroundUrl'],[jsonrsp['Container'][0]['Contents']['Items'][titles]['Cast'].split(', ')][0],jsonrsp['Container'][0]['Contents']['Items'][titles]['Director'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Writer'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Duration'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Genre'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][titles]['OriginalName'],jsonrsp['Container'][0]['Contents']['Items'][titles]['ProductionYear'],5)
				#xbmc.log("GO: FILMI: DUMP: " + jsonrsp['Container'][0]['Contents']['Items'][titles]['ObjectUrl'], xbmc.LOGNOTICE)
				
			elif jsonrsp['Container'][0]['Contents']['Items'][titles]['ContentType'] == 3:
				#Ако е епизод на сериал    # addLink(ou,plot,ar,imdb,bu,cast,director,writer,duration,genre,name,on,py,mode)
				plot = jsonrsp['Container'][0]['Contents']['Items'][titles]['Abstract'].encode('utf-8', 'ignore')
				#if jsonrsp['Container'][0]['Contents']['Items'][titles]['AvailabilityTo'] is not None:
					#plot = plot + ' Епизода е достъпен за гледане до: ' + jsonrsp['Container'][0]['Contents']['Items'][titles]['AvailabilityTo'].encode('utf-8', 'ignore')
				addLink(jsonrsp['Container'][0]['Contents']['Items'][titles]['ObjectUrl'],plot,jsonrsp['Container'][0]['Contents']['Items'][titles]['AgeRating'],jsonrsp['Container'][0]['Contents']['Items'][titles]['ImdbRate'],jsonrsp['Container'][0]['Contents']['Items'][titles]['BackgroundUrl'],[jsonrsp['Container'][0]['Contents']['Items'][titles]['Cast'].split(', ')][0],jsonrsp['Container'][0]['Contents']['Items'][titles]['Director'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Writer'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Duration'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Genre'],jsonrsp['Container'][0]['Contents']['Items'][titles]['SeriesName'].encode('utf-8', 'ignore')+' СЕЗОН '+str(jsonrsp['Container'][0]['Contents']['Items'][titles]['SeasonIndex'])+' ЕПИЗОД '+str(jsonrsp['Container'][0]['Contents']['Items'][titles]['Index']),jsonrsp['Container'][0]['Contents']['Items'][titles]['OriginalName'],jsonrsp['Container'][0]['Contents']['Items'][titles]['ProductionYear'],5)
			else:
				#Ако е сериал
				addDir(jsonrsp['Container'][0]['Contents']['Items'][titles]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][titles]['ObjectUrl'],jsonrsp['Container'][0]['Contents']['Items'][titles]['Abstract'].encode('utf-8', 'ignore'),2,jsonrsp['Container'][0]['Contents']['Items'][titles]['BackgroundUrl'])





#Разлистване сезоните на сериал
def SEASON(url):
	xbmcplugin.setContent(int(sys.argv[1]), 'season')
	req = urllib2.Request(url, None, loggedin_headers)
	opener = urllib2.build_opener()
	f = opener.open(req)
	jsonrsp = json.loads(f.read())

	try:
		if jsonrsp['ErrorMessage']:
			xbmcgui.Dialog().ok('Грешка', jsonrsp['ErrorMessage'])
	except:
		pass
	for season in range(0, len(jsonrsp['Parent']['ChildContents']['Items'])):
		addDir(jsonrsp['Parent']['ChildContents']['Items'][season]['Name'].encode('utf-8', 'ignore'),jsonrsp['Parent']['ChildContents']['Items'][season]['ObjectUrl'],jsonrsp['Parent']['ChildContents']['Items'][season]['Abstract'].encode('utf-8', 'ignore'),3,jsonrsp['Parent']['ChildContents']['Items'][season]['BackgroundUrl'])





#Разлистване епизодите на сериал
def EPISODE(url):
	xbmcplugin.setContent(int(sys.argv[1]), 'episode')
	req = urllib2.Request(url, None, loggedin_headers)
	opener = urllib2.build_opener()
	f = opener.open(req)
	jsonrsp = json.loads(f.read())

	try:
		if jsonrsp['ErrorMessage']:
			xbmcgui.Dialog().ok('Грешка', jsonrsp['ErrorMessage'])
	except:
		pass

	for episode in range(0, len(jsonrsp['ChildContents']['Items'])):
		# addLink(ou,plot,ar,imdb,bu,cast,director,writer,duration,genre,name,on,py,mode)
		plot = jsonrsp['ChildContents']['Items'][episode]['Abstract'].encode('utf-8', 'ignore')
		#if jsonrsp['ChildContents']['Items'][episode]['AvailabilityTo'] is not None:
			#plot = plot + ' Епизода е достъпен за гледане до: ' + jsonrsp['ChildContents']['Items'][episode]['AvailabilityTo'].encode('utf-8', 'ignore')
		addLink(jsonrsp['ChildContents']['Items'][episode]['ObjectUrl'],plot,jsonrsp['ChildContents']['Items'][episode]['AgeRating'],jsonrsp['ChildContents']['Items'][episode]['ImdbRate'],jsonrsp['ChildContents']['Items'][episode]['BackgroundUrl'],[jsonrsp['ChildContents']['Items'][episode]['Cast'].split(', ')][0],jsonrsp['ChildContents']['Items'][episode]['Director'],jsonrsp['ChildContents']['Items'][episode]['Writer'],jsonrsp['ChildContents']['Items'][episode]['Duration'],jsonrsp['ChildContents']['Items'][episode]['Genre'],jsonrsp['ChildContents']['Items'][episode]['SeriesName'].encode('utf-8', 'ignore')+' СЕЗОН '+str(jsonrsp['ChildContents']['Items'][episode]['SeasonIndex'])+' '+jsonrsp['ChildContents']['Items'][episode]['Name'].encode('utf-8', 'ignore'),jsonrsp['ChildContents']['Items'][episode]['OriginalName'],jsonrsp['ChildContents']['Items'][episode]['ProductionYear'],5)





#Зареждане на видео
def PLAY(url):
	global goToken
	global individualization
	global customerId
	global GOcustomerId
	global sessionId
	global loggedin_headers

	#Логване, ако потребителя е анонимен
	if sessionId == '00000000-0000-0000-0000-000000000000':
		LOGIN()
	
	#Осигуряване на външни/алтернативни субтитри
	if se=='true':
		try:
			#print 'CID '+cid
			#http://bgapi.hbogo.eu/player50.svc/Content/json/BUL/COMP/
			#req = urllib2.Request('http://bgapi.hbogo.eu/v5/Content/json/BUL/MOBI/'+cid, None, loggedin_headers)
			req = urllib2.Request('http://bgapi.hbogo.eu/v8/Content/json/BUL/ANMO/'+cid, None, loggedin_headers)
			req.add_header('User-Agent', MUA)
			opener = urllib2.build_opener()
			f = opener.open(req)
			jsonrsps = json.loads(f.read())
			#print jsonrsps
			
			#Изтегляме официалните субтитри за епизода в TTML формат и ги конвертираме към SRT
			try:
				if jsonrsps['Subtitles'][0]['Code']==Code:
					slink = jsonrsps['Subtitles'][0]['Url']
				elif jsonrsps['Subtitles'][1]['Code']==Code:
					slink = jsonrsps['Subtitles'][1]['Url']
				req = urllib2.Request(slink, None, loggedin_headers)
				response = urllib2.urlopen(req)
				data=response.read()
				response.close()
					
				subs = re.compile('<p[^>]+begin="([^"]+)\D(\d+)"[^>]+end="([^"]+)\D(\d+)"[^>]*>([\w\W]+?)</p>').findall(data)
				row = 0
				buffer = ''
				for sub in subs:
					row = row + 1
					buffer += str(row) +'\n'
					buffer += "%s,%03d" % (sub[0], int(sub[1])) + ' --> ' + "%s,%03d" % (sub[2], int(sub[3])) + '\n'
					buffer += urllib.unquote_plus(sub[4]).replace('<br/>','\n').replace('<br />','\n').replace("\r\n", "").replace("&lt;", "<").replace("&gt;", ">").replace("\n    ","").strip()
					buffer += '\n\n'
					sub = 'true'
					with open(srtsubs_path, "w") as subfile:
						subfile.write(buffer)
				#Генерира грешка, за да изключи субтитрите при какъвто и да е проблем
				if sub != 'true':
					raise Exception()
					
			except:
				sub = 'false'
		except:
			sub = 'false'
	
	
	#Заявяване на ism Manifest
	#purchase_payload = '<Purchase xmlns="go:v5:interop"><AllowHighResolution>true</AllowHighResolution><ContentId>'+cid+'</ContentId><CustomerId>'+GOcustomerId+'</CustomerId><Individualization>'+individualization+'</Individualization><OperatorId>'+op_id+'</OperatorId><ClientInfo></ClientInfo><IsFree>false</IsFree><UseInteractivity>false</UseInteractivity></Purchase>'
	purchase_payload = '<Purchase xmlns="go:v8:interop" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><AllowHighResolution>true</AllowHighResolution><ContentId>'+cid+'</ContentId><CustomerId>'+GOcustomerId+'</CustomerId><Individualization>'+individualization+'</Individualization><OperatorId>'+op_id+'</OperatorId><IsFree>false</IsFree><RequiredPlatform>COMP</RequiredPlatform><UseInteractivity>false</UseInteractivity></Purchase>'

	purchase_headers = {
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Accept-Encoding': '',
		'Accept-Language': 'en-US,en;q=0.8',
		'Connection': 'keep-alive',
		'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'GO-CustomerId': str(GOcustomerId),
		'GO-requiredPlatform': 'CHBR',
		'GO-SessionId': str(sessionId),
		'GO-swVersion': '4.7.4',
		'GO-Token': str(goToken),
		'Origin': 'https://www.hbogo.bg',
		'User-Agent': UA
		}

	#req = urllib2.Request('https://bgapi.hbogo.eu/v5/Purchase/Json/BUL/COMP', purchase_payload, purchase_headers)
	req = urllib2.Request('https://bgapi.hbogo.eu/v8/Purchase/Json/BUL/COMP', purchase_payload, purchase_headers)
	opener = urllib2.build_opener()
	f = opener.open(req)
	jsonrspp = json.loads(f.read())
	#print jsonrspp

	try:
		if jsonrspp['ErrorMessage']:
			xbmcgui.Dialog().ok('Грешка', jsonrspp['ErrorMessage'])
	except:
		pass

	MediaUrl = jsonrspp['Purchase']['MediaUrl'] + "/Manifest"
	
	PlayerSessionId = jsonrspp['Purchase']['PlayerSessionId']
	x_dt_auth_token = jsonrspp['Purchase']['AuthToken']
	dt_custom_data = base64.b64encode("{\"userId\":\"" + GOcustomerId + "\",\"sessionId\":\"" + PlayerSessionId + "\",\"merchant\":\"hboeurope\"}")

	#Възпроизвеждане на видеото
	is_helper = inputstreamhelper.Helper('ism', drm='com.widevine.alpha')
	if is_helper.check_inputstream():
		li = xbmcgui.ListItem(iconImage=thumbnail, thumbnailImage=thumbnail, path=MediaUrl)
		if (se=='true' and sub=='true'): #Задаване на външни субтитри, ако е избран този режим
			li.setSubtitles([srtsubs_path])
		license_server = 'https://lic.drmtoday.com/license-proxy-widevine/cenc/'
		license_headers = 'dt-custom-data=' + dt_custom_data + '&x-dt-auth-token=' + x_dt_auth_token + '&Origin=https://www.hbogo.bg&Content-Type='
		license_key = license_server + '|' + license_headers + '|R{SSM}|JBlicense'
		
		li.setProperty('inputstreamaddon', 'inputstream.adaptive')
		li.setProperty('inputstream.adaptive.manifest_type', 'ism')
		li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
		li.setProperty('inputstream.adaptive.license_data', 'ZmtqM2xqYVNkZmFsa3Izag==')
		li.setProperty('inputstream.adaptive.license_key', license_key)
		
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)





#Търсачка
def SEARCH():
	keyb = xbmc.Keyboard(search_string, 'Търсене на филми, сериали...')
	keyb.doModal()
	searchText = ''
	if (keyb.isConfirmed()):
		searchText = urllib.quote_plus(keyb.getText())
		if searchText == "":
			addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','','',md+'DefaultFolderBack.png')
		else:
			#Записване на заявката за търсене в настройките
			__settings__.setSetting('lastsearch', searchText)
			#Провеждане на търсене
			#req = urllib2.Request('https://bgapi.hbogo.eu/v5/Search/Json/BUL/COMP/'+searchText.decode('utf-8', 'ignore').encode('utf-8', 'ignore')+'/0', None, loggedin_headers)
			req = urllib2.Request('https://bgapi.hbogo.eu/v8/Search/Json/BUL/ANMO/'+searchText.decode('utf-8', 'ignore').encode('utf-8', 'ignore')+'/0/0/0/0/0/1', None, loggedin_headers)
			opener = urllib2.build_opener()
			f = opener.open(req)
			jsonrsp = json.loads(f.read())        
			#print jsonrsp

			try:
				if jsonrsp['ErrorMessage']:
					xbmcgui.Dialog().ok('Грешка', jsonrsp['ErrorMessage'])
			except:
				pass

			br=0
			for index in range(0, len(jsonrsp['Container'][0]['Contents']['Items'])):
				if (jsonrsp['Container'][0]['Contents']['Items'][index]['ContentType'] == 1 or jsonrsp['Container'][0]['Contents']['Items'][index]['ContentType'] == 7): #1,7=MOVIE/EXTRAS, 2=SERIES(serial), 3=SERIES(episode)
					#Ако е филм    # addLink(ou,plot,ar,imdb,bu,cast,director,writer,duration,genre,name,on,py,mode)
					#addLink(jsonrsp['Container'][0]['Contents']['Items'][index]['ObjectUrl'],jsonrsp['Container'][0]['Contents']['Items'][index]['Abstract'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['AgeRating'],jsonrsp['Container'][0]['Contents']['Items'][index]['ImdbRate'],jsonrsp['Container'][0]['Contents']['Items'][index]['BackgroundUrl'],[jsonrsp['Container'][0]['Contents']['Items'][index]['Cast'].split(', ')][0],jsonrsp['Container'][0]['Contents']['Items'][index]['Director'],jsonrsp['Container'][0]['Contents']['Items'][index]['Writer'],jsonrsp['Container'][0]['Contents']['Items'][index]['Duration'],jsonrsp['Container'][0]['Contents']['Items'][index]['Genre'],jsonrsp['Container'][0]['Contents']['Items'][index]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['OriginalName'],jsonrsp['Container'][0]['Contents']['Items'][index]['ProductionYear'],5)
					addLink(jsonrsp['Container'][0]['Contents']['Items'][index]['ObjectUrl'],'',jsonrsp['Container'][0]['Contents']['Items'][index]['AgeRating'],jsonrsp['Container'][0]['Contents']['Items'][index]['ImdbRate'],jsonrsp['Container'][0]['Contents']['Items'][index]['BackgroundUrl'],[jsonrsp['Container'][0]['Contents']['Items'][index]['Cast'].split(', ')][0],jsonrsp['Container'][0]['Contents']['Items'][index]['Director'],jsonrsp['Container'][0]['Contents']['Items'][index]['Writer'],jsonrsp['Container'][0]['Contents']['Items'][index]['Duration'],jsonrsp['Container'][0]['Contents']['Items'][index]['Genre'],jsonrsp['Container'][0]['Contents']['Items'][index]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['OriginalName'],jsonrsp['Container'][0]['Contents']['Items'][index]['ProductionYear'],5)
				elif jsonrsp['Container'][0]['Contents']['Items'][index]['ContentType'] == 3:
					#Ако е епизод на сериал    # addLink(ou,plot,ar,imdb,bu,cast,director,writer,duration,genre,name,on,py,mode)
					#addLink(jsonrsp['Container'][0]['Contents']['Items'][index]['ObjectUrl'],jsonrsp['Container'][0]['Contents']['Items'][index]['Abstract'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['AgeRating'],jsonrsp['Container'][0]['Contents']['Items'][index]['ImdbRate'],jsonrsp['Container'][0]['Contents']['Items'][index]['BackgroundUrl'],[jsonrsp['Container'][0]['Contents']['Items'][index]['Cast'].split(', ')][0],jsonrsp['Container'][0]['Contents']['Items'][index]['Director'],jsonrsp['Container'][0]['Contents']['Items'][index]['Writer'],jsonrsp['Container'][0]['Contents']['Items'][index]['Duration'],jsonrsp['Container'][0]['Contents']['Items'][index]['Genre'],jsonrsp['Container'][0]['Contents']['Items'][index]['SeriesName'].encode('utf-8', 'ignore')+' '+jsonrsp['Container'][0]['Contents']['Items'][index]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['OriginalName'],jsonrsp['Container'][0]['Contents']['Items'][index]['ProductionYear'],5)
					addLink(jsonrsp['Container'][0]['Contents']['Items'][index]['ObjectUrl'],'',jsonrsp['Container'][0]['Contents']['Items'][index]['AgeRating'],jsonrsp['Container'][0]['Contents']['Items'][index]['ImdbRate'],jsonrsp['Container'][0]['Contents']['Items'][index]['BackgroundUrl'],[jsonrsp['Container'][0]['Contents']['Items'][index]['Cast'].split(', ')][0],jsonrsp['Container'][0]['Contents']['Items'][index]['Director'],jsonrsp['Container'][0]['Contents']['Items'][index]['Writer'],jsonrsp['Container'][0]['Contents']['Items'][index]['Duration'],jsonrsp['Container'][0]['Contents']['Items'][index]['Genre'],jsonrsp['Container'][0]['Contents']['Items'][index]['SeriesName'].encode('utf-8', 'ignore')+' '+jsonrsp['Container'][0]['Contents']['Items'][index]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['OriginalName'],jsonrsp['Container'][0]['Contents']['Items'][index]['ProductionYear'],5)
				else:
					#Ако е сериал
					#addDir(jsonrsp['Container'][0]['Contents']['Items'][index]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['ObjectUrl'],jsonrsp['Container'][0]['Contents']['Items'][index]['Abstract'].encode('utf-8', 'ignore'),2,jsonrsp['Container'][0]['Contents']['Items'][index]['BackgroundUrl'])
					addDir(jsonrsp['Container'][0]['Contents']['Items'][index]['Name'].encode('utf-8', 'ignore'),jsonrsp['Container'][0]['Contents']['Items'][index]['ObjectUrl'],'',2,jsonrsp['Container'][0]['Contents']['Items'][index]['BackgroundUrl'])
				br=br+1
			if br==0:
				addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','','',md+'DefaultFolderBack.png')





def addLink(ou,plot,ar,imdb,bu,cast,director,writer,duration,genre,name,on,py,mode):
	cid = ou.rsplit('/',2)[1]
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&cid="+cid+"&thumbnail="+bu
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=bu, thumbnailImage=bu)
	liz.setArt({ 'thumb': bu,'poster': bu, 'banner' : bu, 'fanart': bu })
	liz.setInfo( type="Video", infoLabels={ "plot": plot, "mpaa": str(ar)+'+', "rating": imdb, "cast": cast, "director": director, "writer": writer, "duration": duration, "genre": genre, "title": name, "originaltitle": on, "year": py } )
	liz.addStreamInfo('video', { 'width': 1920, 'height': 1080 })
	liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
	liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
	liz.setProperty("IsPlayable" , "true")
	
	contextmenu = []
	contextmenu.append(('Информация', 'XBMC.Action(Info)'))
	liz.addContextMenuItems(contextmenu)
	
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,plot,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
	
	if len(plot)>0:
		contextmenu = []
		contextmenu.append(('Информация', 'XBMC.Action(Info)'))
		liz.addContextMenuItems(contextmenu)
	
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



params=get_params()
url=None
name=None
iconimage=None
mode=None
ssl._create_default_https_context = ssl._create_unverified_context

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		thumbnail=str(params["thumbnail"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass
try:
		cid=str(params["cid"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()

elif mode==1:
		LIST(url)

elif mode==2:
		SEASON(url)

elif mode==3:
		EPISODE(url)

elif mode==4:
		SEARCH()

elif mode==5:
		PLAY(url)

elif mode==6:
		SILENTREGISTER()

elif mode==7:
		LOGIN()


xbmcplugin.endOfDirectory(int(sys.argv[1]))