1. Install from "BG Repo" or manually by downloading the zip
2. Go to addon's settings and add your MAC address
3. Go to Kodi PVR addons and enble Simple IPTV PVR
4. Go to Simple IPTV PVR settings and:

  a) Set playlist path:
  
    your-kodi-userdata-folder\addon_data\plugin.program.tvbgpvr.backend\playlist.m3u
  
  b) Set EPG url to:
  
    https://is.gd/tvbgepg
