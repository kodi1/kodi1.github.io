# plugin.video.gong.play
Gong Play Video Provider

# General
Добавка за Kodi™ за гледане на спортно съдържание от сайта Play.Gong.Bg. Услугата изисква активен акаунт и платен абонамент в Play.Gong.Bg!
***
A video addon for Kodi™ (formerly known as XBMC™) for watching live sport events from the Play.Gong.Bg service. Note that, an active account and paid subscription is required in order to use the play.gong.bg service!

# Disclaimer
Some parts of this addon may not be legal in your country of residence - please check with your local laws before installing.
***	
Някои елементи на тази приставка, може да нямат уредени авторски права в България. Името, логото, интернет адреса и сайтът поместен на него са собственост на MTG. Приставката се разпространява под GPL2 лиценз.