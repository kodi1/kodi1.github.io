# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.parse, urllib.error
import inputstreamhelper
import requests
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import base64



#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.tubi'
__Addon = xbmcaddon.Addon(__addon_id__)
md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "resources/media/")
subfile = xbmcvfs.translatePath('special://temp/tubi.English.srt')
api = 'https://tubitv.com/oz/'

try:
    response = requests.get(base64.b64decode('aHR0cHM6Ly9hbmRyb21lZGEuZXUub3JnL2FkZG9ucy9nZXR1c2VyYWdlbnQucGhwP2FuPQ==').decode('utf-8')+__addon_id__, headers={'Accept': 'application/json', 'Accept-Charset': 'UTF-8', 'Accept-Language': 'bg,en-US;q=0.7,en;q=0.3', 'Accept-Encoding': 'identity'})
    jsonrsp = response.json()
    UA = jsonrsp['hua']
except:
    UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:119.0) Gecko/20100101 Firefox/119.0' #За симулиране на заявка от  компютърен браузър


#Хедъри за заявки към API на услугата
tubi_headers = {
    'User-Agent': UA,
    'Accept': '*/*',
    'Accept-Language': 'en-US;q=0.7,en;q=0.3',
    'Accept-Encoding': 'identity',
    'X-Moz': 'prefetch',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'TE': 'trailers',
    'Alt-Used': 'tubitv.com',
    'Origin': 'https://tubitv.com/',
    'Referer': 'https://tubitv.com/'
                    }




#Категории на съдържанието
def CATEGORIES():
        try:
            response = requests.get(api+'containers?isKidsModeEnabled=false&groupStart=0&version=6.1.0', headers=tubi_headers)
            jsonrsp = response.json()
            #print jsonrsp['hash']['featured']['title']
            #print jsonrsp['hash']['featured']['id']
            
            addDir('Search',api+'search/','Search in TUBI Database',4,md+'DefaultAddonsSearch.png')
            
            for categories in range(0, len(jsonrsp['list'])-1):
                try:
                    desc = jsonrsp['hash'][jsonrsp['list'][categories]]['description']
                except:
                    desc = ' '
                try:
                    Cover = jsonrsp['hash'][jsonrsp['list'][categories]]['thumbnail']
                except:
                    Cover = md+'DefaultFolder.png'
                addDir(jsonrsp['hash'][jsonrsp['list'][categories]]['title'],jsonrsp['list'][categories],desc,1,Cover)
        except:
            xbmcgui.Dialog().ok('TUBITV: This is geo-blocked content!', 'You must have USA IP address in order to access this content or services.')
        #Край на обхождането






#Разлистване заглавията от отделните категории
def INDEX(url):
        try:
            response = requests.get(api+'containers/'+url+'/content?cursor=1&limit=6000', headers=tubi_headers)
            jsonrsp = response.json()
            #print(jsonrsp)
        
            #Начало на обхождането
            for movie in jsonrsp['contents'].keys(): #Обхождане по името/ключа на елемента, без индекс
                try:
                    if jsonrsp['contents'][movie]['type'] == 'v': #Ако е игрален филм
                        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
                        #addLink(name,url,vd,plot,year,mpaa,cast,director,mode,iconimage)
                        try:
                            addLink(jsonrsp['contents'][movie]['title'],jsonrsp['contents'][movie]['id'],str(jsonrsp['contents'][movie]['duration']),jsonrsp['contents'][movie]['description'],str(jsonrsp['contents'][movie]['year']),jsonrsp['contents'][movie]['ratings'][0]['value'],jsonrsp['contents'][movie]['actors'],jsonrsp['contents'][movie]['directors'],3,jsonrsp['contents'][movie]['posterarts'][0])
                        except:
                            addLink(jsonrsp['contents'][movie]['title'],jsonrsp['contents'][movie]['id'],str(jsonrsp['contents'][movie]['duration']),'',str(jsonrsp['contents'][movie]['year']),jsonrsp['contents'][movie]['ratings'][0]['value'],jsonrsp['contents'][movie]['actors'],jsonrsp['contents'][movie]['directors'],3,jsonrsp['contents'][movie]['posterarts'][0])
                    elif jsonrsp['contents'][movie]['type'] == 's': #Ако е сериал
                        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
                        #addDir(name,url,plot,mode,iconimage)
                        try:
                            addDir(jsonrsp['contents'][movie]['title'],jsonrsp['contents'][movie]['id'],jsonrsp['contents'][movie]['description'],2,jsonrsp['contents'][movie]['posterarts'][0])
                        except:
                            addDir(jsonrsp['contents'][movie]['title'],jsonrsp['contents'][movie]['id'],'',2,jsonrsp['contents'][movie]['posterarts'][0])
                except:
                    pass
                xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
        except:
            xbmcgui.Dialog().ok('TUBITV: This is geo-blocked content!', 'You must have USA IP address in order to access this content or services.')
        #Край на обхождането
        
        






#Разлистване епизодите на сериал
def EPISODES(url):
        response = requests.get(api+'videos/0'+url+'/content', headers=tubi_headers)
        jsonrsp = response.json()
        #print jsonrsp['k'][0]
        
        #Начало на обхождането
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        try:
            for season in range(0, len(jsonrsp['children'])):
                for episode in range(0, len(jsonrsp['children'][season]['children'])):
                    try:
                        addLink(jsonrsp['children'][season]['children'][episode]['title'],jsonrsp['children'][season]['children'][episode]['id'],str(jsonrsp['children'][season]['children'][episode]['duration']),jsonrsp['children'][season]['children'][episode]['description'],str(jsonrsp['children'][season]['children'][episode]['year']),jsonrsp['children'][season]['children'][episode]['ratings'][0]['value'],jsonrsp['children'][season]['children'][episode]['actors'],jsonrsp['children'][season]['children'][episode]['directors'],3,jsonrsp['children'][season]['children'][episode]['thumbnails'][0])
                    except:
                        addLink(jsonrsp['children'][season]['children'][episode]['title'],jsonrsp['children'][season]['children'][episode]['id'],str(jsonrsp['children'][season]['children'][episode]['duration']),'',str(jsonrsp['children'][season]['children'][episode]['year']),jsonrsp['children'][season]['children'][episode]['ratings'][0]['value'],[''],jsonrsp['children'][season]['children'][episode]['directors'],3,jsonrsp['children'][season]['children'][episode]['thumbnails'][0])
            #Край на обхождането
        except:
            pass








#Зареждане на видео
def PLAY(url):
        response = requests.get(api+'videos/'+url+'/content', headers=tubi_headers)
        jsonrsp = response.json()
        #print jsonrsp['url']
        
        #Изтегляне на субтитри
        suburl=''
        try:
            suburl=jsonrsp['subtitles'][0]['url']
            opener = urllib.request.build_opener()
            opener.addheaders = [('User-Agent', 'UA')]
            urllib.request.install_opener(opener)
            urllib.request.urlretrieve(suburl, subfile)
            sub = 'true'
        except:
            sub = 'false'
        
        if (jsonrsp['url'] != ''):
            li = xbmcgui.ListItem(path=jsonrsp['url'])
        else:
            is_helper = inputstreamhelper.Helper('hls', drm='com.widevine.alpha')
            if is_helper.check_inputstream():
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('TUBI','Licensed video', 2000, md+'DefaultGenre.png'))
                li = xbmcgui.ListItem(path=jsonrsp['video_resources'][3]['manifest']['url'])
                li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                licKeyUrl = jsonrsp['video_resources'][3]['license_server']['url']
                li.setProperty('inputstream.adaptive.license_key', licKeyUrl)

        li.setArt({ 'thumb': jsonrsp['thumbnails'][0],'poster': jsonrsp['thumbnails'][0], 'banner' : jsonrsp['thumbnails'][0], 'fanart': jsonrsp['thumbnails'][0], 'icon': jsonrsp['thumbnails'][0] })
        li.setInfo( type="Video", infoLabels={ "Title": jsonrsp['title'], "Plot": jsonrsp['description'] } )
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+urllib.parse.quote_plus(UA)+'&Referer=https://tubitv.com')

        if sub=='true': #Задаване на външни субтитри, ако има такива
            li.setSubtitles([subfile])
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('TUBI','Loaded English subtitles', 4000, md+'DefaultAddonSubtitles.png'))
            xbmc.sleep(1000) #Винаги зареждай така субтитри, иначе може да не се визуализират, ако няма изчакване!
        else:
            xbmc.Player().showSubtitles(False)
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        except:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('TUBI','Video Not Found!', 4000, md+'DefaultIconError.png'))






#Търсачка
def SEARCH(url):
        keyb = xbmc.Keyboard('', 'Search in TUBI Database')
        keyb.doModal()
        searchText = ''
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
            searchText=searchText.replace(' ','+')
            searchurl = url + searchText
            searchurl = searchurl.encode('utf-8')
            SEARCHCONTENT(searchurl)
        else:
            addDir('Go to main menu...','','',md+'DefaultFolderBack.png')




        
#Разлистване заглавията от търсенето
def SEARCHCONTENT(url):
        response = requests.get(url, headers=tubi_headers)
        jsonrsp = response.json()
        
        #Начало на обхождането
        for movie in range(0, len(jsonrsp)):
            try:
                if jsonrsp[movie]['type'] == 'v': #Ако е игрален филм
                    xbmcplugin.setContent(int(sys.argv[1]), 'movie')
                    addLink(jsonrsp[movie]['title'],jsonrsp[movie]['id'],str(jsonrsp[movie]['duration']),jsonrsp[movie]['description'],jsonrsp[movie]['year'],jsonrsp[movie]['ratings'][0]['value'],jsonrsp[movie]['actors'],jsonrsp[movie]['directors'],3,jsonrsp[movie]['posterarts'][0])
                elif jsonrsp[movie]['type'] == 's': #Ако е сериал
                    addDir(jsonrsp[movie]['title'],jsonrsp[movie]['id'],jsonrsp[movie]['description'],4,jsonrsp[movie]['posterarts'][0])
            except:
                pass
            xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
        #Край на обхождането







#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,vd,plot,year,mpaa,cast,director,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
        liz.setInfo( type="Video", infoLabels={ "title": name, "duration": vd, "plot": plot, "year": year, "mpaa": mpaa, "cast": cast, "director": director } )
        liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
        liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
        liz.setProperty("IsPlayable" , "true")
        
        contextmenu = []
        contextmenu.append(('Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextmenu)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,plot,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
        
        if len(desc)>0:
            contextmenu = []
            contextmenu.append(('Information', 'XBMC.Action(Info)'))
            liz.addContextMenuItems(contextmenu)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=uurllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        CATEGORIES()
    
elif mode==1:
        INDEX(url)

elif mode==2:
        EPISODES(url)

elif mode==3:
        PLAY(url)

elif mode==4:
        SEARCH(url)

elif mode==5:
        SEARCHCONTENT(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
