# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.error, urllib.parse
#import http.cookiejar as cj
#import http.cookiejar
import requests
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import inputstreamhelper

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.vatim'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.vatim')
username = __settings__.getSetting('username')
password = __settings__.getSetting('password')

md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "resources/media/")
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:90.0) Gecko/20100101 Firefox/90.0' #За симулиране на заявка от компютърен браузър
LG = 'http://vatim.xyz/Account/Login'
logged_in = False

#Хедъри за заявки към услугата
vt_headers = {
	'User-Agent': UA,
	'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Origin': 'http://vatim.xyz',
	'Referer': LG,
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'accept-language': 'bg,en-US;q=0.7,en;q=0.3',
	'Accept-Encoding': 'gzip'
				}


#Генериране на сесия
def LOGIN():
	s = requests.Session()
	response1 = s.get(LG, headers=vt_headers)
	matcht = re.search('<input name="__RequestVerificationToken" type="hidden" value="(.+?)" />', response1.text)
	payload = {'__RequestVerificationToken': matcht.group(1), 'email': username, 'password': password }
	response2 = s.post(LG, data=payload, headers=vt_headers)
	#print (response2.text)
	#matchl = re.search('<a class="email" href="/Account/Manage" title="Manage">(.+?)</a>', response2.text)
	#xbmcgui.Dialog().ok('Logged In As:',str(matchl.group(1)))
	logged_in = True
	return s




#Меню с директории в приставката
def CATEGORIES():
		addDir('Каталог','http://vatim.xyz/Catalog',1,'http://vatim.xyz/Images/logo1.png')
		addLink('Vatim TV','http:///tv1.dragonsclan.org/tva/tvn/playlist.m3u8',3,'http://vatim.xyz/Images/Serials/idx/vatimtv-1.jpg')
		addDir('LVL UP','http://vatim.xyz/LVLUP',1,'http://vatim.xyz/Images/logo1.png')
		addLink('Лабиринт','/Labyrinth',3,'http://vatim.xyz/Images/Serials/labyrinth/labyrinth-bg.jpg')
		addLink('Лапута: Замък в небето','/Laputa',3,'http://vatim.xyz/Images/Serials/laputa/laputa1.jpg')
		addLink('Атлантида: Загубената империя','https:///voe.sx/e/fsiltwqeqe65',3,'https://filmisub.com/uploads/movies/10865/thumbs/9kbLIQEj99g5Hb9g1IG3VNdtt3h.jpg')
		addLink('Чудотворен свят: Ню Йорк','/LVLUP/Miraculous-ny',3,'http://vatim.xyz/Images/Serials/main/JPEG/mxposter.jpg')
		addLink('Несъвършенна магия','/LVLUP/%D0%9D%D0%B5%D1%81%D1%8A%D0%B2%D1%8A%D1%80%D1%88%D0%B5%D0%BD%D0%B0-%D0%9C%D0%B0%D0%B3%D0%B8%D1%8F',3,'http://vatim.xyz/Images/Serials/main/JPEG/nsmp.jpg')
		addLink('Зомбита 1','/LVLUP/%D0%97%D0%BE%D0%BC%D0%B1%D0%B8%D1%82%D0%B0',3,'http://vatim.xyz/Images/Serials/main/JPEG/zombita1.jpg')
		addLink('Зомбита 2','/LVLUP/%D0%97%D0%BE%D0%BC%D0%B1%D0%B8%D1%82%D0%B02',3,'http://vatim.xyz/Images/Serials/main/JPEG/zombi2p.jpg')
		addLink('Детегледачки в акция','/Detegledachki-v-akcia',3,'http://vatim.xyz/Images/Serials/main/JPEG/detegledachki-v-akcia.jpg')
		addLink('Наследниците 1','https:///voe.sx/e/tth3s99d7kul',3,'https://www.filmi2k.com/wp-content/uploads/2016/04/Descendants.jpg')
		addLink('Наследниците 2','https:///voe.sx/e/p7y2zo4pgrfs',3,'https://www.filmi2k.com/wp-content/uploads/2017/08/Descendants.2.2017.jpg')
		addLink('Наследниците 3','https:///voe.sx/e/hhy5ywljbiud',3,'https://www.filmi2k.com/wp-content/uploads/2019/08/Descendants-3-2019.jpg')
		addLink('Замръзналото кралство 1','https:///voe.sx/e/si7eii310zki',3,'https://filmisub.com/uploads/posts/zamunda/416166/416166-poster150.jpg')
		addLink('Замръзналото кралство 2','https:///voe.sx/e/e07p6wdq09bf',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1590517265/thumbs/themoviedb-1590517265-poster.jpg')
		addLink('Малката стъпка','https:///voe.sx/e/ydbn8luiv6o9',3,'https://filmisub.com/uploads/posts/zamunda/555963/thumbs/555963-poster.jpg')
		addLink('Как да си дресираш дракон 2','https:///voe.sx/e/yntzn5alpxq9',3,'https://filmisub.com/uploads/movies/82702/thumbs/cGwNjJvfRjc7VFOI0hIhi8pLLvS.jpg')
		addLink('Как да си дресираш дракон 3','https:///voe.sx/e/27q4lrnpf8qj',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1554222530/thumbs/themoviedb-1554222530-poster.jpg')
		addLink('Бикът Фердинанд','https:///voe.sx/e/7hfawclqdcz7',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1519824259/thumbs/themoviedb-1519824259-poster.jpg')
		addLink('Ледена Епоха 1','https:///voe.sx/e/ccrfwf9kh88x',3,'https://filmisub.com/uploads/posts/zamunda/316613/316613-poster.jpg')
		addLink('Ледена Епоха 2','https:///voe.sx/e/z80c9ru0nxgv',3,'https://filmisub.com/uploads/posts/zamunda/325808/325808-poster.jpg')
		addLink('Ледена Епоха 3','https:///voe.sx/e/k7ju95y6ttw6',3,'https://filmisub.com/uploads/posts/zamunda/227244/227244-poster.jpg')
		addLink('Ледена Епоха 4','https:///voe.sx/e/5vvlrdjkbo3w',3,'https://filmisub.com/uploads/posts/zamunda/326516/326516-poster.jpg')
		addLink('Ледена Епоха 5','https:///voe.sx/e/dmfc0qp95gv3',3,'https://filmisub.com/uploads/posts/2016-09/1472933069_1467914502_1.jpg')
		addLink('Круд 1','https:///voe.sx/e/5wjfgqnnjw2x',3,'https://filmisub.com/uploads/posts/2013-03/thumbs/1364723989_croods.jpg')
		addLink('Круд 2','https:///voe.sx/e/i6s64hxcceo0',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1609334481/thumbs/themoviedb-1609334481-poster.jpg')
		addLink('Бебе Бос','https:///voe.sx/e/03zph2e6n556',3,'https://filmisub.com/uploads/posts/zamunda/510504/thumbs/510504-poster.jpg')
		addLink('Патешки истории: Съкровището на изгубената лампа','https:///voe.sx/e/kyrdbuqufbm1',3,'https://filmisub.com/uploads/posts/zamunda/351984/thumbs/351984-poster.jpg')
		addLink('Малката русалка','https:///voe.sx/e/ryq2n59jeziz',3,'https://filmisub.com/uploads/posts/zamunda/370413/thumbs/370413-poster.jpg')
		addLink('Смелата Моана','https:///voe.sx/e/dzt5liooevn5',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1481299027/thumbs/themoviedb-1481299027-poster.jpg')
		addLink('Търсенето на Немо','https:///voe.sx/e/ykvtyk7r4wzp',3,'https://filmisub.com/uploads/posts/2013-03/1364710141_finding-nemo.jpg')
		addLink('Търсенето на Дори','https:///voe.sx/e/pwf3dnpegky1',3,'https://filmisub.com/uploads/posts/zamunda/481842/thumbs/481842-poster.jpg')
		addLink('Аладин 1','https:///voe.sx/e/4wgy1er3ra1b',3,'https://filmisub.com/uploads/movies/812/thumbs/7f53XAE4nPiGe9XprpGAeWHuKPw.jpg')
		addLink('Аладин 2: Завръщането на Джафар','https:///voe.sx/e/b3qnrirahu1p',3,'https://filmisub.com/uploads/posts/zamunda/114108/114108-poster.jpg')
		addLink('Цар Лъв 1','https:///voe.sx/e/84hz4v3lccmn',3,'https://filmisub.com/uploads/posts/zamunda/278306/thumbs/278306-poster.jpg')
		addLink('Цар Лъв 2: Гордостта на Симба','https:///voe.sx/e/noitcvdutyr0',3,'https://filmisub.com/uploads/posts/zamunda/280621/thumbs/280621-poster.jpg')
		addLink('Цар Лъв 3: Хакуна Матата','https:///voe.sx/e/85iy4yf35ern',3,'https://filmisub.com/uploads/posts/zamunda/281051/thumbs/281051-poster.jpg')
		addLink('Добрият Динозавър','https:///voe.sx/e/lbf3d4q9x3v9',3,'https://filmisub.com/uploads/posts/zamunda/460358/thumbs/460358-poster.jpg')
		addLink('Хотел Трансилвания 2','https:///voe.sx/e/qumo5556xvsq',3,'https://filmisub.com/uploads/posts/zamunda/cinefish32984/thumbs/cinefish32984-poster.jpg')
		addLink('Хотел Трансилвания 3','https:///voe.sx/e/ezed13tbwg5y',3,'https://filmisub.com/uploads/posts/zamunda/541481/thumbs/541481-poster.jpg')
		addLink('Мегаум','https:///voe.sx/e/aw1597ux1bji',3,'https://filmisub.com/uploads/movies/38055/thumbs/amXAUSAUrnGuLGEyc1ZNhBvgbnF.jpg')
		addLink('Рататуй','https:///voe.sx/e/onnjai7yy0td',3,'https://filmisub.com/uploads/movies/2062/thumbs/y8y6Fv0k068OnHBZtu949A1t6pj.jpg')
		addLink('Пазителите','https:///voe.sx/e/hzffvjk14c6d',3,'https://filmisub.com/uploads/posts/2013-02/thumbs/1361786014_rise-of-the-guardians.jpg')




#Разлистване на заглавията
def INDEXCAT(url):
		if (username != "" and logged_in == False):
			s = LOGIN()
		response = s.get(url, headers=vt_headers)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
		#data = "".join(data.split()) #Изчистваме всички интервали и нови редове
		data = response.text.replace('\n', '').replace('\r', '')
		#print (data)
		match = re.compile('<div class=\"pic\">.{3,10}<a href=\"(.+?)\" title=\"(.+?)\">.{15,100}src=\"(.+?)\"').findall(data)
		for alink, title, poster in match:
			#print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
			poster = 'http://vatim.xyz' + poster
			addDir(title,'http://vatim.xyz'+urllib.parse.quote(alink),2,poster) #html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
			#print alink
		#Край на обхождането
		#addDir('Наръчник на Геймъра Сезон 1','http://vatim.xyz/Gamer/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/gameri1.jpg')
		#addDir('Наръчник на Геймъра Сезон 2','http://vatim.xyz/Gamer/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/gameri1.jpg')
		addDir('Най-добри приятели завинаги Сезон 1','http://vatim.xyz/Best-Friends-Whenever/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/bfw1.jpg')
		addDir('Най-добри приятели завинаги Сезон 2','http://vatim.xyz/Best-Friends-Whenever/S2/E1',2,'http://vatim.xyz/Images/Serials/idx/bfw1.jpg')
		#addDir('Райли в големия свят Сезон 1','http://vatim.xyz/Girl-Meets-World/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
		addDir('Райли в големия свят Сезон 2','http://vatim.xyz/Girl-Meets-World/S2/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
		addDir('Райли в големия свят Сезон 3','http://vatim.xyz/Girl-Meets-World/S3/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
		addDir('Кейси под прикритие Сезон 1','http://vatim.xyz/KC_Undercover/S1/E1',2,'http://vatim.xyz/Images/Serials/KC-Undercover/keisi-12.jpg')


#Разлистване на епизодите
def INDEXPAGES(name,url):
		if (username != "" and logged_in == False):
			s = LOGIN()
		response = s.get(url, headers=vt_headers)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'episode')
		data = response.text.replace('\n', '').replace('\r', '')
		#print (data)
		sename = ''
		matchf = re.compile('<p class=\"description\">(.+?)</p>').findall(data) #Име на сезона
		for fullname in matchf:
			sename = fullname[::1]
		
		match = re.compile('<li>.{0,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,170}src=\"(.+?)\"').findall(data) #Списък на епизодите; ако има обложки
		for alink, title, poster in match:
			#print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
			poster = 'http://vatim.xyz' + poster.replace('..','')
			if '<' not in title:
				if (sename and 'Сезон' not in title):
					addLink(title.replace('Епизод', sename+' Епизод'),urllib.parse.quote(alink),3,poster) #html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
				else:
					addLink(title,urllib.parse.quote(alink),3,poster)
				#print alink
		
		match = re.compile('<a href=\"(.+?)\" {1,5}title=\"(.+?)\" class').findall(data) #Списък на епизодите; ако няма обложки а бутони
		for alink, title in match:
			#print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
			if '<' not in title:
				if (sename and 'Сезон' not in title):
					addLink(title.replace('Епизод', sename+' Епизод'),urllib.parse.quote(alink),3,md+'DefaultMovies.png') #html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
				else:
					addLink(title,urllib.parse.quote(alink),3,md+'DefaultMovies.png')
				#print alink
		#Ръчно добавяне на линкове за 
		if 'Benji-Zax-Prince' in url:
			addLink("Бенджи, Закс и Звездният принц - Епизод 1","http:///fp.vatx.club/~antsacti/B1.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 2","http:///fp.vatx.club/~antsacti/B2.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 3","http:///fp.vatx.club/~antsacti/B3.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 4","http:///fp.vatx.club/~antsacti/B4.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 5","http:///fp.vatx.club/~antsacti/B5.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 6","http:///fp.vatx.club/~antsacti/B6.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 7","http:///fp.vatx.club/~antsacti/B7.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 8","http:///fp.vatx.club/~antsacti/B8.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 9","http:///fp.vatx.club/~antsacti/B9.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 10","http:///fp.vatx.club/~antsacti/B10.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 11","http:///fp.vatx.club/~antsacti/B11.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 12","http:///fp.vatx.club/~antsacti/B12.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 13","http:///fp.vatx.club/~antsacti/B13.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
		#Край на обхождането
		
		#Превключване между Сезони
		if ("/S1/E1" in url and "<h3> Сезон 2</h3>" in data):
			addDir('Сезон 2 >>',url.replace('/S1/E1','/S2/E1'),2,'DefaultFolder.png')
		if ("<h2> Сезон 2</h2>" in data):
			matchs = re.compile('<li>.{5,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,150}src=\"(.+?)\"').findall(data)
			for alink, title, poster in matchs:
				if 'Сезон-2' in title:
					poster = 'http://vatim.xyz' + poster.replace('..','')
					addDir('Сезон 2 >>','http://vatim.xyz'+urllib.parse.quote(alink),2,md+'DefaultFolder.png')
		if ("/S2/E1" in url and "<h3> Сезон 3</h3>" in data):
			addDir('Сезон 3 >>',url.replace('/S2/E1','/S3/E1'),2,md+'DefaultFolder.png')
		if ("/Sezon2/E1" in url and "<h3> Сезон 3</h3>" in data):
			addDir('Сезон 3 >>',url.replace('/Sezon2/E1','/S3/E1'),2,md+'DefaultFolder.png')
		if ("<h2> Сезон 3</h2>" in data):
			matchs = re.compile('<li>.{5,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,150}src=\"(.+?)\"').findall(data)
			for alink, title, poster in matchs:
				if 'Сезон-3' in title:
					poster = 'http://vatim.xyz' + poster.replace('..','')
					addDir('Сезон 3 >>','http://vatim.xyz'+urllib.parse.quote(alink),2,md+'DefaultFolder.png')
		if ("<h3> Сезон 4</h3>" in data):
			matchs = re.compile('<li.{5,30}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,170}src=\"(.+?)\"').findall(data)
			for alink, title, poster in matchs:
				if '/S4/E1' in alink:
					poster = 'http://vatim.xyz' + poster.replace('..','')
					addDir('Сезон 4 >>','http://vatim.xyz'+urllib.parse.quote(alink),2,md+'DefaultFolder.png')
		
		if ("/S4/E1" in url and "<h3> Сезон 5</h3>" in data):
			addDir('Сезон 5 >>',url.replace('/S4/E1','/S5/E1'),2,md+'DefaultFolder.png')
		
		
		






#Зареждане на видео или ТВ
def PLAY(name,url,iconimage):
	stream = ""
	url = urllib.parse.unquote(url).replace('//','/')
	#print ('URL: '+url)
	#xbmcgui.Dialog().ok('URL:',url)
	if (username != "" and logged_in == False):
		s = LOGIN()
		
		#Подготвяне на епизодите
		if ('http' not in url):
			response = s.get('http://vatim.xyz'+url, headers=vt_headers)
			#print (response.text)
			#Извличане на видеото
			if 'pcloud.com' in response.text:
				matche = re.compile('data-src=\"(.+?)\"').findall(response.text)
				for pcloudf in matche:
					response2 = requests.get(pcloudf, headers=vt_headers, cookies=response.cookies)
					matchv = re.compile('downloadlink\": \"(.+?)\",').findall(response2.text)
					for vlink in matchv:
						stream = vlink.replace('\/','/')
			elif 'vbox7.com' in response.text:
				matchv = re.compile('iframe.{5,30}src=\".+vid=(.+?)\"').findall(response.text)
				for pvlink in matchv:
					#print ('pvlink:' + pvlink)
					jsonrsp = json.loads(urllib.request.urlopen('https://api.vbox7.com/v6/?action=r_item_execute&item_md5=' + pvlink + '&app_token=vbox7_android_1.0.0_gT13mY').read())
					stream = jsonrsp['items'][0]['data']['default_video']
					#print (stream)    
			elif ('iframe' in response.text and 'vbox7.com' not in response.text):
				matche = re.compile('iframe.{5,30}src=\"(.+?)\"').findall(response.text)
				for iframe in matche:
					#print (iframe)
					response = s.get('http://vatim.xyz'+iframe, headers=vt_headers)
					#print (response.text)
					data2 = response.text.replace('\n', '').replace('\r', '')
					if 'file' in data2:
						matchv = re.compile('file: \"(.+?)\".{30,50}image:\"(.+?)\".{5,15}title: \"(.+?)\"').findall(data2)
						for vlink, poster, title in matchv:
							stream = vlink
							#xbmcgui.Dialog().ok('file: 223',stream)
							iconimage = 'http://vatim.xyz' + poster
					else:
						matchv = re.compile('src.{1,4}\"(.+?)\" }').findall(data2)
						for vlink in matchv:
							stream = vlink
							#xbmcgui.Dialog().ok('src 229',stream)
				
			elif 'file:' in response.text:
				matchv = re.compile('file:.{1,4}\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('file: 235',stream)
			elif 'src:' in response.text:
				matchv = re.compile('src:.{1,4}\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('src: 240',stream)
			elif 'source src' in response.text:
				matchv = re.compile('<source src=\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('source src= 245',stream)
			elif 'source' in response.text:
				matchv = re.compile('source: "(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('source: 250',stream)
			elif '"hls":' in response.text:
				matchv = re.compile('"hls": "(.+?)",').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('hls: 264',stream)
			elif 'sources:' in response.text:
				matchv = re.compile('sources: \["(.+?)","http').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('sources: 269',stream)
			
		
			#Осигуряване на обложка
			matchcover = re.compile('<img src=\"(.+jpg)\"').findall(response.text)
			for cover in matchcover:
				iconimage = 'http://vatim.xyz' + cover[::1]
				#xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM cover ',iconimage, 4000, iconimage))
		else:
			if 'myFunction' in url:
				matchv = re.compile('\'(http.+?)\',').findall(urllib.parse.unquote(url))
				for vlink in matchv:
					stream = vlink.replace('http:/vn','http://vn')
					#xbmcgui.Dialog().ok('myFunction 263',stream)
			elif 'voe.sx' in url:
				response = requests.get(url)
				matchv = re.compile('"hls": "(.+?)",').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('hls: 287',stream)

			else:
				stream = url
		
		#Възпроизвеждане на видеото
		if 'm3u8' in stream:
			is_helper = inputstreamhelper.Helper('hls')
			if is_helper.check_inputstream():
				stream = stream.replace('playlist_fmp4.m3u8','playlist.m3u8')
				#xbmcgui.Dialog().ok('Stream HLS',stream)
				li = xbmcgui.ListItem(path=stream)
				li.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
				li.setInfo( type="Video", infoLabels={ 'Title': name })

				li.setMimeType('application/x-mpegURL')
				li.setContentLookup(False)

				li.setProperty('inputstream', 'inputstream.adaptive')
				li.setProperty('inputstream.adaptive.manifest_type', 'hls')
				li.setProperty('inputstream.adaptive.license_key', '|' + 'User-Agent='+urllib.parse.quote_plus(UA)+'&Origin=http://vatim.xyz'+'&Referer=http://vatim.xyz/'+'&verifypeer=false')
				li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+urllib.parse.quote_plus(UA)+'&Origin=http://vatim.xyz'+'&Referer=http://vatim.xyz/'+'&verifypeer=false')
				try:
					xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
				except:
					xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))
		else:	
			#xbmcgui.Dialog().ok('Stream MP4',stream)
			li = xbmcgui.ListItem(path=stream+'|User-Agent='+urllib.parse.quote_plus(UA)+'&Origin='+stream+'&Referer='+stream+'&verifypeer=false')
			li.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
			li.setInfo( type="Video", infoLabels={ 'Title': name })
			try:
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			except:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))
			







#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		#xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEXCAT(url)

elif mode==2:
		INDEXPAGES(name,url)

elif mode==3:
		PLAY(name,url,iconimage)

elif mode==4:
		LOGIN()


xbmcplugin.endOfDirectory(int(sys.argv[1]))