# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.error, urllib.parse
#import http.cookiejar as cj
#import http.cookiejar
import requests
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import inputstreamhelper

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.vatim'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.vatim')
username = __settings__.getSetting('username')
password = __settings__.getSetting('password')

md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "resources/media/")
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:90.0) Gecko/20100101 Firefox/90.0' #За симулиране на заявка от компютърен браузър
LG = 'http://vatim.xyz/Account/Login'
logged_in = False

#Хедъри за заявки към услугата
vt_headers = {
	'User-Agent': UA,
	'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Origin': 'http://vatim.xyz',
	'Referer': LG,
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'accept-language': 'bg,en-US;q=0.7,en;q=0.3',
	'Accept-Encoding': 'gzip'
				}


#Генериране на сесия
def LOGIN():
	s = requests.Session()
	response1 = s.get(LG, headers=vt_headers)
	matcht = re.search('<input name="__RequestVerificationToken" type="hidden" value="(.+?)" />', response1.text)
	payload = {'__RequestVerificationToken': matcht.group(1), 'email': username, 'password': password }
	response2 = s.post(LG, data=payload, headers=vt_headers)
	#print (response2.text)
	#matchl = re.search('<a class="email" href="/Account/Manage" title="Manage">(.+?)</a>', response2.text)
	#xbmcgui.Dialog().ok('Logged In As:',str(matchl.group(1)))
	logged_in = True
	return s




#Меню с директории в приставката
def CATEGORIES():
		addLink('Vatim TV','http:///tv1.dragonsclan.org/tva/tvn/playlist.m3u8',3,'http://vatim.xyz/Images/Serials/idx/vatimtv-1.jpg')
		addDir('Каталог','http://vatim.xyz/Catalog',1,'http://vatim.xyz/Images/logo1.png')
		addDir('LVL UP','http://vatim.xyz/LVLUP',1,'http://vatim.xyz/Images/logo1.png')
		addLink('Лабиринт','/Labyrinth',3,'http://vatim.xyz/Images/Serials/labyrinth/labyrinth-bg.jpg')
		addLink('Лапута: Замък в небето','/Laputa',3,'http://vatim.xyz/Images/Serials/laputa/laputa1.jpg')
		addLink('Атлантида: Загубената империя','https:///voe.sx/e/fsiltwqeqe65',3,'https://filmisub.com/uploads/movies/10865/thumbs/9kbLIQEj99g5Hb9g1IG3VNdtt3h.jpg')
		addLink('Чудотворен свят: Ню Йорк','/LVLUP/Miraculous-ny',3,'http://vatim.xyz/Images/Serials/main/JPEG/mxposter.jpg')
		addLink('Чудотворен свят: Шанхай – легендата за женския дракон','https:///playtube.tv/v/KNTYmZ',3,'https://playtube.tv/upload/photos/2021/08/ut28v21pTpfmQV4mKDJ6_22_af1f34fdd22601844683cd4f0fc316cf_image.jpg')
		addLink('Несъвършенна магия','/LVLUP/%D0%9D%D0%B5%D1%81%D1%8A%D0%B2%D1%8A%D1%80%D1%88%D0%B5%D0%BD%D0%B0-%D0%9C%D0%B0%D0%B3%D0%B8%D1%8F',3,'http://vatim.xyz/Images/Serials/main/JPEG/nsmp.jpg')
		addLink('Зомбита 1','/LVLUP/%D0%97%D0%BE%D0%BC%D0%B1%D0%B8%D1%82%D0%B0',3,'http://vatim.xyz/Images/Serials/main/JPEG/zombita1.jpg')
		addLink('Зомбита 2','/LVLUP/%D0%97%D0%BE%D0%BC%D0%B1%D0%B8%D1%82%D0%B02',3,'http://vatim.xyz/Images/Serials/main/JPEG/zombi2p.jpg')
		addLink('Детегледачки в акция','/Detegledachki-v-akcia',3,'http://vatim.xyz/Images/Serials/main/JPEG/detegledachki-v-akcia.jpg')
		addLink('Наследниците 1','https:///voe.sx/e/tth3s99d7kul',3,'https://www.filmi2k.com/wp-content/uploads/2016/04/Descendants.jpg')
		addLink('Наследниците 2','https:///voe.sx/e/p7y2zo4pgrfs',3,'https://www.filmi2k.com/wp-content/uploads/2017/08/Descendants.2.2017.jpg')
		addLink('Наследниците 3','https:///voe.sx/e/hhy5ywljbiud',3,'https://www.filmi2k.com/wp-content/uploads/2019/08/Descendants-3-2019.jpg')
		addLink('Замръзналото кралство 1','https:///voe.sx/e/si7eii310zki',3,'https://filmisub.com/uploads/posts/zamunda/416166/416166-poster150.jpg')
		addLink('Замръзналото кралство 2','https:///voe.sx/e/e07p6wdq09bf',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1590517265/thumbs/themoviedb-1590517265-poster.jpg')
		addLink('Малката стъпка','https:///voe.sx/e/ydbn8luiv6o9',3,'https://filmisub.com/uploads/posts/zamunda/555963/thumbs/555963-poster.jpg')
		addLink('Как да си дресираш дракон 1','https:///playtube.tv/v/OGDsmQ',3,'https://playtube.tv/upload/photos/2019/09/4de187ffc11fe951e6bb1d742813aff5455f4e18aFzq7aDyFRfWEB9eEPG1.video_thumb_6930_3815.5.jpeg')
		addLink('Как да си дресираш дракон 2','https:///voe.sx/e/yntzn5alpxq9',3,'https://filmisub.com/uploads/movies/82702/thumbs/cGwNjJvfRjc7VFOI0hIhi8pLLvS.jpg')
		addLink('Как да си дресираш дракон 3','https:///voe.sx/e/27q4lrnpf8qj',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1554222530/thumbs/themoviedb-1554222530-poster.jpg')
		addLink('Повелителят на драконите (2020)','https:///voe.sx/e/um4wxi2hnhve',3,'https://www.filmifen.com/uploads/posts/2021-11/thumbs/1637598281_1613610186_4464350.jpg')
		addLink('Дракон на желанията (2021)','https:///voe.sx/e/jtwykay7g0qs',3,'https://www.filmifen.com/uploads/posts/2021-08/thumbs/1628759030_1628751348_8245176.jpg')
		addLink('Рая и последният дракон (2021)','https:///voe.sx/e/jtayi7yj3fpz',3,'https://www.filmifen.com/uploads/posts/2021-04/thumbs/1617279650_1616043114_103324.jpg')
		addLink('Бикът Фердинанд','https:///voe.sx/e/7hfawclqdcz7',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1519824259/thumbs/themoviedb-1519824259-poster.jpg')
		addLink('Ледена Епоха 1','https:///voe.sx/e/ccrfwf9kh88x',3,'https://filmisub.com/uploads/posts/zamunda/316613/316613-poster.jpg')
		addLink('Ледена Епоха 2','https:///voe.sx/e/z80c9ru0nxgv',3,'https://filmisub.com/uploads/posts/zamunda/325808/325808-poster.jpg')
		addLink('Ледена Епоха 3','https:///voe.sx/e/k7ju95y6ttw6',3,'https://filmisub.com/uploads/posts/zamunda/227244/227244-poster.jpg')
		addLink('Ледена Епоха 4','https:///voe.sx/e/5vvlrdjkbo3w',3,'https://filmisub.com/uploads/posts/zamunda/326516/326516-poster.jpg')
		addLink('Ледена Епоха 5','https:///voe.sx/e/dmfc0qp95gv3',3,'https://filmisub.com/uploads/posts/2016-09/1472933069_1467914502_1.jpg')
		addLink('Круд 1','https:///voe.sx/e/5wjfgqnnjw2x',3,'https://filmisub.com/uploads/posts/2013-03/thumbs/1364723989_croods.jpg')
		addLink('Круд 2','https:///voe.sx/e/i6s64hxcceo0',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1609334481/thumbs/themoviedb-1609334481-poster.jpg')
		addLink('Бебе Бос','https:///voe.sx/e/03zph2e6n556',3,'https://filmisub.com/uploads/posts/zamunda/510504/thumbs/510504-poster.jpg')
		addLink('Патешки истории: Съкровището на изгубената лампа','https:///voe.sx/e/kyrdbuqufbm1',3,'https://filmisub.com/uploads/posts/zamunda/351984/thumbs/351984-poster.jpg')
		addLink('Малката русалка','https:///voe.sx/e/ryq2n59jeziz',3,'https://filmisub.com/uploads/posts/zamunda/370413/thumbs/370413-poster.jpg')
		addLink('Смелата Моана','https:///voe.sx/e/dzt5liooevn5',3,'https://filmisub.com/uploads/posts/zamunda/themoviedb-1481299027/thumbs/themoviedb-1481299027-poster.jpg')
		addLink('Търсенето на Немо','https:///voe.sx/e/ykvtyk7r4wzp',3,'https://filmisub.com/uploads/posts/2013-03/1364710141_finding-nemo.jpg')
		addLink('Търсенето на Дори','https:///voe.sx/e/pwf3dnpegky1',3,'https://filmisub.com/uploads/posts/zamunda/481842/thumbs/481842-poster.jpg')
		addLink('Аладин 1','https:///voe.sx/e/4wgy1er3ra1b',3,'https://filmisub.com/uploads/movies/812/thumbs/7f53XAE4nPiGe9XprpGAeWHuKPw.jpg')
		addLink('Аладин 2: Завръщането на Джафар','https:///voe.sx/e/b3qnrirahu1p',3,'https://filmisub.com/uploads/posts/zamunda/114108/114108-poster.jpg')
		addLink('Аладин (2019)','https:///voe.sx/e/meysjey6ic74',3,'https://www.filmifen.com/uploads/posts/2021-04/thumbs/1618156841_1579400507_7821970.jpg')
		addLink('Повелителят на крадците (2006)','https:///playtube.tv/v/hayK85',3,'https://playtube.tv/upload/photos/2019/06/d23efe1d15f1274b359792761804191e0c0cf9375riOQQjU4W5TbgRqAko1.video_thumb_1403_2804.5.jpeg')
		addLink('Цар Лъв 1','https:///voe.sx/e/84hz4v3lccmn',3,'https://filmisub.com/uploads/posts/zamunda/278306/thumbs/278306-poster.jpg')
		addLink('Цар Лъв 2: Гордостта на Симба','https:///voe.sx/e/noitcvdutyr0',3,'https://filmisub.com/uploads/posts/zamunda/280621/thumbs/280621-poster.jpg')
		addLink('Цар Лъв 3: Хакуна Матата','https:///voe.sx/e/85iy4yf35ern',3,'https://filmisub.com/uploads/posts/zamunda/281051/thumbs/281051-poster.jpg')
		addLink('Добрият Динозавър','https:///voe.sx/e/lbf3d4q9x3v9',3,'https://filmisub.com/uploads/posts/zamunda/460358/thumbs/460358-poster.jpg')
		addLink('Хотел Трансилвания 1','https:///playtube.tv/v/MHtkvB',3,'https://playtube.tv/upload/photos/2019/09/ce9d9462c147f22fedf42baf5eda3e28cdb9b3fb5yJQIsZlGo4lKZxXeO5c.video_thumb_1364_1830.3333333333.jpeg')
		addLink('Хотел Трансилвания 2','https:///voe.sx/e/qumo5556xvsq',3,'https://filmisub.com/uploads/posts/zamunda/cinefish32984/thumbs/cinefish32984-poster.jpg')
		addLink('Хотел Трансилвания 3','https:///voe.sx/e/ezed13tbwg5y',3,'https://filmisub.com/uploads/posts/zamunda/541481/thumbs/541481-poster.jpg')
		addLink('Мегаум','https:///voe.sx/e/aw1597ux1bji',3,'https://filmisub.com/uploads/movies/38055/thumbs/amXAUSAUrnGuLGEyc1ZNhBvgbnF.jpg')
		addLink('Рататуй','https:///voe.sx/e/onnjai7yy0td',3,'https://filmisub.com/uploads/movies/2062/thumbs/y8y6Fv0k068OnHBZtu949A1t6pj.jpg')
		addLink('Пазителите','https:///voe.sx/e/hzffvjk14c6d',3,'https://filmisub.com/uploads/posts/2013-02/thumbs/1361786014_rise-of-the-guardians.jpg')
		addLink('Двете страни на чудесата (2020)','https:///playtube.tv/v/dJ5MDl',3,'https://playtube.tv/upload/photos/2021/06/Y9hC1Gv7t8VVPIlusiGr_13_e73d6dbb230f09b3cab61e0584e4e3bf_image.jpg')
		addLink('Алиса в страната на чудесата (2010)','https:///playtube.tv/v/2yi7mk',3,'https://playtube.tv/upload/photos/2021/05/HyJSlJJjLvfMuNWJFAeI_17_75eddb68bad8a523952752c4bddb14ec_image.png')
		addLink('Анабел Хупър и призракът от Нантъкет (2016)','https:///playtube.tv/v/bCAh4R',3,'https://playtube.tv/upload/photos/2021/05/Z2Bq4EUxlnSJLrZVtpxU_30_75baf6a00387c81129f9bf606e7ea93c_image.jpg')
		addLink('Фантастични животни и къде да ги намерим (2016)','https:///playtube.tv/v/VyOB4v',3,'https://playtube.tv/upload/photos/2021/09/mwJxXYsfuBqyGMKZbc8R_08_8d47699797041449fa2e199f0597722e_image.jpg')
		addLink('Портал на воините (2016)','https:///playtube.tv/v/plsSd9',3,'https://playtube.tv/upload/photos/2021/07/Png6GpEJxbzvK59BL9Ut_02_0f8f28e29ae588328e3501602c01ca49_image.jpg')
		addLink('Превъзпитай татко (1994)','https:///playtube.tv/v/P8Benr',3,'https://playtube.tv/upload/photos/2019/05/3dc912d250d658fc286f630970a574c979de173cXjBmfeaSFJ3elXGk2rJM.video_thumb_6021_4062.5.jpeg')
		addLink('Сам вкъщи 1 (1990)','https:///playtube.tv/v/7fqaDl',3,'https://playtube.tv/upload/photos/2019/07/3485f9596eee3fd82435646a5f9357c6573b431b7d16omXirLpNZnjEHwku.video_thumb_1955_3866.2.jpeg')
		addLink('Сам вкъщи 2 (1992)','https:///voe.sx/e/g6byz8rcm1c4',3,'https://www.filmifen.com/uploads/posts/2021-11/thumbs/1637846182_home_alone_two_ver2.jpg')
		addLink('Сам вкъщи 3 (1997)','https:///playtube.tv/v/BpqgGH',3,'https://playtube.tv/upload/photos/2019/07/7fcfe903c6f112cff167b4e3b7ca6ab2fb06ceb6Rqgs1JIFCVuH3Q8WCuGs.video_thumb_3465_2048.3333333333.jpeg')
		addLink('Сам вкъщи 4 (2002)','https:///voe.sx/e/ln0jru4liagx',3,'https://www.filmifen.com/uploads/posts/2013-10/thumbs/1380845615_e45e288ee8e035a4.jpg')
		addLink('Сам вкъщи 5 (2012)','https:///playtube.tv/v/eMHUv6',3,'https://playtube.tv/upload/photos/2019/07/38b4a52d60045ffe31810e3d349b20746a5c4693wAoaqG2vlBhwAWXKGGOa.video_thumb_4257_2710.jpeg')
		addLink('Денис Белята (1993)','https:///playtube.tv/v/WcmDtn',3,'https://playtube.tv/upload/photos/2020/11/u5RhKeOxBFfQ5J5gB3YV_26_114f622b0c203e4d0cad959c803b929e_image.jpg')
		addLink('Денис Белята отново атакува (1998)','https:///playtube.tv/v/Jq5zX7',3,'https://playtube.tv/upload/photos/2019/07/cf639f63ed34ab0a57c47da1266266c19af8a008K3D3PYKIHVAha8QclmOc.video_thumb_6481_2148.jpeg')
		addLink('Коледата на Денис белята (2007)','https:///playtube.tv/v/VqnLrD',3,'https://playtube.tv/upload/photos/2019/07/d335e34544b6611e4accdc5dde51f64567ef643dLh9ajbUNQTFGVljBHqdT.video_thumb_5087_3274.7.jpeg')
		addLink('Ралф разбива интернета (2018)','https:///playtube.tv/v/gLzPB3',3,'https://egmontbulgaria.com/media/cache/fb_image_thumb/product-images/34/80/Wreck-itRalph_Cover1546459569.297.jpg')
		addLink('Феноменалните (2004)','https:///playtube.tv/v/dAABox',3,'https://playtube.tv/upload/photos/2020/12/T3mEy1QEuRugMOhm5eXQ_29_de13572a0735536174f299445a1ab3bf_image.jpg')
		addLink('Рапунцел и разбойникът (2010)','https:///playtube.tv/v/XaMGYT',3,'https://egmontbulgaria.com/media/cache/fb_image_thumb/product-images/14/24/rapunzel1482485405.177.jpg')
		addLink('Братът на мечката (2003)','https:///playtube.tv/v/MaKyBd',3,'https://playtube.tv/upload/photos/2020/05/54a3b37c956fb39de878b18d0771eac97ae45f3eRx9yCnVH1rtFu8TNoopN.video_thumb_8253_2552.5.jpeg')
		addLink('Красавицата и звярът (1991)','https:///playtube.tv/v/6Bkjkn',3,'https://playtube.tv/upload/photos/2020/05/0127a40c51986504c2c8afe3c1ae1b8d611efce1RPsHvzDMtYOdxVfUcRJn.video_thumb_4647_1835.jpeg')
		addLink('Ваканцията на Мистър Бийн (2007)','https:///playtube.tv/v/lnD3Og',3,'https://playtube.tv/upload/photos/2019/05/772c25207970689b77476ae42af3896cf0d6ec7fnep2YQABMaNTeNnofP36.video_thumb_8833_3493.1.jpeg')
		addLink('Семейство Флинтстоун 1 (1994)','https:///playtube.tv/v/MLvcYm',3,'https://playtube.tv/upload/photos/2019/05/d4cae9ebd35f95b1da6051466ac1f48e7db1c5f2KrCG7i6CCWtzTppsXlnS.video_thumb_6432_2605.jpeg')
		addLink('Семейство Флинтстоун 2 (2000)','https:///playtube.tv/v/2KdJhR',3,'https://playtube.tv/upload/photos/2019/05/15d7216699313c0456dc58debad19722bf86605cxNiUcjgSUwqwUnDITqFT.video_thumb_3892_1742.6666666667.jpeg')
		addLink('Бейб (1995)','https:///playtube.tv/v/j5EP6F',3,'https://playtube.tv/upload/photos/2019/06/aae09ea3d7ce0ce0f329e41e7aff234949c994d99JB2iJXkgdvnNJkMOz2c.video_thumb_3572_1840.jpeg')
		addLink('Астерикс и Обеликс: Мисия Клеопатра (2002)','https:///playtube.tv/v/u45pht',3,'https://playtube.tv/upload/photos/2019/06/44672ce753e38b87f42f20f2ea5839013d3d41edEJx7lbqPLNW7YkXBHZTV.video_thumb_7673_2068.jpeg')
		addLink('Астерикс на Олимпийските игри (2008)','https:///playtube.tv/v/miWFAh',3,'https://playtube.tv/upload/photos/2019/07/1c39868288a19d528394d7f4e1192c91d8d25fd7BuDm1t1L1VAw3BbSzr3z.video_thumb_2708_25.jpeg')
		addLink('Летящи хлапета (2008)','https:///playtube.tv/v/QgwbKc',3,'https://playtube.tv/upload/photos/2019/06/423cb245141c80c603c4d86b2a02a1adeb08ab2efQtVLS96DDW57emeA4Le.video_thumb_4708_1993.3333333333.jpeg')
		addLink('Маската (1994)','https:///playtube.tv/v/cMewZP',3,'https://playtube.tv/upload/photos/2019/06/5120ab570a8d91146c94f91f46c8c41461a47cdaAYdT5xe7hP6TsP95xHHB.video_thumb_1663_3036.jpeg')
		addLink('Скъпа, уголемих детето (1992)','https:///playtube.tv/v/Lyk86h',3,'https://playtube.tv/upload/photos/2019/06/268ab8ced6544cc1e1934eed71f26ae1af94ee39wGteJ4j775ro2TfW2nNr.video_thumb_4706_3342.3.jpeg')
		addLink('Феята на зъбките 1 (2010)','https:///playtube.tv/v/XvfKOJ',3,'https://playtube.tv/upload/photos/2019/06/356fe899014f99eb6bb4773db0682a451896d59eW9U1LAFEEcolCMb3Rfbz.video_thumb_9744_1946.3333333333.jpeg')
		addLink('Феята на зъбките 2 (2012)','https:///playtube.tv/v/dLNXl8',3,'https://playtube.tv/upload/photos/2019/07/ede59655c1d1281cbe71e18927945c32950a0c78TvmGPFFMAT6eG1yUXWkg.video_thumb_1341_3521.7.jpeg')
		addLink('Един рицар в Камелот (1998)','https:///playtube.tv/v/wSxXe4',3,'https://playtube.tv/upload/photos/2019/07/2d2e117512f5f9f919f841c2e875b87ea808ab5fYLtTR6CwA39s349BvQMb.video_thumb_5800_2538.jpeg')
		addLink('Кадет Кели (2002)','https:///playtube.tv/v/JyKW2o',3,'https://playtube.tv/upload/photos/2019/08/fb5627e82cb48f9be32285e4a3ac1b0fb254e07baDtTEYTkPbaJsbgSEqx5.video_thumb_6884_3906.5.jpeg')
		addLink('Гръм (2008)','https:///playtube.tv/v/RF1TDS',3,'https://playtube.tv/upload/photos/2020/05/64d86808ecc3ad0494335191659d4a138581384cTqzSmU4ffMSSzuAyh851.video_thumb_7946_1927.3333333333.jpeg')
		addLink('Робо-куче (2015)','https:///playtube.tv/v/gVwnoc',3,'https://filmisub.com/uploads/movies/332212/poster-nsI8HUkkL0K2NtXZ6C4FRslbiMV.jpg')
		addLink('101 Далматинци (1996)','https:///playtube.tv/v/HlPWu8',3,'https://playtube.tv/upload/photos/2019/09/b97a0bf7c47bf2ed7f278c28c599e64d51468bcalohy5R4tBMDqYkEj54yp.video_thumb_3282_2844.5.jpeg')
		addLink('102 Далматинци (2000)','https:///playtube.tv/v/C8v7iT',3,'https://playtube.tv/upload/photos/2019/08/cce4e4f5943d07b9b2c457b18a045bb1903ff5c0FmgWfQLlmlsFXQI53eby.video_thumb_9200_25.jpeg')
		addLink('Момче на име Коледа (2021)','https:///voe.sx/e/ja2894fi3syj',3,'https://www.filmifen.com/uploads/posts/2021-11/thumbs/1638125180_1637879869_1366040.jpg')
		addLink('Как Гринч открадна Коледата (2000)','https:///voe.sx/e/uo4bmo7xne2v',3,'https://www.filmifen.com/uploads/posts/2013-12/thumbs/1386680337_how_the_grinch_stole_christ.jpg')
		#addLink('','',3,'')
		




#Разлистване на заглавията
def INDEXCAT(url):
		if (username != "" and logged_in == False):
			s = LOGIN()
		response = s.get(url, headers=vt_headers)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
		#data = "".join(data.split()) #Изчистваме всички интервали и нови редове
		data = response.text.replace('\n', '').replace('\r', '')
		#print (data)
		match = re.compile('<div class=\"pic\">.{3,10}<a href=\"(.+?)\" title=\"(.+?)\">.{15,100}src=\"(.+?)\"').findall(data)
		for alink, title, poster in match:
			#print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
			poster = 'http://vatim.xyz' + poster
			addDir(title,'http://vatim.xyz'+urllib.parse.quote(alink),2,poster) #html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
			#print alink
		#Край на обхождането
		#addDir('Наръчник на Геймъра Сезон 1','http://vatim.xyz/Gamer/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/gameri1.jpg')
		#addDir('Наръчник на Геймъра Сезон 2','http://vatim.xyz/Gamer/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/gameri1.jpg')
		addDir('Най-добри приятели завинаги Сезон 1','http://vatim.xyz/Best-Friends-Whenever/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/bfw1.jpg')
		addDir('Най-добри приятели завинаги Сезон 2','http://vatim.xyz/Best-Friends-Whenever/S2/E1',2,'http://vatim.xyz/Images/Serials/idx/bfw1.jpg')
		#addDir('Райли в големия свят Сезон 1','http://vatim.xyz/Girl-Meets-World/S1/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
		addDir('Райли в големия свят Сезон 2','http://vatim.xyz/Girl-Meets-World/S2/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
		addDir('Райли в големия свят Сезон 3','http://vatim.xyz/Girl-Meets-World/S3/E1',2,'http://vatim.xyz/Images/Serials/idx/raili.jpg')
		addDir('Кейси под прикритие Сезон 1','http://vatim.xyz/KC_Undercover/S1/E1',2,'http://vatim.xyz/Images/Serials/KC-Undercover/keisi-12.jpg')


#Разлистване на епизодите
def INDEXPAGES(name,url):
		if (username != "" and logged_in == False):
			s = LOGIN()
		response = s.get(url, headers=vt_headers)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'episode')
		data = response.text.replace('\n', '').replace('\r', '')
		#print (data)
		sename = ''
		matchf = re.compile('<p class=\"description\">(.+?)</p>').findall(data) #Име на сезона
		for fullname in matchf:
			sename = fullname[::1]
		
		match = re.compile('<li>.{0,16}<a href=\"(.+?)\" {1,5}title=\"(.+?)\">.{15,170}src=\"(.+?)\"').findall(data) #Списък на епизодите; ако има обложки
		for alink, title, poster in match:
			#print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
			poster = 'http://vatim.xyz' + poster.replace('..','')
			if '<' not in title:
				if (sename and 'Сезон' not in title):
					addLink(title.replace('Епизод', sename+' Епизод'),urllib.parse.quote(alink),3,poster) #html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
				else:
					addLink(title,urllib.parse.quote(alink),3,poster)
				#print alink
		
		match = re.compile('<a href=\"(.+?)\" {1,5}title=\"(.+?)\" class').findall(data) #Списък на епизодите; ако няма обложки а бутони
		for alink, title in match:
			#print title.decode('utf-8', 'ignore').encode('utf-8', 'ignore')
			if '<' not in title:
				if (sename and 'Сезон' not in title):
					addLink(title.replace('Епизод', sename+' Епизод'),urllib.parse.quote(alink),3,md+'DefaultMovies.png') #html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
				else:
					addLink(title,urllib.parse.quote(alink),3,md+'DefaultMovies.png')
				#print alink
		#Ръчно добавяне на линкове за 
		if 'Benji-Zax-Prince' in url:
			addLink("Бенджи, Закс и Звездният принц - Епизод 1","http:///fp.vatx.club/~antsacti/B1.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 2","http:///fp.vatx.club/~antsacti/B2.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 3","http:///fp.vatx.club/~antsacti/B3.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 4","http:///fp.vatx.club/~antsacti/B4.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 5","http:///fp.vatx.club/~antsacti/B5.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 6","http:///fp.vatx.club/~antsacti/B6.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 7","http:///fp.vatx.club/~antsacti/B7.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 8","http:///fp.vatx.club/~antsacti/B8.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 9","http:///fp.vatx.club/~antsacti/B9.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 10","http:///fp.vatx.club/~antsacti/B10.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 11","http:///fp.vatx.club/~antsacti/B11.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 12","http:///fp.vatx.club/~antsacti/B12.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
			addLink("Бенджи, Закс и Звездният принц - Епизод 13","http:///fp.vatx.club/~antsacti/B13.mp4",3,"http://vatim.xyz/Images/Serials/main/JPEG/zax.jpg")
		#Край на обхождането
		
		#Превключване между Сезони
		#print (data)
		#Текущ сезон
		season = 1
		matcht = re.compile('var mytxt = \"\D{3,40} Сезон (\d{1,3}) Епизод  \d{1,9}\";').findall(data)
		for seasont in matcht:
			season = seasont
		matcht2 = re.compile('Сезон (\d{1,3}) Епизод \d{1,9}\D{3,40}</h1>').findall(data)
		for seasont in matcht2:
			season = seasont
		#Нов сезон
		matchn = re.compile('> {1,30}<a href=\"(.{1,70})\" title=\"(.{1,70})\"> {1,70}<h\d> Сезон (.+?)</h\d> {1,50}<img').findall(data)
		for alink, title, seasonn in matchn:
			if (seasonn != season):
				addDir('Сезон '+seasonn+' >>','http://vatim.xyz'+urllib.parse.quote(alink),2,md+'DefaultFolder.png')

		
		
		






#Зареждане на видео или ТВ
def PLAY(name,url,iconimage):
	stream = ""
	url = urllib.parse.unquote(url).replace('//','/')
	#print ('URL: '+url)
	#xbmcgui.Dialog().ok('URL:',url)
	if (username != "" and logged_in == False):
		s = LOGIN()
		
		#Подготвяне на епизодите
		if ('http' not in url):
			response = s.get('http://vatim.xyz'+url, headers=vt_headers)
			#print (response.text)
			#Извличане на видеото
			if 'pcloud.com' in response.text:
				matche = re.compile('data-src=\"(.+?)\"').findall(response.text)
				for pcloudf in matche:
					response2 = requests.get(pcloudf, headers=vt_headers, cookies=response.cookies)
					matchv = re.compile('downloadlink\": \"(.+?)\",').findall(response2.text)
					for vlink in matchv:
						stream = vlink.replace('\/','/')
			elif 'vbox7.com' in response.text:
				matchv = re.compile('iframe.{5,30}src=\".+vid=(.+?)\"').findall(response.text)
				for pvlink in matchv:
					#print ('pvlink:' + pvlink)
					jsonrsp = json.loads(urllib.request.urlopen('https://api.vbox7.com/v6/?action=r_item_execute&item_md5=' + pvlink + '&app_token=vbox7_android_1.0.0_gT13mY').read())
					stream = jsonrsp['items'][0]['data']['default_video']
					#print (stream)    
			elif ('iframe' in response.text and 'vbox7.com' not in response.text):
				matche = re.compile('iframe.{5,30}src=\"(.+?)\"').findall(response.text)
				for iframe in matche:
					#print (iframe)
					response = s.get('http://vatim.xyz'+iframe, headers=vt_headers)
					#print (response.text)
					data2 = response.text.replace('\n', '').replace('\r', '')
					if 'file' in data2:
						matchv = re.compile('file: \"(.+?)\".{30,50}image:\"(.+?)\".{5,15}title: \"(.+?)\"').findall(data2)
						for vlink, poster, title in matchv:
							stream = vlink
							#xbmcgui.Dialog().ok('file: 223',stream)
							iconimage = 'http://vatim.xyz' + poster
					else:
						matchv = re.compile('src.{1,4}\"(.+?)\" }').findall(data2)
						for vlink in matchv:
							stream = vlink
							#xbmcgui.Dialog().ok('src 229',stream)
				
			elif 'file:' in response.text:
				matchv = re.compile('file:.{1,4}\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('file: 235',stream)
			elif 'src:' in response.text:
				matchv = re.compile('src:.{1,4}\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('src: 240',stream)
			elif 'source src' in response.text:
				matchv = re.compile('<source src=\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('source src= 245',stream)
			elif 'source' in response.text:
				matchv = re.compile('source: "(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('source: 250',stream)
			elif '"hls":' in response.text:
				matchv = re.compile('"hls": "(.+?)",').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('hls: 264',stream)
			elif 'sources:' in response.text:
				matchv = re.compile('sources: \["(.+?)","http').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('sources: 269',stream)
			
		
			#Осигуряване на обложка
			matchcover = re.compile('<img src=\"(.+jpg)\"').findall(response.text)
			for cover in matchcover:
				iconimage = 'http://vatim.xyz' + cover[::1]
				#xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM cover ',iconimage, 4000, iconimage))
		else:
			if 'myFunction' in url:
				matchv = re.compile('\'(http.+?)\',').findall(urllib.parse.unquote(url))
				for vlink in matchv:
					stream = vlink.replace('http:/vn','http://vn')
					#xbmcgui.Dialog().ok('myFunction 301',stream)
			elif 'voe.sx' in url:
				response = requests.get(url)
				matchv = re.compile('"hls": "(.+?)",').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('hls: 306',stream)
			elif 'playtube.tv' in url:
				response = requests.get(url)
				matchv = re.compile('<source src=\"(.+?)\"').findall(response.text)
				for vlink in matchv:
					stream = vlink
					#xbmcgui.Dialog().ok('mp4: 312',stream)

			else:
				stream = url
		
		#Възпроизвеждане на видеото
		if 'm3u8' in stream:
			is_helper = inputstreamhelper.Helper('hls')
			if is_helper.check_inputstream():
				stream = stream.replace('playlist_fmp4.m3u8','playlist.m3u8')
				#xbmcgui.Dialog().ok('Stream HLS',stream)
				li = xbmcgui.ListItem(path=stream)
				li.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
				li.setInfo( type="Video", infoLabels={ 'Title': name })

				li.setMimeType('application/x-mpegURL')
				li.setContentLookup(False)

				li.setProperty('inputstream', 'inputstream.adaptive')
				li.setProperty('inputstream.adaptive.manifest_type', 'hls')
				li.setProperty('inputstream.adaptive.license_key', '|' + 'User-Agent='+urllib.parse.quote_plus(UA)+'&Origin=http://vatim.xyz'+'&Referer=http://vatim.xyz/'+'&verifypeer=false')
				li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+urllib.parse.quote_plus(UA)+'&Origin=http://vatim.xyz'+'&Referer=http://vatim.xyz/'+'&verifypeer=false')
				try:
					xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
				except:
					xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))
		else:	
			#xbmcgui.Dialog().ok('Stream MP4',stream)
			li = xbmcgui.ListItem(path=stream+'|User-Agent='+urllib.parse.quote_plus(UA)+'&Origin='+stream+'&Referer='+stream+'&verifypeer=false')
			li.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
			li.setInfo( type="Video", infoLabels={ 'Title': name })
			try:
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			except:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VATIM','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))
			







#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		#xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEXCAT(url)

elif mode==2:
		INDEXPAGES(name,url)

elif mode==3:
		PLAY(name,url,iconimage)

elif mode==4:
		LOGIN()


xbmcplugin.endOfDirectory(int(sys.argv[1]))