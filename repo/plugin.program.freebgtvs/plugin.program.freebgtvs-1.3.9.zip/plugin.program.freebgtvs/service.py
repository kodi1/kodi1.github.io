import xbmc
xbmc.executebuiltin('RunScript(plugin.program.freebgtvs, False)')