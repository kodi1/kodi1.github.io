# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import time
import urllib.request, urllib.parse, urllib.error
from urllib.request import urlopen
import requests
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.vbox7'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.vbox7')


#Прочита VBOX7 потребителското име от настройките на приставката
uname1 = __settings__.getSetting("username1")
uname2 = __settings__.getSetting("username2")
uname3 = __settings__.getSetting("username3")
uname4 = __settings__.getSetting("username4")
uname5 = __settings__.getSetting("username5")
uname6 = __settings__.getSetting("username6")
uname7 = __settings__.getSetting("username7")
uname8 = __settings__.getSetting("username8")
uname9 = __settings__.getSetting("username9")
uname10 = __settings__.getSetting("username10")
uname11 = __settings__.getSetting("username11")
uname12 = __settings__.getSetting("username12")
uname13 = __settings__.getSetting("username13")
uname14 = __settings__.getSetting("username14")
uname15 = __settings__.getSetting("username15")
uname16 = __settings__.getSetting("username16")
uname17 = __settings__.getSetting("username17")
uname18 = __settings__.getSetting("username18")
uname19 = __settings__.getSetting("username19")
uname20 = __settings__.getSetting("username20")
uname21 = __settings__.getSetting("username21")
uname22 = __settings__.getSetting("username22")
uname23 = __settings__.getSetting("username23")
uname24 = __settings__.getSetting("username24")
uname25 = __settings__.getSetting("username25")


md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_path = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/vbox7.search.txt")
kolekcii_path = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/vbox7.playlist.txt")
srtsubs_path = xbmcvfs.translatePath('special://temp/vbox7.Bulgarian.srt')
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:87.0) Gecko/20100101 Firefox/87.0' #За симулиране на заявка от компютърен браузър


api4 = 'http://api.vbox7.com/v4/?action='
token4 = '&app_token=imperia_android_0.1.0_3rG7jk'
api5 = 'http://api.vbox7.com/v5/?action='
token5 = '&app_token=vbox7_android_1.0.0_gT13mY'
api6 = 'https://api.vbox7.com/v6/?action='
token6 = '&app_token=vbox7_android_1.0.0_gT13mY'




#Меню с директории в приставката
def CATEGORIES():
		addLink('Зареди видео по неговото ID','VOD',0,0,'Зареди видео по неговото ID',7,md+'DefaultMovies.png')
		addDir('Търси видео във VBOX7','r_items_search&query=',3,md+'DefaultAddonsSearch.png')
		#addDir('Търси плейлисти/колекции във VBOX7','https://www.vbox7.com/xpose/search/search.do?ajax=1&order=name&type=playlist&q=',5,md+'DefaultAddonsSearch.png')
		addDir('Списък канали','s_channels',12,md+'DefaultGenre.png')
		addDir('Класации на VBOX7','url',9,md+'DefaultFolder.png')
		addDir('Каталог игрални филми','r_user_collection&id=1786738&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог документални филми','r_user_collection&id=1807205&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог детски филми','r_user_collection&id=1958423&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог детски сериали','r_user_collections&username=vatim&page=1',4,md+'DefaultStudios.png')
		addDir('Каталог Аниме','r_user_items&username=otakubulgaria&page=1',1,md+'DefaultStudios.png')
		addDir('Каталог корейски сериали','cks',11,md+'DefaultMovieTitle.png')
		addDir('Каталог KPOP клипове','r_user_collection&id=1552349&page=1',1,md+'DefaultMusicSongs.png')
		#Функции изискващи посочен акаунт
		if uname1:
			addDir('Клипове, плейлисти и абонаменти на '+uname1,uname1,10,md+'DefaultActor.png')
		else:
			addLink('Въведете VBOX7 username1 в настройките','VBOX7',0,0,'',8,md+'DefaultActor.png')
		if uname2:
			addDir('Клипове, плейлисти и абонаменти на '+uname2,uname2,10,md+'DefaultActor.png')
		if uname3:
			addDir('Клипове, плейлисти и абонаменти на '+uname3,uname3,10,md+'DefaultActor.png')
		if uname4:
			addDir('Клипове, плейлисти и абонаменти на '+uname4,uname4,10,md+'DefaultActor.png')
		if uname5:
			addDir('Клипове, плейлисти и абонаменти на '+uname5,uname5,10,md+'DefaultActor.png')
		if uname6:
			addDir('Клипове, плейлисти и абонаменти на '+uname6,uname6,10,md+'DefaultActor.png')
		if uname7:
			addDir('Клипове, плейлисти и абонаменти на '+uname7,uname7,10,md+'DefaultActor.png')
		if uname8:
			addDir('Клипове, плейлисти и абонаменти на '+uname8,uname8,10,md+'DefaultActor.png')
		if uname9:
			addDir('Клипове, плейлисти и абонаменти на '+uname9,uname9,10,md+'DefaultActor.png')
		if uname10:
			addDir('Клипове, плейлисти и абонаменти на '+uname10,uname10,10,md+'DefaultActor.png')
		if uname11:
			addDir('Клипове, плейлисти и абонаменти на '+uname11,uname11,10,md+'DefaultActor.png')
		if uname12:
			addDir('Клипове, плейлисти и абонаменти на '+uname12,uname12,10,md+'DefaultActor.png')
		if uname13:
			addDir('Клипове, плейлисти и абонаменти на '+uname13,uname13,10,md+'DefaultActor.png')
		if uname14:
			addDir('Клипове, плейлисти и абонаменти на '+uname14,uname14,10,md+'DefaultActor.png')
		if uname15:
			addDir('Клипове, плейлисти и абонаменти на '+uname15,uname15,10,md+'DefaultActor.png')
		if uname16:
			addDir('Клипове, плейлисти и абонаменти на '+uname16,uname16,10,md+'DefaultActor.png')
		if uname17:
			addDir('Клипове, плейлисти и абонаменти на '+uname17,uname17,10,md+'DefaultActor.png')
		if uname18:
			addDir('Клипове, плейлисти и абонаменти на '+uname18,uname18,10,md+'DefaultActor.png')
		if uname19:
			addDir('Клипове, плейлисти и абонаменти на '+uname19,uname19,10,md+'DefaultActor.png')
		if uname20:
			addDir('Клипове, плейлисти и абонаменти на '+uname20,uname20,10,md+'DefaultActor.png')
		if uname21:
			addDir('Клипове, плейлисти и абонаменти на '+uname21,uname21,10,md+'DefaultActor.png')
		if uname22:
			addDir('Клипове, плейлисти и абонаменти на '+uname22,uname22,10,md+'DefaultActor.png')
		if uname23:
			addDir('Клипове, плейлисти и абонаменти на '+uname23,uname23,10,md+'DefaultActor.png')
		if uname24:
			addDir('Клипове, плейлисти и абонаменти на '+uname24,uname24,10,md+'DefaultActor.png')
		if uname25:
			addDir('Клипове, плейлисти и абонаменти на '+uname25,uname25,10,md+'DefaultActor.png')
		


#Подменю класации
def KLASATZII(url):
	addDir('Избор на редактора','r_editor_content',1,md+'DefaultActor.png') #OK
	addDir('Препоръчани','r_recomended_items',1,md+'DefaultFolder.png') #OK
	addDir('Следвани','r_followed',1,md+'DefaultFolder.png') #OK
	addDir('Поредици','r_poster_events',1,md+'DefaultFolder.png') #???????????????????
	addDir('Популярни в момента','r_items_stream',1,md+'DefaultFolder.png') #OK
	addDir('ТОП 40','r_items_top40',1,md+'DefaultFolder.png') #OK
	addDir('ТОП Музика','r_items_topmusic',1,md+'DefaultMusicSongs.png') #OK
	



#Подменю функции изискващи акаунт
def USERV(uname):
	addDir('Клипове на '+uname,'r_user_videos&username='+uname+'&page=1',1,md+'DefaultActor.png')
	#addDir('Клипове на '+uname,'r_user_items&username='+uname+'&page=1',1,md+'DefaultActor.png')
	#addDir('Клипове на '+uname+' на фокус','r_user_focus_videos&username='+uname+'&page=1',1,md+'DefaultActor.png')
	addDir('Любими клипове на '+uname,'r_user_favourites&username='+uname+'&page=1',1,md+'DefaultActor.png')
	addDir('Плейлисти на '+uname,'r_user_collections&username='+uname+'&page=1',4,md+'DefaultActor.png')
	addDir('Абонаменти на '+uname,'r_user_subscription_videos&username='+uname+'&page=1',1,md+'DefaultActor.png')




#Разлистване на заглавията в директория
def INDEX(url):
		try:
			xbmcplugin.setContent(int(sys.argv[1]), 'movie')
			#https://api.vbox7.com/v6/?action=r_items_top40&app_token=vbox7_android_1.0.0_gT13mY
			try: #url е от тип byte
				jsonrsp = json.loads(urllib.request.urlopen(api6 + url.decode('utf-8') + token6).read())
			except: #url е от тип string
				jsonrsp = json.loads(urllib.request.urlopen(api6 + url + token6).read())
			indexcounter = len(jsonrsp['items'])
			
			for index in range(0, indexcounter):
				try: #префикс data, има duration, няма инфо за HD
					addLink(jsonrsp['items'][index]['data']['title'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['data']['mdkey'],jsonrsp['items'][index]['data']['duration'],0,jsonrsp['items'][index]['data']['title'].encode('utf-8', 'ignore'),2,jsonrsp['items'][index]['data']['thumbnails']['big'])
				except:
					try: #префикс data, няма duration, няма инфо за HD
						addLink(jsonrsp['items'][index]['data']['title'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['data']['mdkey'],0,0,jsonrsp['items'][index]['data']['title'].encode('utf-8', 'ignore'),2,jsonrsp['items'][index]['data']['thumbnails']['big'])
					except:
						try: #без префикс data, има duration, няма инфо за HD
							addLink(jsonrsp['items'][index]['title'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['mdkey'],jsonrsp['items'][index]['duration'],0,jsonrsp['items'][index]['title'].encode('utf-8', 'ignore'),2,jsonrsp['items'][index]['thumbnails']['big'])
						except:
							try: #без префикс data, няма duration, няма инфо за HD
								addLink(jsonrsp['items'][index]['title'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['mdkey'],0,0,jsonrsp['items'][index]['title'].encode('utf-8', 'ignore'),2,jsonrsp['items'][index]['thumbnails']['big'])
							except:
								pass
			
			
			#Ако имаме още страници...
			try: #url е от тип byte
				if 'page=' in url.decode('utf-8') and indexcounter > 13:
					lisearch = re.compile('(.+?)&page=(\d+)').findall(url.decode('utf-8'))
					for baseurl,page in lisearch:
						page = int(page) + 1
						url = baseurl + '&page=' + str(page)
						url = url.encode('utf-8')
					addDir('следваща страница>>',url,1,md+'DefaultFolder.png')
			except: #url е от тип string
				if 'page=' in url and indexcounter > 13:
					lisearch = re.compile('(.+?)&page=(\d+)').findall(url)
					for baseurl,page in lisearch:
						page = int(page) + 1
						url = baseurl + '&page=' + str(page)
						url = url.encode('utf-8')
					addDir('следваща страница>>',url,1,md+'DefaultFolder.png')
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")




#Разлистване заглавията на отделните плейлисти
def INDEXCOLLECTIONS(url):
		try:
			xbmcplugin.setContent(int(sys.argv[1]), 'season')
			#https://api.vbox7.com/v6/?action=r_user_collections&username=mrnkaloto&page=1&app_token=vbox7_android_1.0.0_gT13mY
			jsonrsp = json.loads(urllib.request.urlopen(api6 + url + token6).read())
			indexcounter = len(jsonrsp['items'])
			for index in range(0, indexcounter):
				addDir(jsonrsp['items'][index]['collection_title'].encode('utf-8', 'ignore'),'r_user_collection&id=' + str(jsonrsp['items'][index]['collection_id']) + '&page=1',1,jsonrsp['items'][index]['collection_thumbnail'][0].replace('http:https://','https://'))
			

			#Ако имаме още страници...
			if indexcounter > 14:
				lisearch = re.compile('(.+?)&page=(.+?)').findall(url)
				for baseurl,page in lisearch:
					page = int(page) + 1
					url = baseurl + '&page=' + str(page)
					url = url.encode('utf-8')
				addDir('следваща страница>>',url,4,md+'DefaultFolder.png')
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")




#Разлистване каналите с потребители
def LISTCHANNELS(url):
		try:
			xbmcplugin.setContent(int(sys.argv[1]), 'season')
			#http://api.vbox7.com/v6/?action=s_channels&app_token=vbox7_android_1.0.0_gT13mY
			jsonrsp = json.loads(urllib.request.urlopen(api6 + url + token6).read())
			indexcounter1 = len(jsonrsp['items']) #брой канали
			try:
				for index in range(0, indexcounter1):
					addDir(jsonrsp['items'][index]['data']['title'].encode('utf-8', 'ignore'),str(jsonrsp['items'][index]['data']['api_params']['channelid'])+'&page=1',13,md+'DefaultFolder.png')
			except:
				pass
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")




#Разлистване потребителите в каналите
def LISTUSERS(url):
		try:
			xbmcplugin.setContent(int(sys.argv[1]), 'season')
			#http://api.vbox7.com/v6/?action=r_channels_items&app_token=vbox7_android_1.0.0_gT13mY&channelid=14&page=1
			jsonrsp = json.loads(urllib.request.urlopen(api6 + 'r_channels_items' + token6 + '&channelid=' + url).read())
			indexcounter = len(jsonrsp['items']) #брой потребители в канала
			for index in range(0, indexcounter):
				try:
					addDir(jsonrsp['items'][index]['data']['uploader'].encode('utf-8', 'ignore'),jsonrsp['items'][index]['data']['uploader'].encode('utf-8', 'ignore'),10,jsonrsp['items'][index]['data']['uploader_avatar']['medium'])
				except:
					pass
			

			#Ако имаме още страници...
			if 'page=' in url and indexcounter > 13:
				lisearch = re.compile('channelid=(\d+)&page=(\d+)').findall(url)
				for channel,page in lisearch:
					page = int(page) + 1
					url = channel + '&page=' + str(page)
				addDir('следваща страница>>',url,13,md+'DefaultFolder.png')
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Включете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")




#Зареждане на видео
def VIDEOLINKS(url):
		#https://api.vbox7.com/v6/?action=r_item_execute&item_md5=933850bd72&app_token=vbox7_android_1.0.0_gT13mY
		jsonrsp = json.loads(urllib.request.urlopen(api6 + 'r_item_execute&item_md5=' + url + token6).read())
		#http://api.vbox7.com/v6/?action=r_video_description&video_md5=933850bd72&app_token=vbox7_android_1.0.0_gT13mY
		jsonrsp2 = json.loads(urllib.request.urlopen(api6 + 'r_video_description&video_md5=' + url + token6).read())
		title = jsonrsp['title'].encode('raw_unicode_escape', 'ignore').decode('unicode_escape', 'ignore').encode('utf8', 'ignore')
		thumb = jsonrsp['items'][0]['data']['thumbnails']['big']
		plot = jsonrsp2['items'][0]['video_description_full']
		
		try:
			#Конвертиране на субтитрите в SRT формат
			if not (jsonrsp['items'][0]['data']['subtitles_path'] == ''):
				jsonrsp = json.loads(urllib.request.urlopen(jsonrsp['items'][0]['data']['subtitles_path']).read().split("var sSubsJson = '", 1)[-1].split("';", 1)[0].decode('utf8').encode('raw_unicode_escape').decode('utf-8', 'ignore').encode('utf-8', 'ignore').replace('\\\"', '"').replace('\\\\"', '\\"'))
				row = 0
				subs = ''
				for i in range(0, len(jsonrsp)):
					row = row + 1
					subs += str(row) +'\n'
					subs += time.strftime("%H:%M:%S,000", time.gmtime(int(jsonrsp[i]['f']))) + ' --> ' + time.strftime("%H:%M:%S,000", time.gmtime(int(jsonrsp[i]['t']))) + '\n'
					subs += jsonrsp[i]['s'].encode('raw_unicode_escape', 'ignore').decode('unicode_escape', 'ignore').encode('utf8', 'ignore').replace('+',' ').replace('|','').replace('<br>','\n')
					subs += '\n\n'
				st = 'true'
				with open(srtsubs_path, "w") as subfile:
					subfile.write(subs)
			else:
				st = 'false'
		except:
			st = 'false'
		

		#Задаване на стрийм с оптимална резолюция
		try:
			stream = jsonrsp['items'][0]['data']['default_video']
		except:
			try:
				jsonrsp3 = json.loads(urllib.request.urlopen('https://www.vbox7.com/ajax/video/nextvideo.php?vid=' + url).read())
				stream = jsonrsp3['options']['src'].replace('.mpd','_'+str(jsonrsp3['options']['highestRes'])+'.mp4')
			except:
				stream = 'http://m.vbox7.com/blank.mp4'
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VBOX7','Този клип е личен!', 4000, md+'DefaultIconError.png'))


		#Възпроизвеждане на видеото
		li = xbmcgui.ListItem(path=stream+'|User-Agent='+UA+'&Referer=https://www.vbox7.com&verifypeer=false')
		li.setArt({ 'thumb': thumb,'poster': thumb, 'banner' : thumb, 'fanart': thumb, 'icon': thumb })
		li.setInfo( type="Video", infoLabels={ 'Title': title, 'Plot': plot } )
		if st=='true': #Задаване на външни субтитри, ако има такива или изключването им
			li.setSubtitles([srtsubs_path])
			xbmc.executebuiltin("Notification(VBOX7,Зареждам субтитри!,4000)")
		try:
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		except:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('VBOX7','Не мога да отворя видеото!', 4000, md+'DefaultIconError.png'))

		
		

#Търсачка
def SEARCH(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'season')
		#Отваряне на предишната заявка за търсене
		searchfile=xbmcvfs.File(search_path)
		result = searchfile.read()
		searchfile.close()
		
		keyb = xbmc.Keyboard(result, 'Търсачка на клипове')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.parse.quote_plus(keyb.getText())
			url= url + searchText + '&page=1'
			url = url.encode('utf-8')
			#print 'SEARCHING:' + url
			
			#Записване на заявката за търсене
			searchfile=xbmcvfs.File(search_path, 'w')
			result = searchfile.write(keyb.getText())
			searchfile.close()
			
			INDEX(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+"DefaultFolderBack.png")




#Каталог с корейски сериали
def KORCAT(url):
		try:
			xbmcplugin.setContent(int(sys.argv[1]), 'season')
			response = requests.get('http://shineegirlbg.blogspot.com/p/blog-page_1939.html', headers={'User-Agent': UA})

			
			match = re.compile('id=(\d{4,})\D+\">(.+?)</a>').findall(response.text)
			for cid,name in match:
				#name = title.encode('utf-8', 'ignore')
				name = name.replace("<b>", "")
				name = name.replace("</b>", "")
				#name = name.replace("<br />", "")
				#name = name.replace('<span style="font-size: large;">', "")
				#name = name.replace("</span>", "")
				name = name.replace("&nbsp;", "")
				#cid = cid.replace("#_=_", "")
				adress = 'r_user_collection&id=' + cid + '&page=1'
				if not ('http' in name):
					addDir(name,adress,1,md+"DefaultFolder.png")
		except:
			xbmc.executebuiltin("Notification(VBOX7,Няма връзка със сървъра!,4000)")
			addDir('Проверете интернет връзката и опитайте отново','','',md+"DefaultIconError.png")




#Търсачка на колекции
def SEARCHCOLLECTIONS(url):
		#Отваряне на предишната заявка за търсене
		kolfile=xbmcvfs.File(kolekcii_path)
		result = kolfile.read()
		kolfile.close()
		
		keyb = xbmc.Keyboard(result, 'Търсачка на колекции')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.parse.quote_plus(keyb.getText())
			url= url + searchText + '&page=1'
			url = url.encode('utf-8')
			#print 'Adres za tursene na kolekciqta:' + url
			
			#Записване на заявката за търсене
			kolfile=xbmcvfs.File(kolekcii_path, 'w')
			result = kolfile.write(keyb.getText())
			kolfile.close()
			
			LISTCOLLECTIONS(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+"DefaultFolderBack.png")




#Разлистване на колекциите от търсачката на колекции
def LISTCOLLECTIONS(url):
			xbmcplugin.setContent(int(sys.argv[1]), 'season')
			req = urllib.request.Request(url)
			req.add_header('User-Agent', UA)
			req.add_header('Referer', 'https://vbox7.com/')
			response = urllib.request.urlopen(req)
			data=response.read()
			response.close()
			#print data
			
			match = re.compile('data-id=\"(\d*)\" data-order=\"date\" data-p=\"playlist\" title=\"(.+?)\">').findall(data)
			for cid,title in match[::2]:
				#title = title.encode('utf-8', errors='ignore')
				#cid = re.match( r'.*coll_(.*?)_avatar.*', thumbnail, re.M|re.I)
				adress = 'r_user_collection&id=' + cid + '&page=1'
				#print 'title:' + title
				#addDir(title,adress,1,'http'+thumbnail)
				addDir(title,adress,1,md+"DefaultFolder.png")




#Зареждане на клип по неговото ID
def LOADBYID():
		keyb = xbmc.Keyboard('', 'Въведете ID на видеото http://vbox7.com/play:xxxx')
		keyb.doModal()
		if (keyb.isConfirmed()):
			vid = urllib.parse.quote_plus(keyb.getText())
			#print 'LOADBYID:' + vid
			VIDEOLINKS(vid)
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+"DefaultFolderBack.png")




#Прилагане на настройките на приставката при първо въвеждане
def SETTINGS():
		try:
			xbmcaddon.Addon(id='plugin.video.vbox7').openSettings()
			xbmc.executebuiltin("Container.Refresh")
		except:
			print('VBOX7 Addon Error: грешка при излизане от диалога за настройки или опресняване на главното меню')




#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,vd,hd,plot,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
		liz.setInfo( type="Video", infoLabels={ "Plot": plot, "Duration": vd } )
		#liz.setInfo( type="Video", infoLabels={ "Plot": "Това е plot","PlotOutline": "Това е plotoutline","Tagline": "Това е tagline","Duration": vd } )
		if hd==1:
			liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
			liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
			liz.addStreamInfo('video', { 'duration': vd })
		else:
			liz.addStreamInfo('video', { 'width': 720, 'height': 480 })
			liz.addStreamInfo('video', { 'aspect': 1.5, 'codec': 'h264' })
			liz.addStreamInfo('video', { 'duration': vd })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty('IsPlayable' , 'true')
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok




#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok




#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEX(url)
		
elif mode==2:
		VIDEOLINKS(url)

elif mode==3:
		SEARCH(url)

elif mode==4:
		INDEXCOLLECTIONS(url)

elif mode==5:
		SEARCHCOLLECTIONS(url)

elif mode==6:
		LISTCOLLECTIONS(url)

elif mode==7:
		LOADBYID()

elif mode==8:
		SETTINGS()

elif mode==9:
		KLASATZII(url)
		
elif mode==10:
		USERV(url)

elif mode==11:
		KORCAT(url)

elif mode==12:
		LISTCHANNELS(url)

elif mode==13:
		LISTUSERS(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
