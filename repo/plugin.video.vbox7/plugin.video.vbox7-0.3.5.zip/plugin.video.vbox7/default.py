# -*- coding: utf-8 -*-
import re
import sys
import os
import time
import urllib
import urllib2
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


__addon_id__= 'plugin.video.vbox7'
__Addon = xbmcaddon.Addon(__addon_id__)

#Read VBOX7 username from plugin settings
__settings__ = xbmcaddon.Addon(id='plugin.video.vbox7')
username = __settings__.getSetting("username")
uname = __settings__.getSetting("username")
menu = __settings__.getSetting("menu")

searchicon = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/search.png")
SUBS_PATH = xbmc.translatePath(__Addon.getAddonInfo('path') + "/vbox7sub.bg.srt")

MUA = 'Mozilla/5.0 (Linux; Android 4.2.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19'
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:36.0) Gecko/20100101 Firefox/36.0'
apptoken = '&app_token=qaiware_android_0.0.3_p7sDzv'

def CATEGORIES():
	
		#Menu setting: flat or tree view
		if menu=='true':
			addLink('Зареди видео по неговото ID','VOD',0,7,'DefaultVideo.png')
			addDir('Търси видео във VBOX7','r_video_search&query=',3,searchicon)
			addDir('Търси колекции във VBOX7','http://vbox7.com/search/?collection_q=',5,searchicon)
			#Functions with username settings
			if uname=='':
				addLink('Въведете VBOX7 username в настройките','VB7',0,8,'DefaultActor.png')
			else:
				addDir('Клипове, колекции и абонаменти на '+uname,'url',10,'')
			addDir('Класации на VBOX7','url',9,'')
		else:
			addLink('Зареди видео по неговото ID','VOD',0,7,'DefaultVideo.png')
			addDir('Търси видео във VBOX7','r_video_search&query=',3,searchicon)
			addDir('Търси колекции във VBOX7','http://vbox7.com/search/?collection_q=',5,searchicon)
			#Functions with username settings
			if uname=='':
				addLink('Въведете VBOX7 username в настройките','VB7',0,8,'DefaultActor.png')
			else:
				addDir('Клипове на '+uname,'r_user_videos&username='+uname+'&page=1',1,'')
				addDir('Любими клипове на '+uname,'r_user_favourites&username='+uname+'&page=1',1,'')
				addDir('Колекции на '+uname,'r_user_collections&username='+uname+'&page=1',4,'')
				addDir('Абонаменти на '+uname,'r_user_subscription_videos&username='+uname+'&page=1',1,'')
			addDir('Избор на редактора и други акценти','r_video_editor_selection',1,'DefaultActor.png')
			addDir('Популярни днес','r_video_popular&page=1',1,'')
			addDir('ТОП 40','r_video_top40',1,'')
			addDir('ТОП 40 авторски','r_video_top40_authors',1,'')
			addDir('ТОП 40 BG POP','r_video_top40_bgpop',1,'DefaultAudio.png')
			addDir('ТОП 40 BG POP FOLK','r_video_top40_bgpopfolk',1,'DefaultAudio.png')
			addDir('ТОП 40 авто и спорт','r_video_top40_by_category&category=avtosport',1,'')
			addDir('ТОП 40 смях','r_video_top40_by_category&category=smiah',1,'')
			addDir('ТОП 40 новини','r_video_top40_by_category&category=novini',1,'')
			addDir('ТОП 40 любопитно','r_video_top40_by_category&category=lubopitno',1,'')
			addDir('ТОП 40 аниме и AMV','r_video_top40_by_category&category=anime',1,'')
			addDir('ТОП 100','r_video_top100',1,'')
			#addDir('','',1,'')


def KLASATZII(url):
	addDir('Избор на редактора и други акценти','r_video_editor_selection',1,'DefaultActor.png')
	addDir('Популярни днес','r_video_popular&page=1',1,'')
	addDir('ТОП 40','r_video_top40',1,'')
	addDir('ТОП 40 авторски','r_video_top40_authors',1,'')
	addDir('ТОП 40 BG POP','r_video_top40_bgpop',1,'DefaultAudio.png')
	addDir('ТОП 40 BG POP FOLK','r_video_top40_bgpopfolk',1,'DefaultAudio.png')
	addDir('ТОП 40 авто и спорт','r_video_top40_by_category&category=avtosport',1,'')
	addDir('ТОП 40 смях','r_video_top40_by_category&category=smiah',1,'')
	addDir('ТОП 40 новини','r_video_top40_by_category&category=novini',1,'')
	addDir('ТОП 40 любопитно','r_video_top40_by_category&category=lubopitno',1,'')
	addDir('ТОП 40 аниме и AMV','r_video_top40_by_category&category=anime',1,'')
	addDir('ТОП 100','r_video_top100',1,'')


def USERV(url):
	addDir('Клипове на '+uname,'r_user_videos&username='+uname+'&page=1',1,'')
	addDir('Любими клипове на '+uname,'r_user_favourites&username='+uname+'&page=1',1,'')
	addDir('Колекции на '+uname,'r_user_collections&username='+uname+'&page=1',4,'')
	addDir('Абонаменти на '+uname,'r_user_subscription_videos&username='+uname+'&page=1',1,'')



def INDEX(url):
		api = 'https://api.vbox7.com/v3?action=' + url + apptoken
		req = urllib2.Request(api)
		req.add_header('User-Agent', MUA)
		response = urllib2.urlopen(req)
		data=response.read()
		response.close()
		
		indexcounter = 0
		match = re.compile('{"video_date.+?"video_duration":(.+?),".+?"video_mdkey":"(.+?)".+?video_subtitles_path":"(.+?),"video_thumbnails":{"original":"(.+?)",.+?video_title":"(.+?)".+?}').findall(data)
		for vd,vid,subp,thumbnail,title in match:
			thumbnail = thumbnail.replace("\\", "")
			title = title.decode('unicode_escape', errors='ignore').encode('utf-8', errors='ignore')
			title = title.replace('\/', '/')
			indexcounter = indexcounter + 1
			addLink(title,vid,vd,2,thumbnail)
		
		#If results are on more pages
		if 'page=' in url and indexcounter > 14:
			lisearch = re.compile('(.+?)&page=(.+?)').findall(url)
			for baseurl,page in lisearch:
				page = int(page) + 1
				url = baseurl + '&page=' + str(page)
				url = url.encode('utf-8')
			thumbnail='DefaultFolder.png'
			addDir('следваща страница>>',url,1,thumbnail)


def INDEXCOLLECTIONS(url):
		api = 'https://api.vbox7.com/v3?action=' + url + apptoken
		req = urllib2.Request(api)
		req.add_header('User-Agent', MUA)
		response = urllib2.urlopen(req)
		data=response.read()
		response.close()
		
		indexcounter = 0
		match = re.compile('collection_id":(.+?),".+?collection_thumbnail":(.+?),"collection_title":"(.+?)","').findall(data)
		for cid,thumbnail,title in match:
			thumbnail = thumbnail.replace('\/', '/')
			thumbnail = thumbnail.replace('["', '')
			thumbnail = thumbnail.replace('"]', '')
			title = title.replace('\/', '/')
			title = title.decode('unicode_escape', errors='ignore').encode('utf-8', errors='ignore')
			indexcounter = indexcounter + 1
			adress = 'r_user_collection&id=' + cid + '&page=1'
			addDir(title,adress,1,thumbnail)
		
		#If results are on more pages
		if indexcounter > 14:
			lisearch = re.compile('(.+?)&page=(.+?)').findall(url)
			for baseurl,page in lisearch:
				page = int(page) + 1
				url = baseurl + '&page=' + str(page)
				url = url.encode('utf-8')
			thumbnail='DefaultFolder.png'
			addDir('следваща страница>>',url,4,thumbnail)


def VIDEOLINKS(url,name):
		#Get Play URL, medium thumbnail and subtitles
		psevdoapi = 'http://vbox7.com/etc/ext.do?key=' + url
		req = urllib2.Request(psevdoapi)
		req.add_header('User-Agent', UA)
		response = urllib2.urlopen(req)
		data=response.read()
		response.close()
		
		try:
			try:
				match = re.compile('flv_addr=(.+?)&jpg_addr=(.+?)&subsEnabled=(.+?)&related').findall(data)
				playurl = match[0][0]
				Image = 'http://' + match[0][1]
		

				#Get subtitles if any and format them to srt
				st = 'false'
				if match[0][2] <> 'false':
					st = 'true'
					print 'VB7 Addon: външните субтитри са активирани'
					subs = match[0][2]
					subs = subs.encode('utf-8', errors='ignore')
					subs = urllib.unquote_plus(subs)
					subs = subs.strip('true&subsData=')
					s = re.compile('{"s":"(.*?)","t"\:(\d+),"f"\:(\d+)}')
					items = s.findall(subs)
					row = 0
					subs = ''
					for i in items:
						row = row + 1
						subs += str(row) +'\n'
						subs += time.strftime("%H:%M:%S,000", time.gmtime(int(i[2]))) + ' --> ' + time.strftime("%H:%M:%S,000", time.gmtime(int(i[1]))) + '\n'
						subs += i[0].decode('string_escape').replace('+',' ').replace('<br>','\n')
						subs += '\n\n'
			
					#Save sub to HDD
					subfile=xbmcvfs.File(SUBS_PATH, 'w')
					result = subfile.write(subs)
					subfile.close()
				else:
					st = 'false'
					print 'VB7 Addon: няма външни субтитри за това видео'
		
			except IndexError: 
				mobileapi = 'http://m.vbox7.com/play:' + url
				req = urllib2.Request(mobileapi)
				req.add_header('User-Agent', MUA)
				response = urllib2.urlopen(req)
				data=response.read()
				response.close()
			
				match = re.compile("v.src = '(.+?)';").findall(data)
				playurl = match[0]
				matchI = re.compile("'poster', '(.+?)'").findall(data)
				Image = matchI[0]
				st = 'false'
				print 'VB7 Addon: няма достъпни външни субтитри за това видео'
		
			#Play Selected Item
			li = xbmcgui.ListItem(iconImage=Image, thumbnailImage=Image, path=playurl)
			li.setInfo('video', { 'title': name })
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		
			#Set subtitles if any or disable them
			if st=='true':
				while not xbmc.Player().isPlaying():
					xbmc.sleep(100) #wait until video is being played
					xbmc.Player().setSubtitles(SUBS_PATH)
			else:
				xbmc.Player().showSubtitles(False)
				if os.path.isfile(SUBS_PATH):
					os.unlink(SUBS_PATH)

		except:
			print 'VB7 Addon Error: не е открито видеото по ID>' + url + ' , затова пренасочвам към windows error...'
			VIDEOLINKS('be1e5e8dcb','Грешка 404 - видеото не съществува')


def SEARCH(url):
		keyb = xbmc.Keyboard('', 'Търсачка на клипове')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			url= url + searchText + '&page=1'
			url = url.encode('utf-8')
			print 'SEARCHING:' + url
			INDEX(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',"DefaultFolderBack.png")


def SEARCHCOLLECTIONS(url):
		keyb = xbmc.Keyboard('', 'Търсачка на колекции')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			url= url + searchText + '&page=1'
			url = url.encode('utf-8')
			LISTCOLLECTIONS(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',"DefaultFolderBack.png")


def LISTCOLLECTIONS(url):
			req = urllib2.Request(url)
			req.add_header('User-Agent', UA)
			response = urllib2.urlopen(req)
			data=response.read()
			response.close()
			
			match = re.compile('collection:(.+?)".+?src="(.+?)" alt="(.+?)"').findall(data)
			newpage = re.compile('class="nextPage".+?page=(.+?)"><span>').findall(data)
			for cid,thumbnail,title in match:
				#title = title.encode('utf-8', errors='ignore')
				adress = 'r_user_collection&id=' + cid + '&page=1'
				#print 'title:' + title
				addDir(title,adress,1,thumbnail)
			
			#If results are on more pages
			for page in newpage:
				lisearch = re.compile('(.+?)&page=(.+?)').findall(url)
				for baseurl,page in lisearch:
					page = int(page) + 1
					url = baseurl + '&page=' + str(page)
					url = url.encode('utf-8', errors='ignore')
					print 'New collection page url:' + url
				thumbnail='DefaultFolder.png'
				addDir('следваща страница>>',url,6,thumbnail)


def LOADBYID():
		keyb = xbmc.Keyboard('', 'Въведете ID на видеото http://vbox7.com/play:xxxx')
		keyb.doModal()
		if (keyb.isConfirmed()):
			vid = urllib.quote_plus(keyb.getText())
			print 'LOADBYID:' + vid
			
			try:
				oembed = 'http://vbox7.com/etc/oembed/?format=xml&url=http%3A%2F%2Fvbox7.com%2Fplay%3A' + vid
				req = urllib2.Request(oembed)
				req.add_header('User-Agent', UA)
				response = urllib2.urlopen(req)
				data=response.read()
				response.close()

				match = re.compile('<title>(.+?)</title>').findall(data)
				name = match[0]
				name=name.replace('&quot;','"');
			except:
				name='VB7 Addon Error: грешка при зареждане на видео по неговото ID'
				
			VIDEOLINKS(vid,name)
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',"DefaultFolderBack.png")

def SETTINGS():
		try:
			xbmcaddon.Addon(id='plugin.video.vbox7').openSettings()
			xbmc.executebuiltin("Container.Refresh")
		except:
			print 'VB7 Addon Error: грешка при излизане от диалога за настройки или опресняване на главното меню'

def addLink(name,url,vd,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		liz.addStreamInfo('video', { 'duration': vd, 'Width': 1280 })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok


def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok



def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
mode=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass

#print "VB7 Operating Mode: "+str(mode)
#print "VB7 Video ID: "+str(url)
#print "VB7 Video Name: "+str(name)

if mode==None or url==None or len(url)<1:
		print ""
		CATEGORIES()
	
elif mode==1:
		print ""+url
		INDEX(url)
		
elif mode==2:
		print ""+url
		VIDEOLINKS(url,name)

elif mode==3:
		print ""+url
		SEARCH(url)

elif mode==4:
		print ""+url
		INDEXCOLLECTIONS(url)

elif mode==5:
		print ""+url
		SEARCHCOLLECTIONS(url)

elif mode==6:
		print ""+url
		LISTCOLLECTIONS(url)

elif mode==7:
		print ""+url
		LOADBYID()

elif mode==8:
		print ""+url
		SETTINGS()

elif mode==9:
		print ""+url
		KLASATZII(url)
		
elif mode==10:
		print ""+url
		USERV(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
