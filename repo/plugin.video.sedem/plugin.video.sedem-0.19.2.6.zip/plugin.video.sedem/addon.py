# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.parse, urllib.error
from urllib.parse import quote_plus
from pathlib import Path
import shutil
import requests
import html
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urlresolver

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.sedem'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.sedem')

ksuboff = __settings__.getSetting("ksuboff")

kprevedeni = __settings__.getSetting("kprevedeni")
if kprevedeni=='true':
	showbg = '&showbg=yes'
	bul = '&bul=on'
else:
	showbg = ''
	bul = ''

ksorting = __settings__.getSetting("ksorting")
if ksorting=='0':
	order=''
elif ksorting=='1':
	order = '&orderby=moviedate'
elif ksorting=='2':
	order = '&orderby=subsdate'
else:
	order = '&orderby=moviename'

md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_string_k = urllib.parse.unquote_plus(__settings__.getSetting('lastsearchk'))
search_string_d = urllib.parse.unquote_plus(__settings__.getSetting('lastsearchd'))

subpath = xbmcvfs.translatePath('special://temp/Kolibka/')
#Създай директорията, ако не съществува
if not os.path.exists(subpath):
	os.makedirs(subpath)
subarch = xbmcvfs.translatePath('special://temp/Kolibka/subtitle.rar')
subfile = xbmcvfs.translatePath('special://temp/Kolibka/kolibka.Bulgarian.srt')
peshakoffsubs_path = xbmcvfs.translatePath('special://temp/Peshakoff.Bulgarian.Forced.srt')
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0'

#Хедъри за заявки към услугите
headers = {
	'User-Agent': UA,
	'accept': '*/*',
	'origin': 'null',
	'Connection': 'keep-alive',
	'accept-language': 'bg,en-US;q=0.7,en;q=0.3',
	'Accept-Encoding': 'gzip'
					}

#Меню с директории в приставката
def CATEGORIES():
		if __settings__.getSetting("kenable") =='true':
			addDir('Търси във Колибка','http://kolibka.com/search.php?q=',3,md+'DefaultAddonsSearch.png')
			addDir('Вселена','http://kolibka.com/movies.php?cat=space'+ showbg,1,'http://kolibka.com/images/vselena1.jpg')
			addDir('Технологии','http://kolibka.com/movies.php?cat=technology'+ showbg,1,'http://kolibka.com/images/techno1.jpg')
			addDir('Енергия','http://kolibka.com/movies.php?cat=energy'+ showbg,1,'http://kolibka.com/images/energy1.jpg')
			addDir('Конфликти','http://kolibka.com/movies.php?cat=conflicts'+ showbg,1,'http://kolibka.com/images/war1.jpg')
			addDir('Природа','http://kolibka.com/movies.php?cat=nature'+ showbg,1,'http://kolibka.com/images/nature2.jpg')
			addDir('Морски свят','http://kolibka.com/movies.php?cat=sea'+ showbg,1,'http://kolibka.com/images/more1.jpg')
			addDir('Палеонтология','http://kolibka.com/movies.php?cat=paleontology'+ showbg,1,'http://kolibka.com/images/dino1.jpg')
			addDir('Животни','http://kolibka.com/movies.php?cat=animals'+ showbg,1,'http://kolibka.com/images/animals1.jpg')
			addDir('Екология','http://kolibka.com/movies.php?cat=ecology'+ showbg,1,'http://kolibka.com/images/eko1.jpg')
			addDir('Катастрофи','http://kolibka.com/movies.php?cat=catastrophes'+ showbg,1,'http://kolibka.com/images/katastrofi1.jpg')
			addDir('По света','http://kolibka.com/movies.php?cat=world'+ showbg,1,'http://kolibka.com/images/posveta1.jpg')
			addDir('Цивилизации','http://kolibka.com/movies.php?cat=civilizations'+ showbg,1,'http://kolibka.com/images/civil1.jpg')
			addDir('Човек','http://kolibka.com/movies.php?cat=human'+ showbg,1,'http://kolibka.com/images/chovek1.jpg')
			addDir('Общество','http://kolibka.com/movies.php?cat=society'+ showbg,1,'http://kolibka.com/images/ob6testvo1.jpg')
			addDir('Личности','http://kolibka.com/movies.php?cat=biography'+ showbg,1,'http://kolibka.com/images/lichnost1.jpg')
			addDir('Изкуство','http://kolibka.com/movies.php?cat=art'+ showbg,1,'http://kolibka.com/images/art1.jpg')
			addDir('Духовни учения','http://kolibka.com/movies.php?cat=spiritual'+ showbg,1,'http://kolibka.com/images/duh1.jpg')
			addDir('Загадки','http://kolibka.com/movies.php?cat=mysteries'+ showbg,1,'http://kolibka.com/images/zagadka1.jpg')
			addDir('БГ творчество','http://kolibka.com/movies.php?cat=bg'+ showbg,1,'http://kolibka.com/images/bg1.jpg')
		if __settings__.getSetting("denable") =='true':
			addDir('Търси във Документални','http://www.dokumentalni.com/?s=',6,md+'DefaultAddonsSearch.png')
			addDir('България','http://www.dokumentalni.com/archives/category/%d0%b1%d1%8a%d0%bb%d0%b3%d0%b0%d1%80%d0%b8%d1%8f/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/Bulgaria-ekologiq.jpg')
			addDir('Герои','http://www.dokumentalni.com/archives/category/%d0%b2%d0%b4%d1%8a%d1%85%d0%bd%d0%be%d0%b2%d0%b8%d1%82%d0%b5%d0%bb%d0%b8/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2016/01/citizenfour.jpg')
			addDir('Екология','http://www.dokumentalni.com/archives/category/%d0%b5%d0%ba%d0%be%d0%bb%d0%be%d0%b3%d0%b8%d1%8f/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/ekologiq.jpg')
			addDir('Здраве','http://www.dokumentalni.com/archives/category/%d0%b7%d0%b4%d1%80%d0%b0%d0%b2%d0%b5/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2012/12/HUNGRY-FOR-CHANGE-small-WEB1.jpg')
			addDir('Икономика','http://www.dokumentalni.com/archives/category/%d0%b8%d0%ba%d0%be%d0%bd%d0%be%d0%bc%d0%b8%d0%ba%d0%b0/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/ikonomika4-1.jpg')
			addDir('История','http://www.dokumentalni.com/archives/category/%d0%b8%d1%81%d1%82%d0%be%d1%80%d0%b8%d1%8f/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/istoriq1-1.jpg')
			addDir('Космос','http://www.dokumentalni.com/archives/category/%d0%ba%d0%be%d1%81%d0%bc%d0%be%d1%81/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/cosmos.jpeg')
			addDir('Култури','http://www.dokumentalni.com/archives/category/%d0%ba%d1%83%d0%bb%d1%82%d1%83%d1%80%d0%b8/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/culture-Copia.jpg')
			addDir('Наука','http://www.dokumentalni.com/archives/category/%d0%bd%d0%b0%d1%83%d0%ba%d0%b0/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/nauka1-1.jpg')
			addDir('Сатира','http://www.dokumentalni.com/archives/category/%d1%81%d0%b0%d1%82%d0%b8%d1%80%d0%b0/page/1',4,'http://www.dokumentalni.com/wp-content/uploads/2017/06/chimp_laugh-500x383.jpeg')
		if __settings__.getSetting("penable") =='true':
			addDir('Peshakoff Studio','https://ufobg.com/category/%D0%B2%D0%B8%D0%B4%D0%B5%D0%BE%D1%82%D0%B5%D0%BA%D0%B0/%D0%B4%D0%BE%D0%BA%D1%83%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D0%BB%D0%BD%D0%B8/page/1/',7,'https://ufobg.com/wp-content/uploads/2020/05/simeonoff-logo-white.png')
		

#Парсване на страница с филми в колибката
def KINDEX(url):
		url = url + order
		response = requests.get(url, headers=headers)
		newpage=re.compile('page=(.+?)&amp;orderby=.*&amp;.*\n.*alt="следваща страница"').findall(response.text)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'movie')
		matcht = re.compile('<table((.|[\r\n])+?)</table').findall(response.text)
		for table in matcht:
			titl = str(table)
			#print titl

			desc=''
			thumbnail=md+'DefaultVideo.png'
			matchp = re.compile('<img src=.*thumbs/(.+?)" alt="(.+?)" border').findall(titl)
			for thumb,title1 in matchp:
				thumbnail = 'http://kolibka.com/thumbs/' + thumb
				#title1=title1.decode('unicode_escape').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore') #.decode('unicode_escape').encode('ascii', 'ignore')
				title1=title1.replace('(','')
				title1=title1.replace(')','')
				title1=html.unescape(title1)
				#print title1
				n = title1.split(' / ')
				for lang in n:
					title1=lang[:]
					#print title1
			
			#html.unescape(аргумент) поправя HTML кодировката на символите; urllib.parse.quote(аргумент) коригира спейсовете в адресите; re.compile(r'<[^>]+>').sub('', аргумент) премахва HTML таговете от стринг
			matcho = re.compile(':</b><br />(.+?)</div>').findall(titl)
			for description in matcho:
				desc=description
				desc=html.unescape(desc)
				desc=re.compile(r'<[^>]+>').sub('', desc) #.decode('unicode_escape').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore')
				#desc=desc.replace('&quot;','"')
				#desc=desc.replace('<br />',' ')
				#desc=re.sub('_+', '', desc)
				#print desc
				
			match = re.compile('mid=(.+?)" title="(.+?)">(.+?)<').findall(titl)
			for mid,t,title2 in match:
				#title2=title2.decode('unicode_escape').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore') #.decode('unicode_escape').encode('ascii', 'ignore')
				#title2=title2.replace(' - ','-')
				#title2=title2.replace('- ','-')
				title=title1+ ' :: '+title2
				title=title.replace('  ',' ')
				title=title.replace('  ',' ')
				#print title
				addLink(title,mid+'@'+thumbnail+'@'+desc,desc,2,thumbnail)
		#Край на обхождането
		
		#Ако резултатите са на повече страници
		if newpage != []:
			if 'http://kolibka.com/movies.php' in url:
				lisearch = re.compile('(.+?)&page=.*').findall(url)
				for exactmatch in lisearch:
					url = exactmatch
			url = url + '&page=' + newpage[0][0]
			#print 'URL OF THE NEXT PAGE IS' + url
			thumbnail=md+'DefaultFolder.png'
			addDir('следваща страница>>',url,1,thumbnail)



#Възпроизвеждане на филма със субтитрите в колибката
def KVIDEOLINKS(name,url):
		mid, thumbnail, desc = url.split("@")
		#Получване на URL адресите
		playurl = urllib.request.urlopen('http://kolibka.com/download.php?mid=' + mid).geturl() #по надеждно зареждане на крайният адрес
		try:
			suburl = urllib.request.urlopen('http://kolibka.com/download.php?sid=' + mid).geturl()
		except:
			sub = 'false'
		
		#Осигуряваме субтитри
		if ksuboff=='true':
			sub = 'false'
		else:
			try:
				#Изтрий старите и Изтегли новите
				if xbmcvfs.exists(subarch): xbmcvfs.delete(subarch)
				#myfile = Path(subarch)
				#myfile.touch(exist_ok=True)
				#f = open(myfile)

				if xbmcvfs.exists(subfile): xbmcvfs.delete(subfile)
				urllib.request.urlretrieve(suburl, subarch)
				#with urllib.request.urlopen(suburl) as response, open(subarch, 'wb') as out_file:
				#	data = response.read()
				#	out_file.write(data)
				#Разархивирай
				(dirs, files) = xbmcvfs.listdir('rar://%s' % (quote_plus(subarch)))
				#print(dirs)
				#print(files)
				for file in files:
					src = 'rar://' + quote_plus(subarch) + '/' + file
					#print (src)
					dest = subpath + file
					#print (dest)
					xbmcvfs.copy(src, dest)
			
				#Намери и преименувай
				files = os.listdir(subpath)
				patern = '.*\.(srt|sub)$'
				for filename in files:
					if re.match(patern, filename):
						file = subpath + filename
						os.rename(file, subfile)
						sub = 'true'
						#xbmcgui.Dialog().ok('SUBFILE',subfile)
			except:
				sub = 'false'
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('КОЛИБКА','Филмът е без външни субтитри!?', 4000, md+'DefaultAddonSubtitles.png'))
		
		
		#Пускане на филма
		li = xbmcgui.ListItem(path=playurl+'|User-Agent='+UA+'&Referer=http://kolibka.com&verifypeer=false')
		li.setArt({ 'thumb': thumbnail,'poster': thumbnail, 'banner' : thumbnail, 'fanart': thumbnail, 'icon': thumbnail })
		li.setInfo( type="Video", infoLabels={ 'Title': name, 'Plot': desc } )
		try:
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			#Задаване на субтитри, ако има такива или изключването им
			if sub=='true':
				while not xbmc.Player().isPlaying():
					xbmc.sleep(1000) #wait until video is being played
					xbmc.Player().setSubtitles(subfile)
			else:
				xbmc.Player().showSubtitles(False)
		except:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('КОЛИБКА','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))



#Търсачка в колибката
def KSEARCH(url):
		keyb = xbmc.Keyboard(search_string_k, 'Търсачка на филми')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.parse.quote_plus(keyb.getText())
			
			if searchText == "":
				addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','',md+'DefaultFolderBack.png')
			else:
				#Записване на заявката за търсене в настройките
				__settings__.setSetting('lastsearchk', searchText)
			
			url = url + searchText + bul
			url = url.encode('utf-8')
			KINDEX(url.lower().decode()) #.decode() поправя грешките в bytes
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+'DefaultFolderBack.png')


#Парсване на страница с филми в документални
def DINDEX(url):
		response = requests.get(url, headers=headers)
		newpage=re.compile('rel=\"next\" href=\".*/page/(\d+)\">»').findall(response.text)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'movie')
		matcha = re.compile('<article((.|[\r\n])+?)</article').findall(response.text)
		for article in matcha:
			titl = str(article)
			#print (titl)

			#desc=''
			thumbnail=md+'DefaultVideo.png'
			matchp = re.compile('data-src=\"(http.+?)\" ').findall(titl)
			for thumb in matchp:
				thumbnail = thumb
				#print('thumbnail:' + thumbnail)
				
			matchd = re.compile('sub-lineheight\">(.+?)<').findall(titl)
			for description in matchd:
				desc=description.strip() #.decode('unicode_escape').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore')
				#desc=desc.replace('[&hellip;]','').replace('&#8211;','-')
				#desc=desc.replace('&#8222;','"').replace('&#8220;','"')
				
			matcht = re.compile('<a href=\"(.+?)\".*title=\"(.+?)\"').findall(titl)
			for pid,title in matcht:
				#title = title.decode('unicode_escape').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore')
				#title = title.replace('&#8211;','-').replace('&#8217;',"'").replace('&#8230;','...')
				addLink(html.unescape(title),pid+'@'+thumbnail+'@'+desc,html.unescape(desc),5,thumbnail)
		#Край на обхождането
		
		#Ако резултатите са на повече страници
		if newpage != []:
			if 'http://www.dokumentalni.com/archives/category/' in url:
				lisearch = re.compile('(.*/page/)\d+').findall(url)
				for exactmatch in lisearch:
					url = exactmatch
			url = url + newpage[0][0]
			#print 'URL OF THE NEXT PAGE IS' + url
			thumbnail=md+'DefaultFolder.png'
			addDir('следваща страница>>',url,4,thumbnail)



#Възпроизвеждане на филма със субтитрите в документални
def DVIDEOLINKS(name,url):
		mid, thumbnail, desc = url.split("@")
		
		#Получване на URL адресите
		response = requests.get(mid, headers=headers)
		matchl = re.compile('<ifram.* src=\"(.+?)\".*allowfullscreen').findall(response.text)
		for iframe in matchl:
			video = iframe #.replace('https://www.youtube.com/embed/','https://www.youtube.com/watch?v=')
			
		
		#Пускане на филма
		#xbmcgui.Dialog().ok('DOCUMENTALNI URL',video)
		#print('URL: '+video)
		if 'video' in locals():
			hmf = urlresolver.HostedMediaFile(video)
			if hmf:
				try:
					#Play via universal urlresolver
					li = xbmcgui.ListItem(path=urlresolver.resolve(video))
					li.setArt({ 'thumb': thumbnail,'poster': thumbnail, 'banner' : thumbnail, 'fanart': thumbnail, 'icon': thumbnail })
					li.setInfo( type="Video", infoLabels={ 'Title': name, 'Plot': desc } )
					try:
						xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
					except:
						xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('ДОКУМЕНТАЛНИ','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))
				except:
					xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('ДОКУМЕНТАЛНИ','Грешка при подготвяне на видеото', 4000, md+'DefaultIconError.png'))
			else:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('ДОКУМЕНТАЛНИ','Този хостинг не се поддържа', 4000, md+'DefaultIconError.png'))
		else:
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('ДОКУМЕНТАЛНИ','Не открих видео линк', 4000, md+'DefaultIconError.png'))
		
		



#Търсачка в документални
def DSEARCH(url):
		keyb = xbmc.Keyboard(search_string_d, 'Търсачка на филми')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.parse.quote_plus(keyb.getText())
			
			if searchText == "":
				addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','',md+'DefaultFolderBack.png')
			else:
				#Записване на заявката за търсене в настройките
				__settings__.setSetting('lastsearchd', searchText)
			
			url = url + searchText
			url = url.encode('utf-8')
			DINDEX(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+'DefaultFolderBack.png')



#Парсване на страница с филми в PeshakoffStudio
def PINDEX(url):
		response = requests.get(url, headers=headers)
		newpage=re.compile('/page/(\d+)/').findall(url)
		
		#Начало на обхождането
		xbmcplugin.setContent(int(sys.argv[1]), 'movie')
		nm=0
		desc=''
		thumbnail=md+'DefaultVideo.png'
		match = re.compile('<h3 class=\"entry-title\"><a href=\"(.+?)/\" title=\"(.+?)\">').findall(response.text)
		for url1, title in match:
			nm=nm+1
			thumbnail = ''
			title = html.unescape(title).replace('" class="post-thumb','') #urllib.parse.unquote(url1).decode('utf8', 'ignore').encode('utf8', 'ignore').replace('https://ufobg.com/','').replace('-',' ')
			desc=title
			addLink(title,url1+'@'+thumbnail+'@'+desc,desc,8,thumbnail)
		#addDir(title,url1,8,thumbnail)
		#Край на обхождането

		#Ако резултатите са на повече страници
		if nm == 10:
			npn = int(newpage[0])+1
			url = 'https://ufobg.com/category/%D0%B2%D0%B8%D0%B4%D0%B5%D0%BE%D1%82%D0%B5%D0%BA%D0%B0/%D0%B4%D0%BE%D0%BA%D1%83%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D0%BB%D0%BD%D0%B8/page/'+str(npn)+'/'
			#print 'URL OF THE NEXT PAGE IS' + url
			thumbnail=md+'DefaultFolder.png'
			addDir('Към страница '+str(npn)+' >>',url,7,thumbnail)


#Възпроизвеждане на филма със субтитрите
def PVIDEOLINKS(name,url):
		pv, thumbnail, desc = url.split("@")
		#xbmcgui.Dialog().ok('PESHAKOFFSTUDIO PV',pv)
		#Получване на URL адресите
		response = requests.get(pv, headers=headers)
		
		matchl = re.compile('<source src=\"htt.{1,2}:\/\/(.+?.mp4).{0,20}\" ').findall(response.text)
		for videol in matchl:
			videohref = 'https://' + videol.replace(' ','%20')
			#xbmcgui.Dialog().ok('PESHAKOFFSTUDIO URL',videohref)
		matchd = re.compile('<meta itemprop="description" content="(.+?)" /').findall(response.text)
		for desctext in matchd:
			desc = desctext #urllib.parse.unquote(desctext).decode('utf8', 'ignore').encode('utf8', 'ignore').replace('&#8220;','"').replace('&#8221;','"')
		
		#Субтитри WEBVTT -> SRT
		sub = 'false'
		matchs = re.compile("'subtitles' src='(.+?)' srclang=").findall(response.text)
		for subf in matchs:
			#xbmcgui.Dialog().ok('PESHAKOFFSTUDIO SUB',subf)
			req = requests.get(subf.replace(' ','%20'), headers=headers)
			data = req.text
						
			lines = []
			current_sub_line = []
			for line in data.split("\r\n"):
				if current_sub_line:
					current_sub_line.append(line)
					if not line:
						lines.append("\n".join(current_sub_line) + "\n")
						current_sub_line = []
				elif " --> " in line:
					current_sub_line = [re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)', r'\n\1,\2 --> \3,\4', line)]
			lines.append("\n".join(current_sub_line))
			complete = "".join(("{}{}".format(i, l) for i, l in enumerate(lines, 1)))
			with open(peshakoffsubs_path, "w") as subfile:
				subfile.write(complete)
				sub = 'true'
		
		#Пускане на филма
		if videohref:
			try:
				#Direct play
				li = xbmcgui.ListItem(path=videohref)
				li.setArt({ 'thumb': thumbnail,'poster': thumbnail, 'banner' : thumbnail, 'fanart': thumbnail, 'icon': thumbnail })
				li.setInfo( type="Video", infoLabels={ 'Title': name, 'Plot': desc } )
				try:
					xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
					#Задаване на субтитри, ако има такива или изключването им
					if sub=='true':
						while not xbmc.Player().isPlaying():
							xbmc.sleep(1000) #wait until video is being played
							xbmc.Player().setSubtitles(peshakoffsubs_path)
					else:
						xbmc.Player().showSubtitles(False)
						xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('PESHAKOFFSTUDIO','Филмът е без външни субтитри!?', 4000, md+'DefaultAddonSubtitles.png'))
				except:
					xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('PESHAKOFFSTUDIO','Не мога да отворя видеото', 4000, md+'DefaultIconError.png'))
			except:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('PESHAKOFFSTUDIO','Грешка при подготовката на видеото', 4000, md+'DefaultIconError.png'))



#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,desc,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc } )
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok

#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass

#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		KINDEX(url)
		
elif mode==2:
		KVIDEOLINKS(name,url)

elif mode==3:
		KSEARCH(url)

elif mode==4:
		DINDEX(url)
		
elif mode==5:
		DVIDEOLINKS(name,url)

elif mode==6:
		DSEARCH(url)

elif mode==7:
		PINDEX(url)

elif mode==8:
		PVIDEOLINKS(name,url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
