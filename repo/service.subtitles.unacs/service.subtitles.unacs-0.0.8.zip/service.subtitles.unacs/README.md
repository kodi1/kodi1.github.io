service.subtitles.unacs
=======================

If you are using previous version of script, you need to uninstall it, before install this one.

Thanks to josdion and jconxtc

Plugin can be installed via repo:
http://kodi1.github.io/repo.bg.plugins.zip
