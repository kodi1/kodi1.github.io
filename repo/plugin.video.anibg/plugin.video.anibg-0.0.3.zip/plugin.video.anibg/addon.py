# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urlresolver

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.anibg'
__Addon = xbmcaddon.Addon(__addon_id__)
md = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:54.0) Gecko/20100101 Firefox/54.0' #За симулиране на заявка от компютърен браузър


#Меню с директории в приставката
def CATEGORIES():
        addDir('Търсене','http://anibg.info/index.php?do=search&subaction=search&search_start=0&full_search=0&result_from=1&story=','',3,md+'DefaultAddonsSearch.png')
        addDir('Топли-топли','http://anibg.info/ongoing/page/1/','',1,md+'DefaultFolder.png')
        addDir('Азиатски сериали','http://anibg.info/aziatski-seriali/page/1/','',1,md+'DefaultFolder.png')
        addDir('Бойни изкуства','http://anibg.info/martial-arts/page/1/','',1,md+'DefaultFolder.png')
        addDir('Вампири','http://anibg.info/vampires/page/1/','',1,md+'DefaultFolder.png')
        addDir('Военни','http://anibg.info/military/page/1/','',1,md+'DefaultFolder.png')
        addDir('Детективски','http://anibg.info/detective/page/1/','',1,md+'DefaultFolder.png')
        addDir('Джосей','http://anibg.info/josei/page/1/','',1,md+'DefaultFolder.png')
        addDir('Драма','http://anibg.info/drama/page/1/','',1,md+'DefaultFolder.png')
        addDir('Ежедневие','http://anibg.info/slice-of-life/page/1/','',1,md+'DefaultFolder.png')
        addDir('Екшън','http://anibg.info/action/page/1/','',1,md+'DefaultFolder.png')
        addDir('Ечи','http://anibg.info/ecchi/page/1/','',1,md+'DefaultFolder.png')
        addDir('История','http://anibg.info/history/page/1/','',1,md+'DefaultFolder.png')
        addDir('Комедия','http://anibg.info/comedy/page/1/','',1,md+'DefaultFolder.png')
        addDir('Магическо момиче','http://anibg.info/magical-girl/page/1/','',1,md+'DefaultFolder.png')
        addDir('Меха','http://anibg.info/mecha/page/1/','',1,md+'DefaultFolder.png')
        addDir('Мистерия','http://anibg.info/mistery/page/1/','',1,md+'DefaultFolder.png')
        addDir('Музикални','http://anibg.info/musics/page/1/','',1,md+'DefaultFolder.png')
        addDir('Приключения','http://anibg.info/adventure/page/1/','',1,md+'DefaultFolder.png')
        addDir('Психология','http://anibg.info/psychology/page/1/','',1,md+'DefaultFolder.png')
        addDir('Романтика','http://anibg.info/romance/page/1/','',1,md+'DefaultFolder.png')
        addDir('Самурай','http://anibg.info/samurai/page/1/','',1,md+'DefaultFolder.png')
        addDir('Свръхестествено','http://anibg.info/super-natural/page/1/','',1,md+'DefaultFolder.png')
        addDir('Сейнен','http://anibg.info/seinen/page/1/','',1,md+'DefaultFolder.png')
        addDir('Спорт','http://anibg.info/sport/page/1/','',1,md+'DefaultFolder.png')
        addDir('Трилър','http://anibg.info/thriller/page/1/','',1,md+'DefaultFolder.png')
        addDir('Ужаси','http://anibg.info/horror/page/1/','',1,md+'DefaultFolder.png')
        addDir('Училище','http://anibg.info/school/page/1/','',1,md+'DefaultFolder.png')
        addDir('Фентъзи','http://anibg.info/fantasy/page/1/','',1,md+'DefaultFolder.png')
        addDir('Харем','http://anibg.info/harem/page/1/','',1,md+'DefaultFolder.png')
        addDir('Юри','http://anibg.info/yuri/page/1/','',1,md+'DefaultFolder.png')
        addDir('Яой','http://anibg.info/yaoi/page/1/','',1,md+'DefaultFolder.png')
        addDir('SciFi','http://anibg.info/scifi/page/1/','',1,md+'DefaultFolder.png')
        #addDir('','','',1,md+'')




#Разлистване на категориите аниме
def INDEXCAT(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        #print 'request page url:' + url
        data=response.read()
        response.close()
        
        #Начало на обхождането
        desc = ''
        br = 0 #Брояч на аниметата в страницата
        matcha = re.compile('<article((.|[\r\n])+?)</article').findall(data)
        for article in matcha:
            art = str(article)
            #print art
            
            matcho = re.compile('story_c_text\">(.+?)</div>').findall(art)
            for description in matcho:
                desc = description.decode('unicode_escape').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore')
                desc=desc.replace('&quot;','"').replace('&nbsp;',' ').replace('<p>',' ').replace('</p>',' ').replace('<span>','').replace('</span>','').replace('<br />',' ').replace('<b>','').replace('</b>','')
                
            
            match = re.compile('<a href=\"(.+?)\">(.+?)</a>.*><li><img src=\"(.+?)\" alt=').findall(art)
            for alink, title, poster in match:
                poster = 'http://anibg.info' + poster.replace(' ','%20')
                addDir(title,alink,desc,2,poster)
                br = br + 1 #добавяме и това видео към общия брояч
        #Край на обхождането
        
        #Ако резултатите са на повече от една страници
        if br == 10: #тогава имаме следваща страница и конструираме нейния адрес
            getpage=re.compile('(.+?)page/(.+?)/').findall(url)
            for baseurl,page in getpage:
                newpage = int(page)+1
                url = baseurl + 'page/' + str(newpage) + '/'
                #print 'URL OF THE NEXT PAGE IS:' + url
                thumbnail=md+'DefaultFolder.png'
                addDir('следваща страница>>',url,'',1,thumbnail)






#Разлистване на епизодите
def INDEXPAGES(name,url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        #print 'request page url:' + url
        data=response.read()
        response.close()
        
        #Извличане на обложка
        matchp = re.compile('meta property="og:image" content="(.+?)"').findall(data)
        for poster in matchp:
            thumbnail = poster
        
        #Извличане на епизодите
        matche = re.compile('{\"title\": \"(.+?)\", \"file\": \"(.+?)\", \"image\": \"(.+?)\"').findall(data)
        for title, video, cover in matche:
            if 'http' not in video:
                video = 'http:'+video
            if ('http' not in cover and '/' in cover):
                cover = 'http:'+cover
            else:
                cover = thumbnail
            addLink(name+' '+title,video,4,cover)
            
            
                







#Търсачка
def SEARCH(url):
        keyb = xbmc.Keyboard('', 'Търсачка')
        keyb.doModal()
        searchText = ''
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
            searchText=searchText.replace(' ','+')
            searchurl = url + searchText
            searchurl = searchurl.encode('utf-8')
            #print 'SEARCHING:' + searchurl
            INDEXCAT(searchurl)
        else:
            addDir('Върнете се назад в главното меню за да продължите','','','',md+'DefaultFolderBack.png')







#Подготвяне и зареждане на видео
def PLAY(name,url,iconimage):
        if 'Unknown' in url:
            xbmc.executebuiltin("Notification(AniBG,Липсва видеострийм в сайта!,4000)")
        else:
            try:
                hmf = urlresolver.HostedMediaFile(url)
                if hmf:
                    item = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=str(urlresolver.resolve(url)))
                    item.setInfo( type="Video", infoLabels={ "Title": name } )
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
                else:
                    item = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=url+'|User-Agent='+UA+'&Referer=http://www.anibg.info/')
                    item.setInfo( type="Video", infoLabels={ "Title": name } )
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            except:
                xbmc.executebuiltin("Notification(AniBG,Не мога да отворя видеото!,4000)")
            
            
            







#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,desc,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        #xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        name=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        CATEGORIES()
    
elif mode==1:
        INDEXCAT(url)

elif mode==2:
        INDEXPAGES(name,url)

elif mode==3:
        SEARCH(url)

elif mode==4:
        PLAY(name,url,iconimage)


xbmcplugin.endOfDirectory(int(sys.argv[1]))