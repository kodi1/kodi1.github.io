<img align="right" src="https://raw.githubusercontent.com/harrygg/plugin.video.btvplus/master/resources/icon.png" alt="BtvPlus logo">

# Коди добавка предоставяща минимален интерфейс за гледане на видео съдържание от сайта btvplus.bg

> Добавката не е официална нито е одобрена или насърчена от btvplus.bg

## Възможности

* Преглед на категориите
* Възпроизвеждане на видео
* Възпроизвеждане на живо на bTV 

## Инсталация

* Ръчно, като свалите зипа (и инсталирате предварително всички зависимости)
* Автоматично, през хранилището [BG Addons](https://kodi1.github.io/)